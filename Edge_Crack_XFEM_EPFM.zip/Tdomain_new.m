function [Tdomain] = Tdomain_new(c,xTip,numelem)

global node element updated_node

numnode = size(updated_node,1);
radius_x = c(1,1);
radius_y = c(1,2);
center = xTip;
r1=[]; r2=[];
% Distance from the center of tip element
for i = 1 : numnode
    sctr = updated_node(i,:);
    rho1  = abs(center(1,1)-sctr(1,1));
    rho2  = abs(center(1,2)-sctr(1,2));
    r1    = [r1,rho1];
    r2    = [r2,rho2];
end
test1 = r1-radius_x;
test2 = r2-radius_y;

ind=0;
for i = 1:numnode
    Tnode1 = (test1(1,i)<=0) && (test2(1,i)<=0);
    if Tnode1==1
        ind = ind+1;
        Tnode(ind) = i;
    end
end
ind1=0;
for i = 1:numelem
    sctr = element(i,:);
    for j = 1:length(Tnode)
        kk = Tnode(j);
        if (ismember(kk,sctr))
            ind1 = ind1+1;
            Tdomain(ind1,1) = i;
        end
    end
end







