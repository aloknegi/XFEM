igp = 0; numgpt1=0; numgpt2=0;
dstrain = zeros(3,1);    %incremental strain matrix
fint = zeros(total_unknown,1);    %initialising internal force vector
for iel = 1:numelem
    sctr = element(iel,:);     % element connectivity
    U    = element_disp(iel,pos,enrich_node,du);
    sctrB = assembly(iel,enrich_node,pos);
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))   % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,tip_elem))   % tip element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,split_elem_fictitious))   % fictitious element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (any(intersect(Fnodes,sctr)) ~= 0)   % having total enrich nodes (split + tip + fictitious)
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
    for kk = 1 : size(W,1)
        pt = Q(kk,:);     % quadrature point
        igp = igp + 1;
        [B,J0] = xfemBmatrix_LEFM(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
        
        C = Cmat(1:3,1:3,igp);
        
        if (ismember(iel,stiff_elem))
            numgpt1 = numgpt1+1;
            Sy0 = Yield1(numgpt1,1);
        else
            numgpt2 = numgpt2+1;
            Sy0 = Yield2(numgpt2,1);
        end
        
        %--------- Calculation of Cmat(elasto-plastic matrix)---------------
        if(strcmp(PlasticityModel,'RADIALRETURN'))
            
            dstrain(1:3,1) = B*U;    % incremental elastic strain
            Sn_e = strain_e(1:3,igp);   %Elastic Strain
            Sn_p = strain_p(1:3,igp);   %Plastic Strain
            rt = rp(igp,1);    %Hardening function
            Snp_eff = Strn_p(igp,1);   %Effective Plastic Strain
            
            [S3 Sn_e Sn_p Snp_eff Seff_red Cep rt] = StateUpdate_PSs(Sn_e,Sn_p,dstrain,rt,E,nu,mu,H,beta,pow,Sy0,C,Snp_eff,MaterialModel);
            
            stress(:,igp)= S3;    %Final stress
            strain_e(1:3,igp) = Sn_e;    %Elastic strains
            strain_p(1:3,igp) = Sn_p;    %Plastic strains
            Strn_p(igp,1) = Snp_eff;    %Effective Plastic strain
            Seff(igp,1) = Seff_red;    %effective stress
            CMAT(:,:,igp) = Cep;     %elasto-plastic matrix
            rp(igp,1) = rt;
            stress_y(igp,1) = S3(2,1);
            strain_e(4,igp) = -(nu/(1-nu))*(Sn_e(1)+Sn_e(2));     %Elastic Strain zz
            strain_p(4,igp) = -(Sn_p(1)+Sn_p(2));     %Plastic Strain zz due to incompressibility condition of plastic flow
            strain(:,igp) = strain_e(:,igp)+strain_p(:,igp);     %Total Strain
            
        else
            [dSn4 dSs4] = StressElastic(B,U,D,nu,E,stressState);
            Ss4_prev = stress(:,igp);
            Seff_prev = Seff(igp,1);
            Snp_eff_prev = Strn_p_prev(igp,1);     %Effective Plastic Strain
            Snp_eff = Strn_p(igp,1);     %Effective Plastic Strain of last step
            
            [S4 Yield0 Snp_eff Snp_eff_prev Seff_red Dep] = OwenH_EPlasticity(dSs4,Ss4_prev,Seff_prev,Sy0,Snp_eff,Snp_eff_prev,H,beta,pow,E,Sy0,D,MaterialModel);
            
            Yield(igp,1) = Yield0;
            Strn_p_prev(igp,1) = Snp_eff_prev;
            stress(:,igp)= S4;    %Final stress
            Strn_p(igp,1) = Snp_eff;    %Effective Plastic strain
            Seff(igp,1) = Seff_red;    %effective stress
            Dmat(:,:,igp) = Dep;
            strain(:,igp) = strain(:,igp) + dSn4;    %Total Strain
            stress_y(igp,1) = S4(2,1);
        end
        
        %-----Calculation of strain zz & Thickness update---------
        delta_epsilon = strain(:,igp) - strain_prev(:,igp);    %Incremental strain
        T(igp) = T(igp)*(1+delta_epsilon(4));    %Thickness update
        t = T(igp);    %updated thickness
        strain_prev(:,igp)= strain(:,igp);     %Strain of previous load step
        
        %>>>>>>>>> Calculation of Effective Strain >>>>>>>>>>>>
        Sn4 = strain(:,igp);
        aa = (Sn4(1,1)-Sn4(2,1))^2 + (Sn4(2,1)-Sn4(4,1))^2 + (Sn4(4,1)-Sn4(1,1))^2 + 6*(Sn4(3,1)/2)^2;
        strn_eff(igp,1) = sqrt(2*aa)/3;
        
        %----Computation of Internal Force Vector------------
        fint(sctrB,1) = fint(sctrB,1) + t*B'*stress(1:3,igp)*W(kk)*det(J0);  %internal force vector
        
    end %End of loop over GP's
end %End of loop over elements

