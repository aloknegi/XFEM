% EDGE CRACK WITH PLANE STRESS PLASTICITY(XFEM CODE)+ Elasto-plastic J-Integral
% Stress Integration Algorithm: 1.RADIAL RETURN  2. OWENHINTON
% Material Models:  1. Constant Hardening 2. Ramberg's Osgood
% Nodes, Crack Tip and Thickness are updated
% Dated 21/09/2012(latest code till now)

clear all; close all; clc; state = 0;tic;

%------------------------------------
Type = 'ELASTO-PLASTIC';
stressState = 'PLANE_STRESS';
YieldCriteria = 'VON MISES';
% PlasticityModel = 'OWENHINTON';
PlasticityModel = 'RADIALRETURN';
MaterialModel = 2;
NODE_UPDATE = 'YES';
TIP_UPDATE = 'YES';
%------------------------------------
ITER = 200;
ubar = 5/ITER;
% ubar1 = [0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005 0.005];% 0.1 0.1 0.1 0.1 0.1];% 0.025 0.025 0.025 0.025];%0.0123 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.005 0.03 0.03 0.03 0.005 0.03 0.005 0.005 0.005 0.005 0.005];
% ITER = length(ubar1);
%------------------------------------
global nnx nny node element pow updated_node count Lt Ht

nnx = 24;  % number of nodes in X-direction
nny = 30;  % number of nodes in Y-direction
upper_disp_node = 553;   % node to prescribe displacement in positive y-direction
lower_disp_node = 145;    % node to prescribe displacement in negative y-direction

Lt = 36.41;   % length of the plate
Ht = 38.2;   % hight of the plate
T0 = 8;    % Initial thickness of the plate

%----- Crack data--------------
a = 16.11;  % Left Crack length
angle = 0;    % Inclination angle in degree for left crack
alpha = pi*angle/180;    % Inclination angle in radian for left crack
xedge = 0;
yedge = Ht/2;
xCr   = [ xedge yedge; xedge+a*cos(alpha) yedge+a*sin(alpha)];   % crack coordinates
xTip  = [xedge+a*cos(alpha) yedge+a*sin(alpha)];   % crack tip coordinates
seg   = xCr(2,:) - xCr(1,:);     % tip segment
QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
XTIP = [xedge yedge];
ytip = yedge;

% +++++++++++++++++++++++++++++++++++++
%            MESH GENERATION
% +++++++++++++++++++++++++++++++++++++
disp([num2str(toc),'MESH GENERATION'])

% Four corner points
pt1 = [0 0] ;
pt2 = [Lt 0] ;
pt3 = [Lt Ht] ;
pt4 = [0 Ht] ;

elemType = 'Q4' ;   % type of element used for meshing
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);
numnode = size(node,1);  % total number of nodes in mesh
xtip = a;
numelem = size(element,1);   % total number of elements in mesh

uln = nnx*(nny-1)+1;   % upper left node number
urn = nnx*nny;    % upper right node number
lrn = nnx;     % lower right node number
lln = 1;    % lower left node number
cln = nnx*(nny-1)/2+1;    % node number at (0,0)

topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';
dispNodes   = unique(botEdge);  % displacement nodes
tracNodes   = unique(topEdge);  % traction nodes

%++++++++++++++ Material properties ++++++++++++++++++
E  = 207e3 ;    % Modulus of Elasticity
nu = 0.30 ;    % Poission's Ratio
Sy02 = 333;    % Yield strength
Su = 475;    % Ultimate strength
mu = 0.5*E/(1+nu);    %Shear modulus
KK = E/(3*(1-2*nu));    %Bulk Modulus
Jic = 390;
Sy01 = 5000;
%Value of hardening parameters
H = 3260;   %Linear Hardening
beta = 0; pow = 0;

if(MaterialModel==2)
    beta = 26;    %Ramberg's Osgood Material Model
    pow  = 1.0;
end

%--------PLANE_STRESS Compliance matrix C ------------
if ( strcmp(stressState,'PLANE_STRESS') )
    D = E/(1-nu^2)*[1 nu 0 0;
        nu 1  0 0;
        0 0 0.5*(1-nu) 0;
        0 0 0 1];
    C = D(1:3,1:3);
else
    D = E/((1+nu)*(1-2*nu))*[1-nu nu 0 nu;
        nu 1-nu 0 nu;
        0 0 0.5-nu 0;
        nu nu 0 1];
    C = D(1:3,1:3);
end

% %+++++++++++++++++++++++++++++++++++++
%        LEVEL SET INITIALIZATION
%      SELECTION OF ENRICHED NODES
% % +++++++++++++++++++++++++++++++++++++

% FOR LEFT EDGE CRACK
%===========================================================
disp([num2str(toc),'   LEVEL SET INITIALIZATION'])
split_elem = 0;
tip_elem = 0;
x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
ls=zeros(numnode,2);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;           % normal LS
    ls(i,2) = ([x y]-xTip)*t';     % tangent LS
end

enrich_node = zeros(numnode,1);
count1 = 0;
count2 = 0;
count3 = 0;
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) < 0
            count1 = count1 + 1 ; % one split element
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % one tip element
            tip_elem(count2) = iel;
            enrich_node(sctr)   = 2;
        elseif min(psi)>0
            count3 = count3 + 1 ; % one fictitious element
            split_elem_fictitious(count3) = iel;
            enrich_node([sctr(1,2) sctr(1,3)])   = 3;
        end
    end
end

split_nodes = find(enrich_node == 1);
tip_nodes   = find(enrich_node == 2);
split_nodes_fictitious = find(enrich_node == 3);

Felement1 = union(split_elem,tip_elem);
Felement = union(Felement1,split_elem_fictitious);  % total enrich elements without repetition
Fnodes1 = union(split_nodes,tip_nodes);
Fnodes = union(Fnodes1,split_nodes_fictitious); % total enrich nodes without repetition

% stiff_elem = [274 275 313 314 352 353 391 392 1405 1406 1444 1445 1483 1484 1522 1523 ];
stiff_elem = [93 94 116 117 139 140 162 163 483 484 507 508 530 531 553 554];
% stiff_elem = [442 443 491 492 540 541 589 590 2255 2256 2304 2305 2353 2354 2402 2403];

% Plot mesh and enriched nodes to check
figure
hold on
grid on
plot_mesh(node,element,elemType,'b-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rh');
n3 = plot(node(split_nodes_fictitious,1),node(split_nodes_fictitious,2),'rs');
set(n1,'MarkerSize',10);
set(n2,'MarkerSize',10);
set(n3,'MarkerSize',5);
set(gcf, 'color', 'white');
axis equal
axis off

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(split_nodes_fictitious,1)*1*2 + size(tip_nodes,1)*4*2;

pos = zeros(numnode,1);
enrich_node(split_nodes (:,1)) = 1;
enrich_node(tip_nodes(:,1))    = 2;
enrich_node(split_nodes_fictitious (:,1)) = 3;
nsnode = 0 ;
ntnode = 0 ;
nfnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1)
        pos(i) = (numnode + nsnode*1 + ntnode*4 + nfnode*1) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4 + nfnode*1) + 1 ;
        ntnode = ntnode + 1 ;
    elseif (enrich_node(i) == 3)
        pos(i) = (numnode + nsnode*1 + ntnode*4 + nfnode*1) + 1 ;
        nfnode = nfnode + 1 ;
    end
end

fict = pos(find(enrich_node==3)); % position number of fictitious nodes
ns_elem = length(split_elem);

numgpt = 0;  igp=0; numgpt1=0; numgpt2=0;
for iel = 1:numelem
    sctr = element(iel,:);   % element connectivity
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))   % split element
        order = 10 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    elseif (ismember(iel,tip_elem))   % tip element
        order = 10 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    elseif (ismember(iel,split_elem_fictitious))   % fictitious element
        order = 10 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    elseif (any(intersect(Fnodes,sctr)) ~= 0)   % having total enrich nodes (split + tip + fictitious)
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
    for kk = 1 : size(W,1)
        numgpt = numgpt + 1;
        gpnt = Q(kk,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:); % global GP
        gpt(numgpt,:) = Gpnt;
        
        if (ismember(iel,stiff_elem))
            numgpt1 = numgpt1+1;
            Cmat1(1:3,1:3,numgpt1) = C(1:3,1:3);
            Yield1 = Sy01*ones(numgpt1,1);
        else
            numgpt2 = numgpt2+1;
            Cmat2(1:3,1:3,numgpt2) = C(1:3,1:3);
            Yield2 = Sy02*ones(numgpt2,1);
        end
        
    end
end

% % Plot GPs for checking
figure
hold on
plot_mesh(node,element,elemType,'b-');
plot(gpt(:,1),gpt(:,2),'r*');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
set(gcf, 'color', 'white');
axis equal
axis off

% SELECTION OF ZERO STRESS GAUSS POINTS
%===========================================================
x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
gpd=zeros(numgpt,2);
for i = 1 : numgpt
    x = gpt(i,1);
    y = gpt(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    gpd(i,1) = phi/l;           % normal LS
    gpd(i,2) = ([x y]-xTip)*t';     % tangent LS
end

half_elem_length = Ht/(2*(nny-1));
zero_stress_gp = find((gpd(:,1)>=-half_elem_length)&(gpd(:,1)<=half_elem_length)&(gpd(:,2)<=0));
% stress(:,zero_stress_gp)=0;

% ------------------------------------------------
%       Intialization of variables
%-------------------------------------------------
if(strcmp(PlasticityModel,'RADIALRETURN'))
    stress = zeros(3,numgpt);
    S_prev = zeros(3,numgpt);    % stress of previous load
else
    stress = zeros(4,numgpt);
    S_prev = zeros(4,numgpt);    % stress of previous load
end

% Yield = Sy0*ones(numgpt,1);
T = T0*ones(numgpt,1);  %Initial thickness at each GP
strain = zeros(4,numgpt);
strain_e = zeros(4,numgpt);  % elastic strain
strain_p = zeros(4,numgpt);  % plastic strain
Sn_prev = zeros(4,numgpt);   % strain of previous load
Seff = zeros(numgpt,1);      % effective stress
Strn_p = zeros(numgpt,1);    %Effective plastic strain
Strn_p_prev = zeros(numgpt,1);    % plastic strain of previous load
strain_prev = zeros(4,numgpt);
rp = zeros(numgpt,1);   %Hardening function
fint = zeros(total_unknown,1);
%------------------------------------------------
J_final = [0];    % to store J-integral value of every load step
def_x = [0];      % to store X-dir. deflection value of every load step
def_y = [0];      % to store Y-dir. deflection value of every load step
reactn = [0];     % to store reaction value of every load step
Eq_Ss = [0];      % to store equivalent stress value of every load step
Eq_Sn = [0];      % to store equivalent strain value of every load step
Eq_Snp = [0];
c = a/2;    % controls the size of J domain
desired_node1 = nnx*(nny/2)+1;%nnx*(nny/2)+1;      % desired node for plotting
desired_node2 = nnx*(nny/2-1)+1;
desired_gp = 213;      % desired gauss point for plotting
req_gpt = zeros(numgpt,1);
%------Cummulative Displacements --------
ux = zeros(numnode,1);
uy = zeros(numnode,1);
ut = zeros(total_unknown,1);
dut = zeros(total_unknown,1);
updated_node = node;
updated_node1 = node;

count=0;
for i_load = 1:ITER  %Loop over load steps
    count = count + 1
    %     ubar = ubar1(i_load);
    fint = zeros(total_unknown,1);
    
    itno = 0;
    del_W = 100;
    while(abs(del_W)>1e-3) % NEWTON RAHPSON loop to iterate within the load step
        itno = itno +1;
        
        % ------------------------------------------------
        %       Global Stiffness matrix Computation
        %-------------------------------------------------
        Stiffness_Matrix;
        
        K = Kmat + Kgeo;      %total stiffness matrix
        f = - fint;      %total force matrix
        
        % ------------------------------------------------
        %       Imposing Essential Boundary Conditions
        %-------------------------------------------------
        disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])
        
        Kres = K;
        bcwt = 1;
        %         bcwt1 = mean(diag(K)); % a measure of the average size of an element in K, used to keep the conditioning of the K matrix
        dispn = [nnx*(nny/2) nnx*(nny/2+1)];
        vdofs = dispn.*2;
        udofs = dispn.*2-1; % for lower left/right corner node
        
        Kres(udofs,:) = 0;   % zero out the rows and columns of the K matrix
        Kres(vdofs,:) = 0;
        Kres(:,udofs) = 0;
        Kres(:,vdofs) = 0;
        Kres(udofs,udofs) = bcwt*speye(length(udofs));   % put ones*bcwt on the diagonal
        Kres(vdofs,vdofs) = bcwt*speye(length(vdofs));
        
        % Fictitious dofs
        fict_u = fict.*2-1;
        fict_v = fict.*2;
        bcwt_fict = mean(diag(K)); % used to maximize the K value at fictitious dofs
        Kres(fict_u,:) = 0;   % zero out the rows and columns of the K matrix
        Kres(fict_v,:) = 0;
        Kres(:,fict_u) = 0;
        Kres(:,fict_v) = 0;
        Kres(fict_u,fict_u) = bcwt_fict*speye(length(fict_u));   % put ones*bcwt_fict on the diagonal
        Kres(fict_v,fict_v) = bcwt_fict*speye(length(fict_v));
        
        %------ specified displacement boundary condition ------------
        vgiven_u = upper_disp_node.*2;
        Kres(vgiven_u,:) = 0; Kres(:,vgiven_u) = 0;
        Kres(vgiven_u,vgiven_u) = bcwt*speye(length(vgiven_u));
        vgiven_l = lower_disp_node.*2;
        Kres(vgiven_l,:) = 0; Kres(:,vgiven_l) = 0;
        Kres(vgiven_l,vgiven_l) = bcwt*speye(length(vgiven_l));
        
        if itno==1
            for kk = 1:total_unknown
                for ll = 1:length(vgiven_u)
                    zz = vgiven_u(ll);
                    f(kk) = f(kk) - K(kk,zz)*ubar;
                end
                
                for ll = 1:length(vgiven_l)
                    zz = vgiven_l(ll);
                    f(kk) = f(kk) + K(kk,zz)*ubar;
                end
            end
        end
        
        f(fict_u) = 0 ;  % force corresponding to fictitious dofs
        f(fict_v) = 0 ;
        
        f(udofs) = 0 ;  % force corresponding to constraint dofs
        f(vdofs) = 0 ;
        
        if itno == 1
            f(vgiven_u) = ubar;
            f(vgiven_l) = -ubar;
        else
            f(vgiven_u) = 0;
            f(vgiven_l) = 0;
        end
        
        % -------------------------
        %       Solution
        %--------------------------
        disp([num2str(toc),'   SOLUTION'])
        du   = Kres\f;
        
        dux = du(1:2:2*numnode) ;
        duy = du(2:2:2*numnode) ;
        
        ux = ux + dux;
        uy = uy + duy;
        ut = ut + du;
        u_x = ut(1:2:2*numnode) ;
        u_y = ut(2:2:2*numnode) ;
        
        %------------updating nodes------------
        if(strcmp(NODE_UPDATE,'YES'))
            updated_node1(:,1) = updated_node1(:,1) + dux;
            updated_node1(:,2) = updated_node1(:,2) + duy;
        else
        end
        
        % -------------------------------------
        %       Stress computation
        %--------------------------------------
        disp([num2str(toc),'      Stress computation at nodes'])
        Stress_Computation;
        
        del_W = (-fint)'*du;
        del_W
        count
        itno
        
    end %End of Newton Raphson loop
    
    % -------------------------------------
    %       Crack Tip Updation
    %-------------------------------------
    if(strcmp(TIP_UPDATE,'YES'))
        Crack_Tip_Update;
    else
    end
    
    % -------------------------------------
    %       J Integral computation
    %-------------------------------------
    J_Integral_new;
    J_final = [J_final Jint];
    
    % -------------------------------------
    %       Node Updation
    %-------------------------------------
    if(strcmp(NODE_UPDATE,'YES'))
        updated_node = updated_node1;  % Updated nodes after N.R. Loop
    else
    end
    
    % ----------------------------------------------
    %       Storage of Variables for plotting
    %-----------------------------------------------
    Eq_Ss = [Eq_Ss;Seff(desired_gp,1)];
    Eq_Sn = [Eq_Sn;strn_eff(desired_gp,1)];
    %     Eq_Snp = [Eq_Snp;u1]; %Effective Plastic strain
    def_x = [def_x;(ut(2*upper_disp_node))];
    def_y = [def_y;abs(ut(2*desired_node1))+abs(ut(2*desired_node2))]
    reactn = [reactn sum(fint(lower_disp_node*2))];
    ab = find(Seff(:,1)>=Sy0);
    
    if  Jint>=Jic
        Jic = Jic + 125;
        a = a + 0.25;
        New_Mesh_Data
    end
    
end %End of load step loop

% Plot numerical deformed configuration
figure
hold on
fac = 1;
% plot_mesh(node,element,elemType,'b-');
% cr = plot(xCr(:,1),xCr(:,2),'r-');
% set(cr,'LineWidth',3);
plot_mesh(updated_node+fac*[u_x u_y],element,elemType,'r-');
title(' Numerical deformed configuration ')
set(gcf, 'color', 'white');
axis on

% Plot GPs for checking
figure
hold on
plot_mesh(updated_node,element,elemType,'b-');
plot(gpt(ab,1),gpt(ab,2),'r.');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',2);
title(' Plastic Zone ')
set(gcf, 'color', 'white');
axis equal
axis on

% Reaction vs def_y plot
figure
hold on
grid on
plot(abs(def_y),abs(reactn),'b-o','LineWidth',0.5, 'MarkerFaceColor','r','MarkerEdgeColor','k','MarkerSize',5)
xlabel('Displacement(mm)');
ylabel('Reaction(N)');
hold off

% Eq stress-strain plot
figure
hold on
plot(Eq_Sn,Eq_Ss,'ko-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','m','MarkerSize',5);
xlabel('Eq Strain');
ylabel('Eq Stress(MPa)');
set(gcf, 'color', 'white');
grid on
axis on

% J vs Aplied load
figure
hold on
plot(abs(reactn),J_final,'ro-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','m','MarkerSize',5);
xlabel('Applied Load (N)');
ylabel('J(MPa.mm)');
set(gcf, 'color', 'white');
grid on
axis on
hold on

% Eq Stress Plot
figure
hold on
tri = delaunay(gpt(:,1),gpt(:,2));
patch('Vertices',gpt,'Faces',tri,'FaceVertexCData',Seff);
colorbar
shading interp
set(gcf, 'color', 'white');
axis equal
axis off
