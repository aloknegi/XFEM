% J vs Aplied load

figure
hold on

% Data P = 16000N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,5),'bo-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data P = 16500N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,6),'bo-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data P = 17000N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,7),'bs-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data P = 17500N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,8),'bd-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data P = 18000N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,9),'bv-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data P = 18200N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,10),'bp-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data P = 18500N
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,11),'b^-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

% Data J-R Curve
load DATA_J_R_plot.mat
plot(DATA_J_R(:,1),DATA_J_R(:,12),'mo-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5);

legend('P = 16KN','P = 16.5KN','P = 17KN','P = 17.5KN','P = 18K7182N','P = 18.2KN','P = 18.5KN','J-R Curve','location','NorthWest');

xlabel('da (mm)');
ylabel('J(MPa.mm)');
set(gcf, 'color', 'white');
grid on
axis on

