function plotContour(stress)

global nnx nny node element

numnode = size(node,1);
numelem = size(element,1);

X = zeros(nnx,nny); Y = X; Z = X;

% Average nodal values if not already done

    stressXX = stress(:,:,1); stressXY = stress(:,:,3); stressYY = stress(:,:,2);
    Sxx = zeros(numnode,2); Sxy = Sxx; Syy = Sxx;

    % Construct stress vectors
    for iE = 1:(numelem)
        for iN = 1:4
            sctr = element(iE,:);
            nNode = sctr(iN);
            Sxx(nNode,:) = Sxx(nNode,:) + [stressXX(iE,iN) 1];
            Sxy(nNode,:) = Sxy(nNode,:) + [stressXY(iE,iN) 1];
            Syy(nNode,:) = Syy(nNode,:) + [stressYY(iE,iN) 1];
        end
    end

    % Average nodal stress values
    Sxx(:,1) = Sxx(:,1)./Sxx(:,2); Sxx(:,2) = [];
    Sxy(:,1) = Sxy(:,1)./Sxy(:,2); Sxy(:,2) = [];
    Syy(:,1) = Syy(:,1)./Syy(:,2); Syy(:,2) = [];


% Plot the contours
for i = 1:3
    figure; hold on;
    if i == 1
        z = Sxx;
        title('\sigma_x_x')
    elseif i == 2
        z = Sxy;
        title('\sigma_x_y')
    elseif i == 3
        z = Syy;
        title('\sigma_y_y')
    end

    iNode = 1;
    for yE = 1:(nny)
        for xE = 1:(nnx)
            X(xE,yE) = node(iNode,1);
            Y(xE,yE) = node(iNode,2);
            Z(xE,yE) = z(iNode);
            iNode = iNode+1;
        end
    end

    contourf(X,Y,Z,40,'LineStyle','none');
    colorbar; xlabel('X'); ylabel('Y');
    set(gcf, 'color', 'white');
    axis equal; axis off; hold off;
end

end