function[S4,Sn_e,Sn_p,strn_p,Seff_red,rt,Dep] = stress_petrinic_new(Sn_e,dSn4,Sn_p,strn_p,D,Sy0,rt,E,mu,KK,beta,pow,MaterialModel)

% Elastic trial stress
Sn_tr = Sn_e+dSn4;%trial inplane strain
sigma_tr = D*Sn_tr;%Elastic predictor based on plane stress condition
S4 = sigma_tr;
[sigma_d p J2d] = Sdevia(S4);
sigma_tr_eff = sqrt(3*J2d);
Sy = Sy0+rt;%Current Yield surfece
Yieldfn_tr = sigma_tr_eff - 3*mu*Sn_p- rt - Sy0;
if (Yieldfn_tr <= 0)
    S4 = sigma_tr;
    Sn_e = Sn_tr;
    Dep = D;
    %--- Calculating Seff (for plotting only)---
    [sigma_d p J2d] = Sdevia(S4);
    Seff_red = sqrt(3*J2d); % equivalent stress or Von-Mises stress
else
%     r0 = rt;
%     dp = 0;
    RES =Yieldfn_tr;
    while(abs(RES)>1e-5)
        if(MaterialModel==2)%Ramberg's Osgood Material model
            H = E/(beta*pow*(Sy0^(1-pow))*(Sy^(pow-1)));%Hardening Modulus
        end
        RES = sigma_tr_eff - 3*mu*Sn_p - rt - Sy0;
        Sn_p = Sn_p + RES/(3*mu+H);
        rt = rt + H*Sn_p;
    end
    strn_p = strn_p + (3/2)*(Sn_p/sigma_tr_eff)*(sigma_d);
    sigma = sigma_tr - 2*mu*strn_p;
    [Dep]=D_matrix(sigma,mu,H,KK,sigma_tr);
    C = inv(D);
    S4 = sigma;
    Sn_e = C*S4;%Inplane Elastic Strain
%     Snp_eff = Snp_eff + dp;
    [sigma_d p J2d] = Sdevia(S4);
    Seff_red = sqrt(3*J2d);
end
end




