function [Tdomain,radius] = Tdomain_old(radius,xTip_n)

global node element updated_node

numnode = size(node,1);
center = xTip_n;
r=[];
% Distance from the center of tip element
for i = 1 : numnode
    sctr = node(i,:);
    rho  = sqrt((sctr(1)-center(1))^2+(sctr(2)-center(2))^2);
    r    = [r,rho];
end
test = r-radius;
test = test(element)';
Tdomain =find(any(test<=0));