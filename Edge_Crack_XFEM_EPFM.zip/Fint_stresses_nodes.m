
% SELECTION OF ZERO STRESS GAUSS POINTS
%===========================================================

stress_centre = zeros(3,numelem);
no_elem = 0; igp = 0;
for iel = 1:numelem
    sctr = element(iel,:);     % element connectivity
    no_elem = no_elem + 1;
    stress1 = zeros(3,1);
    
    % Choose Gauss quadrature rules for elements
   if (ismember(iel,split_elem))   % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,tip_elem))   % tip element
        order =2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,split_elem_fictitious))   % fictitious element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (any(intersect(Fnodes,sctr)) ~= 0)   % having total enrich nodes (split + tip + fictitious)
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
    igp2 = 0;
    for kk = 1 : size(W,1)
        igp = igp + 1;
        igp2 = igp2 +1;
        stress1 =  stress1 + stress(:,igp);   
    end %End of loop over GP's
    
    x1=updated_node(sctr(1,1),1);
    y1=updated_node(sctr(1,1),2);
    x2=updated_node(sctr(1,2),1);
    y2=updated_node(sctr(1,2),2);
    x3=updated_node(sctr(1,3),1);
    y3=updated_node(sctr(1,3),2);
    x4=updated_node(sctr(1,4),1);
    y4=updated_node(sctr(1,4),2);
    d1 = sqrt((x1-x3)^2 + (y1-y3)^2);
    d2 = sqrt((x2-x4)^2 + (y2-y4)^2);
    area_elem(iel) = (d1*d2)/2; % area of elements
    
    stress_centre(:,no_elem) = stress1/igp2;
    
end %End of loop over elements

sum_stress = [];
stress_node = zeros(3,numnode);

for ii = 1:numnode
    ll=0;
    for jj = 1:numelem
        sctrr = element(jj,:);
        if (ismember(ii,sctrr))
            ll = ll+1;
            kk(ll) = jj;
        end
    end
    sum_stress = zeros(3,1);
    total_area = zeros(1,1);
    for mm = 1:length(kk)
        pp = kk(:,mm);
        sum_stress = sum_stress + stress_centre(:,pp)*area_elem(pp);
        total_area = total_area + area_elem(:,pp);
    end
    stress_node(:,ii) = sum_stress/total_area;
end
stress_y1 = (stress_node(2,:))';
plotContour_new(stress_node)




