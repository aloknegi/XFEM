function Cep = Cep_PSs(P,Sigma,H,C,delta_gama)

xi = Sigma'*P*Sigma;
EE = inv(C+delta_gama*P);
n = EE*P*Sigma;
alpha = 1/(Sigma'*P*n+2*xi*H/(3-2*H*delta_gama));
Cep = EE-alpha*n*n';
end
