% -------------------------------------------
%  J Integral computation for left edge crack
% -------------------------------------------
[Jdomain,qnode,radius] = Jdomain_new(c,xTip);

% % plot
% figure
% hold on
% cntr = plot([0,Lt,Lt,0,0],[0,0,Ht,Ht,0]);
% set(cntr,'LineWidth',2);
% % plot the circle
% theta = -pi:0.1:pi;
% xo = xTip(1) + radius*cos(theta) ;
% yo = xTip(2) + radius*sin(theta) ;
% plot(xo,yo,'k-');
% plot_mesh(node,element,'Q4','b-')
% plot_mesh(node,element(Jdomain,:),'Q4','g-')
% cr = plot(xCr(:,1),xCr(:,2),'k-');
% set(cr,'LineWidth',2);
% set(gcf, 'color', 'white');
% axis equal
% axis off

Jint=0;ind=0;ind1=0;
for iel = 1 : numelem
    sctr = element(iel,:);
    
     % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))   % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,tip_elem))   % tip element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,split_elem_fictitious))   % fictitious element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (any(intersect(Fnodes,sctr)) ~= 0)   % having total enrich nodes (split + tip + fictitious)
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
    if (ismember(iel,Jdomain))
        ind1=ind1+1;
    end
    
    for ij = 1:size(W,1)
        ind=ind+1;
        
        if (ismember(iel,Jdomain))
            pt = Q(ij,:);
            wt = W(ij);
            [N,dNdxi] = lagrange_basis(elemType,pt);
            J0    = updated_node(sctr,:)'*dNdxi;
            invJ0 = inv(J0);
            dNdx  = dNdxi*invJ0;
            
            [B,J0] = xfemBmatrix_LEFM(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
            
            leB = size(B,2);
            
            U = element_disp(iel,pos,enrich_node,ut);
            
            % compute derivatives of u w.r.t xy
            HH(1,1) = B(1,1:2:leB)*U(1:2:leB);    % u,x
            HH(1,2) = B(2,2:2:leB)*U(1:2:leB);    % u,y
            HH(2,1) = B(1,1:2:leB)*U(2:2:leB);    % v,x
            HH(2,2) = B(2,2:2:leB)*U(2:2:leB);    % v,y
            
            % ++++++++++++++
            % Gradient of q
            % ++++++++++++++
            q     = qnode(ind1,:);
            gradq = q*dNdx;
            % ++++++++++++++
            % Stress at GPs
            % ++++++++++++++
            
            epsilon = strain(1:3,ind);
            sigma = stress(1:3,ind);
            
            % +++++++++++++++++++++++++++++++++++
            % Transformation to local coordinate
            % +++++++++++++++++++++++++++++++++++
            
            voit2ind    = [1 3;3 2];
            gradqloc    = QT*gradq';
            graddisploc = QT*HH*QT';
            stressloc   = QT*sigma(voit2ind)*QT';%current local stress tensor
            
            epsilon_n=[epsilon(1,1); epsilon(2,1); epsilon(3,1)/2];  %[epsxx epsyy epsxy]
            Eps_loc = epsilon_n(voit2ind); %local incremental strain tensor
            
            % +++++++++++++++
            %   J integral
            % +++++++++++++++
            
            dSEnergy = 0;
            for i=1:2
                for j=1:2
                    dSEnergy = dSEnergy + stressloc(i,j)*Eps_loc(i,j); %(sigam(ij)*dstrain(ij))
                end
            end
            
            J1= (stressloc(1,1) * graddisploc(1,1) + stressloc(2,1) * graddisploc(2,1) ) * gradqloc(1) + ...
                (stressloc(1,2) * graddisploc(1,1) + stressloc(2,2) * graddisploc(2,1) ) * gradqloc(2);
            Jint = Jint + (J1-dSEnergy*gradqloc(1))*det(J0)*wt;
        end
    end  %End of quadrature loop
end  %End of loop over elements
Jint
