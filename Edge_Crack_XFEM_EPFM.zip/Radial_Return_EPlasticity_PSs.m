function[S4 Sn_p Seff_red Cep rt] = Radial_Return_EPlasticity_PSs(dSn4,dSs4,Ss4_prev,rt,G,K,H,Sy0,D,Sn_p,stressState)
% stressState
Ss4 = Ss4_prev + dSs4;%Total elastic stress predictor (trial stress)
% Based on trial stress , calculate following
[sigma_d_tr J2d] = Sdevia(Ss4);
Seff_tr = sqrt(3*J2d); % based on elastic stress predictor (Ss4 matrix)
Yieldfn = Seff_tr-(rt+Sy0);%trial yield function
if(Yieldfn > 0)%whether yielding actively
    State = 2;%represents plastic state 
%     display('Plastic')
    delta_p = 0;%increment in effective plastic strain Sn_p
    rk = rt;
    Res_Yfn = Yieldfn;%Residual yield function initialisation
    while(Res_Yfn>1e-3)%to calculate incremnt in effective plastic strain iteratively
        rk = rt+H*delta_p;
        Res_Yfn = Seff_tr-3*G*delta_p-(rk+Sy0);%Residual yield function = trial yield function - some qty;f=Res_Yfn=0 for a plastic state
        d_delta_p = Res_Yfn/(3*G+H);        
        delta_p = delta_p + d_delta_p;%new value of delta_p        
    end
    rt = rk;
else    
    delta_p = 0;
    State = 1;%represents elastic state 
%     display('Elastic')
end
%------Determine plastic and elastic strain increments and stress increment-----
dSn_p = 1.5*delta_p*sigma_d_tr(1:3)/Seff_tr;%increment in INPLANE plastic strain 
dSn_e = dSn4(1:3) - dSn_p;%increment in elastic INPLANE strain 
dsigma4(1:3,1) = D(1:3,1:3)*dSn_e;%increment in INPLANE stress 

dsigma4(4,1) = 0;

%----Update all quantities to the end of time increment---------
S4 = Ss4_prev + dsigma4;%stress reduced to yield surface
Sn_p = Sn_p + delta_p;%effective plastic strain (p in literature)

%---Calculating final effective stress--------
% [sigma_d J2d] = Sdevia(S4);
% Seff = sqrt(3*J2d);%final effective stress
Seff = Seff_tr-3*G*delta_p;

%-----Calculation of material jacobian matrix-------
if(State == 2)
    R = Seff/Seff_tr;
    Q = 1.5*((1/(1+3*G/H)) - R);
    A = 2*G*Q/Seff_tr^2;
    B = K-2*G*R/3;
%     Dep = zeros(4);
    % Please note that the order of stresses in the stress vector is sigma xx yy xy zz
    Dep(1,1) = A*sigma_d_tr(1,1)*sigma_d_tr(1,1) + 2*G*R + B;
    Dep(1,2) = A*sigma_d_tr(1,1)*sigma_d_tr(2,1) +  B;
    Dep(1,3) = A*sigma_d_tr(1,1)*sigma_d_tr(3,1);% for multiplying with epsilon xy    
    
    Dep(2,1) = A*sigma_d_tr(2,1)*sigma_d_tr(1,1) +  B;
    Dep(2,2) = A*sigma_d_tr(2,1)*sigma_d_tr(2,1) + 2*G*R + B;
    Dep(2,3) = A*sigma_d_tr(2,1)*sigma_d_tr(3,1);% for multiplying with epsilon xy    
    
    Dep(3,1) = A*sigma_d_tr(3,1)*sigma_d_tr(1,1);
    Dep(3,2) = A*sigma_d_tr(3,1)*sigma_d_tr(2,1);
    Dep(3,3) = A*sigma_d_tr(3,1)*sigma_d_tr(3,1)+ G*R ;% for multiplying with epsilon xy
    Cep = Dep;
else
    Cep = D(1:3,1:3);
end
Seff_red = Seff;
end







