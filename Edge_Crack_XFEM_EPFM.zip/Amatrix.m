function A = Amatrix(E,mu,nu,delta_gama)
Astar = zeros(3);
Astar(1,1) = 3*(1-nu)/(3*(1-nu)+E*delta_gama);
Astar(2,2) = 1/(1+2*mu*delta_gama);
Astar(3,3) = Astar(2,2);

A = zeros(3);
A(1,1) = (Astar(1,1)+Astar(2,2))/2;
A(1,2) = (Astar(1,1)-Astar(2,2))/2;
A(2,1) = A(1,2);
A(2,2) = A(1,1);
A(3,3) = Astar(3,3);
end