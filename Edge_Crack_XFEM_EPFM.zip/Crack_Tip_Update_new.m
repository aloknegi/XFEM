%----------- Co-ordinates of Crack tip --------
tip_sctr = element(Exact_tip_elem,:);
front_sctr = [(nnx*((nny/2)-1)+1)  (nnx*((nny/2)-1)+2)  (nnx*(nny/2)+2)  (nnx*(nny/2)+1)];

% crack tip nodes displacements
Tip_u = updated_node1(tip_sctr,:);
Tip_U = updated_node1(tip_sctr,:) - updated_node(tip_sctr,:); % change in crack tip nodes displacement

% crack front nodes displacements
front_u = updated_node1(front_sctr,:);
front_U = updated_node1(front_sctr,:) - updated_node(front_sctr,:); % change in crack tip nodes displacement

%----------------------------------------------------------------------
%        ITERATION METHOD TO CALCULATE LOACAL ZETA & ETA
%----------------------------------------------------------------------

%------------LOOP FOR CRACK TIP-------------

range1 = linspace(-1,1,251);%-1:0.05:1; % range of zeta and eta for iteration
it = length(range1);
IT=it;
for kk=1:IT;   % loop over zeta
    xi = range1(kk);
    for jj = 1:it;  % loop over eta
        eta = range1(jj);
        pt = [xi eta];
        [N,dNdxi]=lagrange_basis('Q4',pt);
        tip = N' * Tip_u; 
        Dist = sqrt((xCr(2,1)-tip(1,1))^2 + (xCr(2,2)-tip(1,2))^2);  % distance between crack tip and iterative node
        Distance(jj,1) = Dist;  % storage of distance   
        G_tip1(jj,:) = pt;  % zeta and eta value for current iteration
    end % end of loop over eta
    
    distance = min(Distance);  % minimum distance
    min_dist(kk,1) = distance;
    local_num = find(Distance==distance);
    G_tip2(kk,:) = G_tip1(local_num,:);
end   % end of loop over zeta

MIN_dist = min(min_dist);   % minimum distance b/t tip and local node
T_node = find(min_dist==MIN_dist);
G_tip = G_tip2(T_node,:);  % crack tip in local co-ordinate system

clear min_dist; clear local_num; clear Distance; clear G_tip2;
%------------LOOP FOR CRACK FRONT-------------

range2 = linspace(-1,1,251);%-1:0.05:1; % range of zeta and eta for iteration
IT = length(range2);
it = IT;
for jj = 1:it
    xi = range2(jj);
    for kk=1:IT;   % loop over eta
    
        eta = range2(kk);
        pt = [xi eta];
        [N,dNdxi]=lagrange_basis('Q4',pt);
        front = N' * front_u;
        Dist = sqrt((xCr(1,1)-front(1,1))^2 + (xCr(1,2)-front(1,2))^2);  % distance between crack tip and iterative node
        Distance(kk,1) = Dist;  % storage of distance
        F_tip1(kk,:) = pt;  % zeta and eta value for current iteration
    end   % end of loop over eta
    distance = min(Distance);   % minimum distance b/t tip and local node
    min_dist(jj,1) = distance;
    local_num = find(Distance==distance);
    F_tip2(jj,:) = F_tip1(local_num,:);  % crack tip in local co-ordinate system
end

MIN_dist = min(min_dist);   % minimum distance b/t tip and local node
F_node = find(min_dist==MIN_dist);
F_tip = F_tip2(F_node,:);  % crack tip in local co-ordinate system

pt = G_tip;
[N,dNdxi]=lagrange_basis('Q4',pt);
Tip = N' * Tip_U;

pt = F_tip;
[N,dNdxi]=lagrange_basis('Q4',pt);
Front = N' * front_U;

xedge = xedge + Front(1,1);
yedge = yedge + Front(1,2);
xtip = xtip + Tip(1,1);
ytip = ytip + Tip(1,2);

xCr   = [ xedge yedge; xtip ytip];  % UPDATED xCr
xTip  = [xtip ytip];                % Updated crack tip
c = (sqrt((xCr(2,1)-xCr(1,1))^2+(xCr(2,2)-xCr(1,2))^2))/2; % UPDATED CRACK LENGTH


