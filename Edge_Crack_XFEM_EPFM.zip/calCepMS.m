function[MS ] = calCepMS(stress,stressState)

%  Cmat = Dmat(1:3,1:3);
MS(1,1)=stress(1);
MS(1,3)=stress(3);
MS(3,3)=stress(2);
MS(2,2)=MS(1,1);
MS(2,4)=MS(1,3);
MS(3,1)=MS(1,3);
MS(4,2)=MS(1,3);
MS(4,4)=MS(3,3);
if ( strcmp(stressState,'AXI_SYM'))
%     Cmat = Dmat;
    MS(5,:)=0;
    MS(:,5)=0;
    MS(5,5)=stress(4);
end
