% Calculation of nodal stresses and internal forces from nodal stresses

global nnx nny node element pow updated_node count Lt Ht

%----- Crack data--------------
angle = 0;    % Inclination angle in degree for left crack
alpha = pi*angle/180;    % Inclination angle in radian for left crack
xedge_n = 0;
yedge_n = Ht/2;
xCr_n   = [ xedge_n yedge_n; xedge_n+a*cos(alpha) yedge_n+a*sin(alpha)];   % crack coordinates
xTip_n  = [xedge_n+a*cos(alpha) yedge_n+a*sin(alpha)];   % crack tip coordinates
seg   = xCr_n(2,:) - xCr_n(1,:);     % tip segment
QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
XTIP = [xCr(1,1) xCr(1,2)];
ytip = xTip(1,2);
xtip = xTip(1,1);

% %+++++++++++++++++++++++++++++++++++++
%        LEVEL SET INITIALIZATION
%      SELECTION OF ENRICHED NODES
% % +++++++++++++++++++++++++++++++++++++

% FOR LEFT EDGE CRACK
%===========================================================
disp([num2str(toc),'   LEVEL SET INITIALIZATION'])
split_elem = 0;
tip_elem = 0;
x0  = xCr_n(1,1); y0 = xCr_n(1,2);
x1  = xCr_n(2,1); y1 = xCr_n(2,2);
tt   = 1/norm(seg)*seg;
ls=zeros(numnode,2);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;           % normal LS
    ls(i,2) = ([x y]-xTip_n)*tt';     % tangent LS
end

[Tdomain,Tradius] = Tdomain_old(Tradius,xTip_n);

enrich_node = zeros(numnode,1);
count1 = 0; count4 = 0;
count2 = 0;
count3 = 0;
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    if (ismember(iel,Tdomain))
        count1 = count1 + 1 ; % one tip element
        tip_elem(count1) = iel;
        enrich_node(sctr)   = 2;
        if max(psi)*min(psi) < 0 && ( max(phi)*min(phi) < 0 )
            count4 = count4 + 1 ; % Actual tip element
            Exact_tip_elem(count4) = iel;
        end
    else
        if( max(phi)*min(phi) < 0 )
            if max(psi) < 0
                count2 = count2 + 1 ; % one split element
                split_elem(count2) = iel;
                enrich_node(sctr)   = 1;
            elseif min(psi)>0
                count3 = count3 + 1 ; % one fictitious element
                split_elem_fictitious(count3) = iel;
                enrich_node([sctr(1,2) sctr(1,3)])   = 3;
            end
        end
    end
end

split_nodes = find(enrich_node == 1);
tip_nodes   = find(enrich_node == 2);
split_nodes_fictitious = find(enrich_node == 3);

Felement1 = union(split_elem,tip_elem);
Felement = union(Felement1,split_elem_fictitious);  % total enrich elements without repetition
Fnodes1 = union(split_nodes,tip_nodes);
Fnodes = union(Fnodes1,split_nodes_fictitious); % total enrich nodes without repetition

% Plot mesh and enriched nodes to check
figure
hold on
grid on
plot_mesh(node,element,elemType,'b-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rh');
n3 = plot(node(split_nodes_fictitious,1),node(split_nodes_fictitious,2),'rs');
set(n1,'MarkerSize',10);
set(n2,'MarkerSize',10);
set(n3,'MarkerSize',5);
set(gcf, 'color', 'white');
axis equal
axis off

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(split_nodes_fictitious,1)*1*2 + size(tip_nodes,1)*4*2;

pos = zeros(numnode,1);
enrich_node(split_nodes (:,1)) = 1;
enrich_node(tip_nodes(:,1))    = 2;
enrich_node(split_nodes_fictitious (:,1)) = 3;
nsnode = 0 ;
ntnode = 0 ;
nfnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1)
        pos(i) = (numnode + nsnode*1 + ntnode*4 + nfnode*1) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4 + nfnode*1) + 1 ;
        ntnode = ntnode + 1 ;
    elseif (enrich_node(i) == 3)
        pos(i) = (numnode + nsnode*1 + ntnode*4 + nfnode*1) + 1 ;
        nfnode = nfnode + 1 ;
    end
end




