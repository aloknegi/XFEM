function [sigma_d p J2d] = Sdevia(Stress_cauchy)

    p = (Stress_cauchy(1,1) + Stress_cauchy(2,1) + Stress_cauchy(4,1))/3;
    sigma_d = [Stress_cauchy(1,1)-p; Stress_cauchy(2,1)-p;Stress_cauchy(3,1);Stress_cauchy(4,1) - p];    
    J2d = (1/2)*(sigma_d(1,1)^2 + sigma_d(2,1)^2 + sigma_d(4,1)^2) + sigma_d(3,1)^2;
end