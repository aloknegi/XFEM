% -------------------------------------------
%  J Integral computation for left edge crack
% -------------------------------------------
[Jdomain,qnode,radius] = Jdomain_new(c,xTip);

% % plot
% figure
% hold on
% cntr = plot([0,Lt,Lt,0,0],[0,0,Ht,Ht,0]);
% set(cntr,'LineWidth',2);
% % plot the circle
% theta = -pi:0.1:pi;
% xo = xTip(1) + radius*cos(theta) ;
% yo = xTip(2) + radius*sin(theta) ;
% plot(xo,yo,'k-');
% plot_mesh(node,element,'Q4','b-')
% plot_mesh(node,element(Jdomain,:),'Q4','g-')
% cr = plot(xCr(:,1),xCr(:,2),'k-');
% set(cr,'LineWidth',2);
% set(gcf, 'color', 'white');
% axis equal
% axis off

Jint= 0;

for iel = 1 : size(Jdomain,2)
    e = Jdomain(iel) ; % current element
    sctr = element(e,:);
    
    %     Choose Gauss quadrature rule
    if (ismember(e,split_elem))     % split element
        order = 7 ;                 
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
    else
        order = 6 ;  
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    %     -----------------------------
    %     start loop over Gauss points
    %     -----------------------------
    for q = 1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        [N,dNdxi] = lagrange_basis(elemType,pt);
        J0    = updated_node(sctr,:)'*dNdxi;
        invJ0 = inv(J0);
        dNdx  = dNdxi*invJ0;
        Gpt = N' * updated_node(sctr,:);     % GP in global coord
        
        [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip,alpha);
        leB = size(B,2);
        
        % nodal displacement of current element
        % taken from the total nodal parameters u
        
        U = element_disp(e,pos,enrich_node,ut);
        
        % compute derivatives of u w.r.t xy
        HH(1,1) = B(1,1:2:leB)*U(1:2:leB);    % u,x
        HH(1,2) = B(2,2:2:leB)*U(1:2:leB);    % u,y
        HH(2,1) = B(1,1:2:leB)*U(2:2:leB);    % v,x
        HH(2,2) = B(2,2:2:leB)*U(2:2:leB);    % v,y
        
        % ++++++++++++++
        % Gradient of q
        % ++++++++++++++
        q     = qnode(iel,:);
        gradq = q*dNdx;
        % ++++++++++++++
        % Stress at GPs
        % ++++++++++++++
%         epsilon = B*U ;
%         sigma   = C*epsilon;
        sigma = stress(1:3,e);
        epsilon = strain(1:3,e);
        
        % +++++++++++++++++++++++++++++++++++
        % Transformation to local coordinate
        % +++++++++++++++++++++++++++++++++++
        
        voit2ind    = [1 3;3 2];
        gradqloc    = QT*gradq';
        graddisploc = QT*HH*QT';
        stressloc   = QT*sigma(voit2ind)*QT';%current local stress tensor
        
        epsilon_n=[epsilon(1,1); epsilon(2,1); epsilon(3,1)/2];  %[epsxx epsyy epsxy]
        Eps_loc = epsilon_n(voit2ind); %local incremental strain tensor
        
        
        % +++++++++++++++
        %   J integral
        % +++++++++++++++
        
        dSEnergy = 0;
        for i=1:2
            for j=1:2
                dSEnergy = dSEnergy + stressloc(i,j)*Eps_loc(i,j); %(sigam(ij)*dstrain(ij))
            end
        end
        
        J1= (stressloc(1,1) * graddisploc(1,1) + stressloc(2,1) * graddisploc(2,1) ) * gradqloc(1) + ...
            (stressloc(1,2) * graddisploc(1,1) + stressloc(2,2) * graddisploc(2,1) ) * gradqloc(2);
        Jint = Jint + (J1-dSEnergy*gradqloc(1))*det(J0)*wt;
        
    end  %End of quadrature loop
end  %End of loop over elements
Jint
