function [a dD] = flowvector(sigma,D)
C1=0;
C2= sqrt(3);
C3 = 0;
[sigma_d p J2d] = Sdevia(sigma);

a1 = [1;1;0;1];
a2 = [sigma_d(1,1);sigma_d(2,1);2*sigma_d(3,1);sigma_d(4,1)]/(2*sqrt(J2d));
a3 = [sigma_d(2,1)*sigma_d(4,1) + J2d/3;
      sigma_d(4,1)*sigma_d(1,1) + J2d/3;
      -2*sigma_d(4,1)*sigma_d(3,1);
      sigma_d(1,1)*sigma_d(2,1)-sigma_d(3,1)^2 + J2d/3];
a = C1*a1 + C2*a2 + C3*a3;
dD = D*a;% or use eqn 7.77 or 7.78
end