function[strain sigma] = StressElastic(B,U,D,nu,E,stressState)
strain = zeros(4,1);%strain matrix
sigma = zeros(4,1);%stress matrix
C = D(1:3,1:3);
if ( strcmp(stressState,'AXI_SYM') )
    strain = B*U;% epsilon = B*U
    sigma = D*B*U;% sigma = D*epsilon = D*(B*U)
else
    strain(1:3,1) = B*U;% epsilon = B*U
    sigma(1:3,1) = C*B*U;% sigma = C*epsilon = C*(B*U)
    
    %------ 4th component of Stress and Strains ----------
    if ( strcmp(stressState,'PLANE_STRESS') )
        sigma_ze = 0;% stress in z dr is zero in plane stress
        strain_ze = -(nu/E)*(sigma(1,1)+ sigma(2,1));% strain in z dr exists in plane stress
    else
        sigma_ze = nu*(sigma(1,1)+ sigma(2,1));% stress in z dr exists in plane strain
        strain_ze = 0;% strain in z dr is zero in plane strain
    end
    sigma(4,1) = sigma_ze;%4th component of stress
    strain(4,1) = strain_ze;%4th component of strain
end