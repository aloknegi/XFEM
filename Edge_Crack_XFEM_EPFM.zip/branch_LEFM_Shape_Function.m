function [f,dfdx,dfdy] = branch_LEFM_Shape_Function(r,theta,alpha)

global pow
%  (r,theta) : polar coordinates of points where the branch
%              functions are to be evaluated
%   alpha    : inclination of the crack tip segment w.r.t x axis
% n=1/(1+pow);
if( r ~=0 )
    r2 = sqrt(r); % r^n;%
else
    r2    = 0.1d-4;
    theta = 0.0d0 ;
end

fac  = 0.5/r2 ;
st2  = sin(theta/2.);
ct2  = cos(theta/2.);
st   = sin(theta);
ct   = cos(theta);

drdx = cos(theta);
drdy = sin(theta);
dtdx = -sin(theta)/r;
dtdy = cos(theta)/r;

dxdX = cos(alpha);
dxdY = sin(alpha);
dydX = -sin(alpha);
dydY = cos(alpha);

drdX = drdx*dxdX + drdy*dydX;
drdY = drdx*dxdY + drdy*dydY;
dtdX = dtdx*dxdX + dtdy*dydX;
dtdY = dtdx*dxdY + dtdy*dydY;

% Functions

f(1) = r2 * st2 ;
f(2) = r2 * ct2;
f(3) = r2 * st2 * st;
f(4) = r2 * ct2 * st;

% Derivatives

% first function
%dPhidr  = -fac * st2;
%dPhidt  =  fac * ct2;
dPhidr = fac * st2;
dPhidt = r2/2 * ct2;
dfdx(1) = dPhidr * drdX + dPhidt * dtdX  ;
dfdy(1) = dPhidr * drdY + dPhidt * dtdY  ;

% second function
% dPhidr  = fac * ct2;
% dPhidt  = fac * st2;
dPhidr = fac * ct2;
dPhidt = -r2/2 * st2;
dfdx(2) = dPhidr * drdX + dPhidt * dtdX  ;
dfdy(2) = dPhidr * drdY + dPhidt * dtdY  ;

% third function
% dPhidr  = fac * st2 * (2*st*st-ct) ;
% dPhidt  = fac * ct* cos(3*theta/2.);
dPhidr = fac * st2 * st;
dPhidt = r2 * (1/2*ct2*st+st2*ct);
dfdx(3) = dPhidr * drdX + dPhidt * dtdX  ;
dfdy(3) = dPhidr * drdY + dPhidt * dtdY  ;

% fourth function
% dPhidr  =  fac * ct2 * (ct + 2*st*st) ;
% dPhidt  = -fac * ct * sin(3*theta/2.);
dPhidr = fac * ct2 *st;
dPhidt = r2 * (-1/2*st2*st+ct2*ct);
dfdx(4) = dPhidr * drdX + dPhidt * dtdX  ;
dfdy(4) = dPhidr * drdY + dPhidt * dtdY  ;

