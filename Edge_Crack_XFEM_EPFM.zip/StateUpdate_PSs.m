function[S3 Sn_e Sn_p Snp_eff Seff_red Cep rt] = StateUpdate_PSs(Sn_e,Sn_p,dSn,rt,E,nu,mu,H,beta,pow,Sy0,Ce,Snp_eff,MaterialModel)
% stressState

Sn_tr = Sn_e+dSn;%trial inplane strain
sigma_tr = Ce*Sn_tr;%Elastic predictor based on plane stress condition
a1 = (sigma_tr(1)+sigma_tr(2))^2;
a2 = (sigma_tr(2)-sigma_tr(1))^2;
a3 = sigma_tr(3)^2;
xi_tr = a1/6 + a2/2 + 2*a3;
Sy = Sy0+rt;%Current Yield surfece
Yieldfn_tr = xi_tr/2 - (1/3)*Sy^2;
if(Yieldfn_tr <= 1e-5)%whether elastic loading
    State = 1;%represents elastic state
    %         display('Elastic')
    %---- update all the variables as the trial values ----
    
    S3 = sigma_tr;
    Sn_e = Sn_tr;
    Cep = Ce;
    %--- Calculating Seff (for plotting only)---
    S4 = [S3;0];
    [sigma_d p J2d] = Sdevia(S4);
    Seff_red = sqrt(3*J2d); % equivalent stress or Von-Mises stress
else
    State = 2;%represents plastic state
%             display('Plastic')
    delta_gama = 0;%increment in effective plastic strain Sn_p
    rk = rt;    
    xi = xi_tr;
    Res_Yfn = Yieldfn_tr;%Residual yield function initialisation
    EE = E/(3*(1-nu));
    while(abs(Res_Yfn)>1e-5)%to calculate incremnt in effective plastic strain iteratively        
        if(MaterialModel==2)%Ramberg's Osgood Material model
            H = E/(beta*pow*(Sy0^(1-pow))*(Sy^(pow-1)));%Hardening Modulus
        end        
        dxi = -(a1/3)*EE/(1+EE*delta_gama)^3 - 2*mu*(a2+4*a3)/(1+2*mu*delta_gama)^3;
        dH = 2*Sy*H*sqrt(2/3)*(sqrt(xi)+0.5*delta_gama*dxi/sqrt(xi));
        dRes_Yfn = dxi/2 - dH/3;
        d_delta_gama = -Res_Yfn/dRes_Yfn;
        delta_gama = delta_gama + d_delta_gama;%new value of delta_gama
        %--- check for convergence ---
        xi = (a1/6)/(1+EE*delta_gama)^2 + (a2/2+2*a3)/(1+2*mu*delta_gama)^2;
        rk = rt+H*delta_gama*sqrt((2/3)*xi);
        Sy = Sy0+rk;
        Res_Yfn = xi/2-(1/3)*Sy^2;
    end
    %---- update all the variables ------
    A = Amatrix(E,mu,nu,delta_gama);
    C = inv(Ce);
%     rk = rt+H*delta_gama*sqrt((2/3)*xi);
%     Sy = Sy0+rk;
    %---- P Matrix ------
    P = zeros(3);
    P(1,1) = 2/3; P(1,2) = -1/3; P(2,1) = -1/3; P(2,2) = 2/3; P(3,3) = 2;
    %--------------------
    
    S3 = A*sigma_tr;
    Sn_e = C*S3;%Inplane Elastic Strain
    Sn_p = Sn_p + delta_gama*P*S3;%Inplane Plastic Strain
    Snp_eff = Snp_eff + delta_gama*sqrt((2/3)*xi);
    rt = rk;
    %--- Calculating Seff (for plotting only)----
    S4 = [S3;0];
    [sigma_d p J2d] = Sdevia(S4);
    Seff_red = sqrt(3*J2d);
    Cep = Cep_PSs(P,S3,H,C,delta_gama);
end
end







