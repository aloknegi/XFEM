%STIFFNESS MATRIX COMPUTATION
Kmat = zeros(total_unknown);
Kgeo  = zeros(total_unknown);
igp = 0;
gpt = zeros(numgpt,2);
numgpt1=0; numgpt2=0;
for iel = 1:numelem
    sctr = element(iel,:);           % element connectivity
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))   % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,tip_elem))   % tip element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (ismember(iel,split_elem_fictitious))   % fictitious element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad_new(order,phi);
    elseif (any(intersect(Fnodes,sctr)) ~= 0)   % having total enrich nodes (split + tip + fictitious)
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
    sctrB = assembly(iel,enrich_node,pos);
    
    for kk = 1 : size(W,1)
        
        % Transform these Gauss points to global coords
        % for plotting only
        igp = igp+1;
        pt = Q(kk,:);       % quadrature point
        [N,dNdxi]=lagrange_basis('Q4',pt);
        Gpnt = N' * updated_node(sctr,:); % global GP
        gpt(igp,:) = Gpnt;
        Cm = Cmat_stiff(1:3,1:3,igp);
        
        % B matrix
        [G,B,J0] = xfemB_Gmatrix_LEFM(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
        
        t = T(igp); %updated thickness
        [MS] = calCepMS(stress(:,igp),stressState);
        
        Kmat(sctrB,sctrB) = Kmat(sctrB,sctrB) + t*B'*Cm*B*W(kk)*det(J0);
        Kgeo(sctrB,sctrB) = Kgeo(sctrB,sctrB) + t*G'*MS*G*W(kk)*det(J0);
    end       % end of looping on GPs
end       % end of looping on elements

