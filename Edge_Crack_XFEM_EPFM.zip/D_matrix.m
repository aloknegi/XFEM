function[Dep]=D_matrix(sigma,mu,H,KK,sigma_tr)
[sigma_d p J2d] = Sdevia(sigma);
sigma_tr_eff = sqrt(3*J2d);
[sigma_d p J2d] = Sdevia(sigma_tr);
Seff_red = sqrt(3*J2d);
Q = (3/2)*(1/(1+3*mu/H)-(sigma_tr_eff/Seff_red));
S = (sigma_tr_eff/Seff_red);
A = (2*mu*Q)/Seff_red^2;
B = KK - (2/3)*mu*S; 

D11 = A*sigma_d(1,1)*sigma_d(1,1) + 2*mu*S + B;
D12 = A*sigma_d(1,1)*sigma_d(2,1) + B;
D13 = A*sigma_d(1,1)*sigma_d(3,1);
D14 = A*sigma_d(1,1)*sigma_d(4,1) + B;

D21 = A*sigma_d(2,1)*sigma_d(1,1) + B;
D22 = A*sigma_d(2,1)*sigma_d(2,1) + 2*mu*S + B;
D23 = A*sigma_d(2,1)*sigma_d(3,1);
D24 = A*sigma_d(2,1)*sigma_d(4,1) + B;

D31 = A*sigma_d(3,1)*sigma_d(1,1);
D32 = A*sigma_d(3,1)*sigma_d(2,1);
D33 = A*sigma_d(3,1)*sigma_d(3,1) + 2*mu*S;
D34 = A*sigma_d(3,1)*sigma_d(4,1);

D41 = A*sigma_d(4,1)*sigma_d(1,1) + B;
D42 = A*sigma_d(4,1)*sigma_d(2,1) + B;
D43 = A*sigma_d(4,1)*sigma_d(3,1);
D44 = A*sigma_d(4,1)*sigma_d(4,1) + 2*mu*S + B;

Dep = [D11 D12 D13 D14; D21 D22 D23 D24; D31 D32 D33 D34; D41 D42 D43 D44];
end


