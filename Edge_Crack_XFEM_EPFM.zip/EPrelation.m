function [Dep] = EPrelation(Ss4,H,D)
Dep = zeros(4);
Cep = zeros(3);
sigma = Ss4;
[a dD] = flowvector(sigma,D);
Dp = dD*dD'/(H+dD'*a);
Dep = D - Dp;
Cep(1:3,1:3)= Dep(1:3,1:3);
end