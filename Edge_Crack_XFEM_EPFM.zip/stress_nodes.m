% Compute stress at nodes and plot
disp([num2str(toc),'      Stress Computation at nodes'])

stressPoints =[-1 -1;1 -1;1 1;-1 1];
stress_node1 = zeros(numelem, 4, 3);

igp=0;
for iel = 1 : numelem
    sctr = element(iel,:);
    nn   = length(sctr);
    U    = element_disp(iel,pos,enrich_node,uut);
    sctrB = assembly(iel,enrich_node,pos);
    
    for q=1:nn
        igp = igp+1;
        pt = stressPoints(q,:);
        [B,J0] = xfemBmatrix_LEFM(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
        strain_node = B*U;
        stress_node1(iel,q,:) = C*strain_node;
    end
end
stress_node = stress_node + stress_node1;
plotContour(stress_node)

% % Average nodal values if not already done
% stressXX = stress_node(:,:,1); stressXY = stress_node(:,:,3); stressYY = stress_node(:,:,2);
% Sxx = zeros(numnode,2); Sxy = Sxx; Syy = Sxx;
% % Construct stress vectors
% for iE = 1:(numelem)
%     for iN = 1:4
%         sctr = element(iE,:);
%         nNode = sctr(iN);
%         Sxx(nNode,:) = Sxx(nNode,:) + [stressXX(iE,iN) 1];
%         Sxy(nNode,:) = Sxy(nNode,:) + [stressXY(iE,iN) 1];
%         Syy(nNode,:) = Syy(nNode,:) + [stressYY(iE,iN) 1];
%     end
% end
% % Average nodal stress values
% Sxx(:,1) = Sxx(:,1)./Sxx(:,2); Sxx(:,2) = [];
% Sxy(:,1) = Sxy(:,1)./Sxy(:,2); Sxy(:,2) = [];
% Syy(:,1) = Syy(:,1)./Syy(:,2); Syy(:,2) = [];
% 
% igp=0;
% for iel = 1 : numelem
%     sctr = element(iel,:);     % element connectivity
%     nn   = length(sctr);
%     U    = element_disp(iel,pos,enrich_node,uut);
%     order = 2;
%     [W,Q] = quadrature(order,'GAUSS',2);
%     sctrB = assembly(iel,enrich_node,pos);
%      
%     igp2=0;
%     for q=1:size(W,1)
%         igp = igp+1;
%         igp2 = igp2+1;
%         ii = sctr(1,igp2);
%         pt = stressPoints(q,:);
%        [B,J0] = xfemBmatrix_LEFM(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
%        fint(sctrB,1) = fint(sctrB,1) + t*B'*[Sxx(ii,1);Syy(ii,1);Sxy(ii,1)]*W(q)*det(J0);  
%     end
% end
% 
% 
