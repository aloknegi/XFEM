function [S4 Snp_eff Seff_red] = ReduceS(R,Ss4_prev,dSs4,Snp_eff,H,beta,pow,E,Sy0,D,MaterialModel,n_step)
%************MARK - 2***********

S4 = zeros(4,1);%initialising S4
Sexcess = R*dSs4/n_step;%Excess stress which must be reduced to yield surface
sigma_flow4 = Ss4_prev +(1-R)*dSs4;% %stress satisfying current yield surface(before reduction)as per step e) pp-251

for i =1:n_step
    [sigma_d p J2d] = Sdevia(sigma_flow4);% based on reduced stress(S4)
    Seff = sqrt(3*J2d); % Seff based on reduced stress(S4)
    [a dD] = flowvector(sigma_flow4,D);
    if(MaterialModel==2)%Romberg's Osgood Material model
        H = E/(beta*pow*(Sy0^(1-pow))*(Seff^(pow-1)));%Hardening Modulus
    end
    d_lamda = (a'*Sexcess)/(H+a'*D*a);%use it
    % d_lamda = (dD'*dSn4)/(H+a'*D*a);
    if(d_lamda < 0)        
        d_lamda = 0;
    end
    S4 = sigma_flow4 + Sexcess - d_lamda*dD;%Reduced stress = Yield surface stress + excess stress -d_lamda*dD    
    % S4 = Ss4_prev + dSs4 - d_lamda*dD;%Reduced stress = prev stress + elastic incremnet-d_lamda*dD
    Snp_eff = Snp_eff + d_lamda*a'*sigma_flow4/Seff;%Current Effective plastic strain:note Seff corresponding to Yield surface(S4) has been used    
    
%     %>>>>>>>>>>For higher accuracy>>>>>>>>>>>>>>>>>>
%     % Based on reduced stress(S4),calculate current Seff and Sy
%     [sigma_d p J2d] = Sdevia(S4);% based on reduced stress(S4)
%     Seff = sqrt(3*J2d); % Seff based on reduced stress(S4)
%     Sy = Sy0+H*Snp_eff;%Yield stress after reduction
%     
%     %----------------------------------------------------------------------
%     % At this stage Seff and Sy must be equal, but they might not be. So a
%     % final reduction is carried out as follows:
%     %----------------------------------------------------------------------
%     %Final reduction and final calculations for stress,Seff and Sy
%     
%     fact = 1;
%     if(Seff>Sy)
%         fact = Sy/Seff;%reduction factor
%     end
%     S4 = S4*fact;%final reduced stress
%     Seff_red = Seff*fact;%final Effective stress
% %     %>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    sigma_flow4 = S4;
end%Stress Reduction Completed

%>>>>>>>>>>>>>For saving computation time>>>>>>>>>>>>>>>>
% Based on reduced stress(S4),calculate current Seff and Sy
[sigma_d p J2d] = Sdevia(S4);% based on reduced stress(S4)
Seff = sqrt(3*J2d); % Seff based on reduced stress(S4)
Sy = Sy0+H*Snp_eff;%Yield stress after reduction

%----------------------------------------------------------------------
% At this stage Seff and Sy must be equal, but they might not be. So a
% final reduction is carried out as follows:
%----------------------------------------------------------------------
%Final reduction and final calculations for stress,Seff and Sy

fact = 1;
if(Seff>Sy)
    fact = Sy/Seff;%reduction factor
end
S4 = S4*fact;%final reduced stress
Seff_red = Seff*fact;%final Effective stress
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
end