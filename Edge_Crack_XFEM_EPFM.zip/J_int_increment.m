if a==24.98
    Jic = Jic + 60;
elseif a==25.08
    Jic = Jic + 50;
elseif a==25.18
    Jic = Jic + 50;
elseif a==25.28
    Jic = Jic + 50;
elseif a==25.38
    Jic = Jic + 50;
elseif a==25.48
    Jic = Jic + 40;
elseif a==25.58
    Jic = Jic + 35;
elseif a==25.68
    Jic = Jic + 35;
elseif a==25.78
    Jic = Jic + 35;
elseif a==25.88
    Jic = Jic + 35;
elseif a==25.98
    Jic = Jic + 35;
elseif a==26.08
    Jic = Jic + 30;
elseif a==26.18
    Jic = Jic + 30;
end