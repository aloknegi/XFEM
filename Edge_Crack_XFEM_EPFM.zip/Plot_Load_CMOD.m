% Load vs y-deformation

figure
hold on
% Data BARC
load BARC_RSD_DATA.mat
plot(DEF,REACTN,'rs-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','m','MarkerSize',5);

% Data XFEM
load XFEM_DATA.mat
plot(def_y,abs(reactn)/1000,'ro-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','m','MarkerSize',5);

legend('BARC RSD DATA','a = 24.98mm & da=0.25mm','location','SouthEast');

xlabel('CMOD(mm)');
ylabel('Load (kN)');
set(gcf, 'color', 'white');
grid on

