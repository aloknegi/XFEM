function [S4 Yield0 Snp_eff Snp_eff_prev Seff_red Dep] = OwenH_EPlasticity(dSs4,Ss4_prev,Seff_prev,Yield0,Snp_eff,Snp_eff_prev,H,beta,pow,E,Sy0,D,MaterialModel)
%This functionperforms Reduction of Stresses to Yield Surface & Cmat calculation as per Book by Owen and Hinton >>>>>>>>

%*****this function accounts for unloading also*****

Ss4 = Ss4_prev + dSs4;%Total elastic stress predictor
% Based on sigma_e , calculate following
[sigma_d p J2d] = Sdevia(Ss4);
Seff = sqrt(3*J2d); % based on elastic stress predictor (Ss4 matrix)

% Sy_prev = Sy0+H*Snp_eff_prev;
Sy_prev = Sy0+H*Snp_eff;
%>>>>> Identification of Deformation Mode,Stress Reduction  >>>>>>>>>>>>
if(Seff_prev>Yield0)%use it
% if(abs(Seff_prev-Sy_prev)<=1e-3)% to check whether GP yielded in previous load step
    if(Seff > Seff_prev)%Yes to above question;now to check whether element continues to yield or starts unloading
%         disp('Strain Hardening')        
        R = 1;% complete plastic        

%         n_step = 8*(Seff-Seff_prev)/Sy0 + 1; %Recommended for higher
%         accuracy but proves inaccurate in tensile loading or at higher strains. It should/can be used
%         in compression problems

        n_step = 1;%Recommended for saving computation cost. It is the best
        if(n_step>100)
            n_step = 100;
        end
            
        Snp_eff_prev = Snp_eff;
        [S4 Snp_eff Seff_red] = ReduceS(R,Ss4_prev,dSs4,Snp_eff,H,beta,pow,E,Sy0,D,MaterialModel,n_step);
        
        %>>>>>>>>>>>calculation of Cmat(4x4 & 3x3 matrices)>>>>>>>>>
        [Dep] = EPrelation(S4,H,D);        
    else
%         disp('Unloading')        
        R = 0;
        %no change in elastic predictor stress (i.e. S4 = Ss4)
        S4 = Ss4_prev + dSs4;
        [sigma_d p J2d] = Sdevia(S4);
        Seff_red = sqrt(3*J2d); % based on elastic stress predictor(Ss4)
        
        %Effective Plastic Strain(Snp_eff) will not change in unloading
        
        Yield0 = Sy0+H*Snp_eff;%New Yield0 is calculated at each unloading
        Snp_eff_prev = Snp_eff;
        Dep = D;        
    end
else            % if element has not yielded in previous load step
    if(Seff > Yield0)% to check whether element has just yielded in this load step
%         disp('Yielding')
        R = (Seff - Yield0)/(Seff - Seff_prev);%element has just yielded
%         n_step = 8*(Seff-Yield0)/Sy0 + 1;

        n_step = 1;%Recommended
        if(n_step>100)
            n_step = 100;
        end
        Snp_eff_prev = Snp_eff;
        [S4 Snp_eff Seff_red] = ReduceS(R,Ss4_prev,dSs4,Snp_eff,H,beta,pow,E,Sy0,D,MaterialModel,n_step);
        
        %>>>>>>>>>>>calculation of Cmat(4x4 & 3x3 matrices)>>>>>>>>>
        [Dep] = EPrelation(S4,H,D);        
    else
%         disp('Elastic')        
        R = 0;        
        S4 = Ss4_prev + dSs4; %no change in elastic predictor stress(i.e. S4 = Ss4)
        [sigma_d p J2d] = Sdevia(S4);
        Seff_red = sqrt(3*J2d); % based on reduced stress(S4)            
        Dep = D;        
    end
end