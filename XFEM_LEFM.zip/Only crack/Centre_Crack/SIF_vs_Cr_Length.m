
% For initial crack of 30mm and 60MPa applied load

cr_length = [30 34 38 42 46 50 54 58 62 66 70 74];
K1L = [444.1401 476.1191 508.3674 550.8155 581.5272 623.8460 673.7729 725.3849 792.4345 842.1350 873.9761 891.4536];
K2L = [0.1123 3.9465 -7.5620 6.9792 -7.8954 7.1741 -4.2596 2.2743 -3.9896 4.2512 -1.5902 2.3069];

K1R = [444.1401 476.1191 508.3674 550.8155 581.5272 623.8460 673.7729 725.3849 792.4345 842.1350 873.9761 891.4536];
K2R = [-0.1123 -3.9465 7.5620 -6.9792 7.8954 -7.1741 4.2596 -2.2743 3.9896 -4.2512 1.5902 -2.3069];

K1eqL = [444.1401 476.1681 508.5361 550.9481 581.6879 623.9697 673.8133 725.3956 792.4646 842.1672 873.9805 891.4626];
K1eqR = [444.1401 476.1681 508.5361 550.9481 581.6879 623.9697 673.8133 725.3956 792.4646 842.1672 873.9805 891.4626];

figure
hold on
plot(cr_length,K1L,'bo-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','y','MarkerSize',5);
plot(cr_length,K2L,'ms-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','y','MarkerSize',5);
xlabel('Crack Length in mm');
ylabel('Stress Intensity Factor in MPa(mm)^.5');
legend('K1L','K2L','location','NorthWest')
set(gcf, 'color', 'white');
grid on
axis on
hold off

figure
hold on
plot(cr_length,K1R,'bo-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','y','MarkerSize',5);
plot(cr_length,K2R,'ms-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','y','MarkerSize',5);
xlabel('Crack Length in mm');
ylabel('Stress Intensity Factor in MPa(mm)^.5');
legend('K1R','K2R','location','NorthWest')
set(gcf, 'color', 'white');
grid on
axis on
hold off

figure
hold on
plot(cr_length,K1eqL,'bo-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','y','MarkerSize',5);
plot(cr_length,K1eqR,'ms-','LineWidth',1.5,'MarkerEdgeColor','k','MarkerFaceColor','y','MarkerSize',5);
xlabel('Crack Length in mm');
ylabel('Stress Intensity Factor in MPa(mm)^.5');
legend('K1eqL','K1eqR','location','NorthWest')
set(gcf, 'color', 'white');
grid on
axis on