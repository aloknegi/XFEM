function [Jdomain,qnode,radius] = Jdomain_new_Right(cR,xTipR)

global node element

numnode = size(node,1);
radius = cR;
center = xTipR;
r=[];
% Distance from the center of tip element
for i = 1 : numnode
    sctr = node(i,:);
    rho  = sqrt((sctr(1)-center(1))^2+(sctr(2)-center(2))^2);
    r    = [r,rho];
end
test = r-radius;
test = test(element)';
Jdomain =find(any(test<=0));

test1 = r-radius;
test1 = test1(element(Jdomain,:))';
test1 = (test1<=0);
qnode = test1';

