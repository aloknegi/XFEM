
% Split and Tip Element Evaluation

enrich_node = zeros(numnode,1);
count1 = 0;
count2 = 0;

for iel = 1: numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    psi1 = ls(sctr,3);
    
    if ( max(phi)*min(phi) < 0 )% && max(psi1)*min(psi1) > 0)
        if (max(psi) < 0 ) && (max(psi1) < 0) %
            count1 = count1 + 1 ;
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        end
    end
end

for iel = 1: numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    psi1 = ls(sctr,3);
    xdiff=xTipR(1)-node(sctr,1);
    ydiff=xTipR(2)-node(sctr,2);

    xdiff1=xTipL(1)-node(sctr,1);
    ydiff1=xTipL(2)-node(sctr,2);

    if ( max(phi)*min(phi) < 0 )

        if  (max(psi)*min(psi) < 0 )%&& (max(xdiff)*min(xdiff)<0 && max(ydiff)*min(ydiff)<0) )
            if (max(xdiff)*min(xdiff)<0 && max(ydiff)*min(ydiff)<0)
                count2 = count2 + 1 ; % one tip element
                tip_elem(count2) = iel;
                enrich_node(sctr)   = 2;
            end
            if (enrich_node(sctr)   == 0|enrich_node(sctr)   == 1)
                count1 = count1 + 1 ;
                split_elem(count1) = iel;
                enrich_node(sctr)   = 1;
            end
        end
        if  (max(psi1)*min(psi1) < 0 )%&& (max(xdiff1)*min(xdiff1)<0 && max(ydiff1)*min(ydiff1)<0) )
            if (max(xdiff1)*min(xdiff1)<0 && max(ydiff1)*min(ydiff1)<0)
                count2 = count2 + 1 ; % one tip element
                tip_elem(count2) = iel;
                enrich_node(sctr)   = 2;
                if (enrich_node(sctr)   == 0|enrich_node(sctr)   == 1)
                    count1 = count1 + 1 ;
                    split_elem(count1) = iel;
                    enrich_node(sctr)   = 1;
                end
            end
        end

    end
end