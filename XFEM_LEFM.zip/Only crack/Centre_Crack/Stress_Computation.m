% Compute stress at nodes and plot
disp([num2str(toc),'      Stress computation'])

stressPoints=[-1 -1;1 -1;1 1;-1 1];
stress=zeros(numelem,4,3);
for e = 1 : numelem
    sctr = element(e,:);
    nn   = length(sctr);
    U     = element_disp(e,pos,enrich_node,u);
    for q=1:nn
        pt = stressPoints(q,:);
        nodes = node(sctr,:);
    
        x0=sum(nodes(:,1))/4;
        y0=sum(nodes(:,2))/4;
        x1=xTipR(:,1);
        y1=xTipR(:,2);

        x2=xTipL(:,1);
        y2=xTipL(:,2);
        dist1=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));
        dist2=sqrt((x2-x0)*(x2-x0)+(y2-y0)*(y2-y0));

        if (dist1<dist2)
            xTip2=xTipR;
            alpha2=alphaR;
        else
            xTip2=xTipL;
            alpha2=alphaL;
        end
  
        [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip2,alpha2);
        strain = B*U;
        stress(e,q,:) = C*strain;
    end
end