% Stress Computation    

stress = zeros(numelem, 4, 3);
    for e = 1 : numelem
        sctr = element(e,:); % element connectivity
        Q = [1 1; 1 -1; -1 1; -1 -1]; % four local stress points to calculate stress
        W = [1;1;1;1];
        q = [];
        for igp = 1 : size(W,1)
            gpnt = Q(igp,:);
            [N,dNdxi]=lagrange_basis('Q4',gpnt);
            Gpnt = N' * node(sctr,:); % global GP
            q = [q;Gpnt];
        end
        
        for igp = 1 : size(W,1)
            pt1 = q(igp,:);                           % quadrature point
            pt  = Q(igp,:);
            x0 = pt1(:,1);
            y0 = pt1(:,2);
            x1 = xTipL(jj,1);
            y1 = xTipL(jj,2);
            
            x2 = xTipR(jj,1);
            y2 = xTipR(jj,2);
            dist1 = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));
            dist2 = sqrt((x2-x0)*(x2-x0)+(y2-y0)*(y2-y0));
            
            U = element_disp(e,pos,enrich_node,u);
            
            if (dist1<dist2)
                [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTipL(jj,:),alphaL);
            else
                [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTipR(jj,:),alphaR);
            end
            
            strain = B*U;
            stress(e,igp,:) = C*strain;
        end
        
    end