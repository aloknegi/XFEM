% Stifness Matrix    

qq =[];
    
    for iel = 1 : numelem
        sctr = element(iel,:); % element connectivity
        nn   = length(sctr);   % number of nodes per element
        
        % -----------------------------------------------
        % Choose Gauss quadrature rules for elements
        if (ismember(iel,split_elem))     % split element
            order = 2 ;
            phi   = ls(sctr,1);
            [W,Q] = discontQ4quad(order,phi);
            
        elseif (ismember(iel,tip_elemL))   % tip element
            order = 7;
            phiL   = ls(sctr,1);
            nodes = node(sctr,:);
            [W,Q] = disTipQ4quad(order,phiL,nodes,xTipL(jj,:));
            
        elseif (ismember(iel,tip_elemR))   % tip element
            order = 7;
            phiR   = ls(sctr,1);
            nodes = node(sctr,:);
            [W,Q] = disTipQ4quad(order,phiR,nodes,xTipR(jj,:));
            
        elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
            order = 4 ;
            [W,Q] = quadrature(order,'GAUSS',2);
            
        else
            order = 2 ;
            [W,Q] = quadrature(order,'GAUSS',2);
        end
        
        q = [];
        for igp = 1 : size(W,1)
            gpnt = Q(igp,:);
            [N,dNdxi]=lagrange_basis('Q4',gpnt);
            Gpnt = N' * node(sctr,:); % global GP
            q = [q;Gpnt];
            qq = [qq;Gpnt];
        end
        
        sctrB = assembly(iel,enrich_node,pos);
        
        % ---------------------
        % Loop on Gauss points
        % ---------------------
        for kk = 1 : size(W,1)
            pt = Q(kk,:) ;                            % quadrature point
            pt1 = q(kk,:) ;
            
            x0=pt1(:,1);
            y0=pt1(:,2);
            x1=xTipL(jj,1);
            y1=xTipL(jj,2);
            
            x2=xTipR(jj,1);
            y2=xTipR(jj,2);
            dist1=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));
            dist2=sqrt((x2-x0)*(x2-x0)+(y2-y0)*(y2-y0));
            
            if (dist1<=dist2)
                
                [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node, xCr,xTipL(jj,:),alphaL);
                
            else
                
                [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node, xCr,xTipR(jj,:),alphaR);
                
            end
            
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
            
        end                  % end of looping on GPs       
    end                      % end of looping on elements