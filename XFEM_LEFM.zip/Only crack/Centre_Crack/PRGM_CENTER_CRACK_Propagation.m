% STRAIGHT CENTER CRACK PROPAGATION
clear all
close all; clc; tic;
global nnx nny node element PLOT Lt Ht elemType E nu C
% Dimension of the domain
% (it is simply a rectangular region Ht x Lt)
Lt = 100;
Ht = 200;
% Loading
sigmato = 3;
KIC = 56;
aImax = 2; % maximum size of crack increment
ni=1;
% Material properties
E  = 8e3;
nu = 0.35;
PLOT = 1;
cc = [Lt/2 Ht/2]    ;           % crack center coordinates
a = 16;                      % crack length
ang = 0;                     % Crack Angle WRT Horizontal axis
an = pi/180*ang;
xCr   = [cc(1,1)-a/2*cos(an)    cc(1,2)-a/2*sin(an);    cc(1,1)+a/2*cos(an)    cc(1,2)+a/2*sin(an)];
xTipR  = [xCr(2,1)  xCr(2,2)];
xTipL = [xCr(1,1)  xCr(1,2)];

seg    = xCr(2,:) - xCr(1,:);        % Tip Segment
seg1   = xCr(1,:) - xCr(2,:);       % SEcond Function for left tip
alphaR = atan2(seg(2),seg(1));       % Inclination Angle
alphaL = atan2(seg1(2),seg1(1));
QTR    = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];
QTL    = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

% +++++++++++++++++++++++++++++
%            MESHING
% +++++++++++++++++++++++++++++

disp([num2str(toc),'   MESH GENERATION'])
% Number of nodes along two directions

nnx = 40 ;
nny = 80;

% Four corner points
pt1 = [0 0] ;
pt2 = [Lt 0] ;
pt3 = [Lt Ht] ;
pt4 = [0 Ht] ;

elemType = 'Q4' ;
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);

numnode = size(node,1);
numelem = size(element,1);

uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)
topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';
% GET NODES ON DIRICHLET BOUNDARY AND ESSENTIAL BOUNDARY
dispNodes  = unique(botEdge);
tracNodes  = unique(topEdge);          % returns the same values as in topedge but with no repetitions

disp([num2str(toc),'LEVEL SET INITIALIZATION'])
x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
t1   = 1/norm(seg1)*seg1;
ls=zeros(numnode,3);

for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;               % normal LS
    ls(i,2) = ([x y]-xTipR)*t';     % tangent LS
    ls(i,3) = ([x y]-xTipL)*t1';   % tangent LS Second tip LeftTip
end

Split_Tip_Elem %%--------SPLIT AND TIP ELEMENT EVALUATION-------%%

enrich_node = zeros(numnode,1);
split_elem  = setdiff(split_elem, tip_elem);
Felement    = union(split_elem,tip_elem);
split_nodes = unique(element(split_elem,:));
trr        = element(tip_elem,:);
tip_nodes  =  unique(trr');
split_nodes =  setdiff(split_nodes,tip_nodes);
enrich_node(split_nodes(:,1)) = 1;
enrich_node(tip_nodes(:,1))   = 2;

figure
hold on
cntr = plot([0,Lt,Lt,0,0],[0,0,Ht,Ht,0],'k');
set(cntr,'LineWidth',1.5);
plot_mesh(node,element,elemType,'k-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',2);
% n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
% n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
% set(n1,'MarkerSize',5);
% set(n2,'MarkerSize',5);
% plot(node(dispNodes,1),node(dispNodes,2),'ks');
set(gcf, 'color', 'white');
axis equal
axis off

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;

K = sparse(total_unknown,total_unknown);

FMech = zeros(total_unknown,1);    % f-matrix

% Compliance matrix C

C = E/(1-nu^2)*[1 nu 0;
    nu 1  0;
    0 0 0.5*(1-nu)];

pos = zeros(numnode,1);
nsnode = 0 ;
ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end

Stiffness_Matrix %%--------STIFFNESS MATRIX COMPUTATION-------%%

% ************************
%    NODAL FORCE VECTOR
% ************************
disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;
    
    for q=1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        FMech(sctry)=FMech(sctry) + N*sigmato*det(J0)*wt;
        
    end   % of quadrature loop
end       % of element loop

f=FMech;

% **********************************
%    ESSENTIAL BOUNDARY CONDITION
% **********************************
disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K));

vdofs = dispNodes.*2;
udofs = 1;

f(udofs) = 0 ;
f(vdofs) = 0 ;
K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

% **********************************
%          POST PROCESSING
% **********************************
disp([num2str(toc),'   POST PROCESSING'])

% **********************************
%       SOLUTION OF EQUATIONS
% **********************************
disp([num2str(toc),'   SOLUTION'])
u   = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'      Deformed configuration'])
% %Plot numerical deformed configuration
figure
hold on
fac = 100;
plot_mesh(node+fac*[u_x u_y],element,elemType,'g-');
title(' Numerical deformed configuration ')
set(gcf, 'color', 'white');
axis equal
axis off

Stress_Computation %%--------STRESS COMPUTATION--------%%

plotContour(stress);

disp([num2str(toc),'      Stress intensity factors computation'])

cL = a/4;
cR = a/4;

SIF_new_L %%------STRESS INTENSITY FACTOR FOR LEFT CRACK-------%%

alphaL = theta_CL+alphaL;
anglereqL = alphaL*180/pi ;
QTL = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

SIF_new_R %%------STRESS INTENSITY FACTOR FOR RIGHT CRACK-------%%

alphaR = theta_CR+alphaR;
anglereqR = alphaR*180/pi;
QTR = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];

pat = [];
pat = [pat; 0 K1L K2L K1R K2R K1eqL K1eqR ];
aa = a;

% Compute the exact SIFs

F = 1.0 + 0.128*(a/Lt) - 0.288*(a/Lt)^2 + 1.523*(a/Lt)^3 ;
F1 = sqrt(1+0.50*(a/2/Lt)^2+20.46*(a/2/Lt)^4+81.72*(a/2/Lt)^6);

KexactGdouts = F * sigmato*sqrt(pi*a/2)
KexactParez = F1 * sigmato*sqrt(pi*a/2)
aIL = aImax; aIR = aImax;

if K1eqL >=K1eqR
    K1eq_MAX = K1eqL;
else
    K1eq_MAX = K1eqR;
end
% K1eq_MAX is Used for crack propagation criterion
xCr(3,:) = [xTipR(1,1)+aIR*cos(alphaR) xTipR(1,2)+aIR*sin(alphaR)];

xCr = [[xTipL(1,1)+aIL*cos(alphaL) xTipL(1,2)+aIL*sin(alphaL)];xCr];

xTipR(2,:) = xCr(4,:); % new right crack tip
xTipL(2,:) = xCr(1,:); % new left crack tip
jj = 2;
disp(K1eq_MAX);
% ====================================================================== %
%               While loop for Fatigue crack propagation
% ====================================================================== %
K1L_final = [];
K2L_final = [];
K1eqL_final = [];
K1R_final = [];
K2R_final = [];
K1eqR_final = [];
ni=1;
sif(ni)= K1eq_MAX;
KGdouts(ni)= KexactGdouts
KParez(ni)= KexactParez
while K1eq_MAX < KIC % check whether SIF is still less than fracture toughness
    ni=ni+1;
    clear K JdomainR JdomainL pos enrich_node
    
    Left_Edge_Crack %%---------LEFT EDGE CRACK---------%%
    
    Right_Edge_Crack %%--------RIGHT EDGE CRACK---------%%
    
    
    FaL = union(split_elemL,tip_elemL);
    ls(unique(element(FaL,:)),1) = lsLL(unique(element(FaL,:)),1);
    
    FaR = union(split_elemR,tip_elemR);
    ls(unique(element(FaR,:)),1) = lsRR(unique(element(FaR,:)),1);
    
    split_elem  = union(Felement, split_elemL);
    split_elem  = union(split_elem, split_elemR);
    split_nodes = unique(element(split_elem,:));
    trrL        = element(tip_elemL,:);
    tip_nodesL  =  unique(trrL');
    trrR        = element(tip_elemR,:);
    tip_nodesR  =  unique(trrR');
    tip_nodes   =  union(tip_nodesL, tip_nodesR);
    split_nodes =  setdiff(split_nodes,tip_nodes);
    tip_elem    =  union(tip_elemL,tip_elemR);
    Felement    =  union(split_elem,tip_elem);
    
    enrich_node = zeros(numnode,1);
    enrich_node(split_nodes(:,1)) = 1;
    enrich_node(tip_nodes(:,1))   = 2;
    
    disp([num2str(toc),'   PLOT NODES AND GAUSS POINTS'])
    
%     figure
%     hold on
%     cntr = plot([0,Lt,Lt,0,0],[0,0,Ht,Ht,0]);
%     set(cntr,'LineWidth',3);
%     plot_mesh(node,element,elemType,'b-');
%     cr = plot(xCr(:,1),xCr(:,2),'r-');
%     set(cr,'LineWidth',3);
%     n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
%     n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
%     set(n1,'MarkerSize',5);
%     set(n2,'MarkerSize',5);
%     plot(node(dispNodes,1),node(dispNodes,2),'ks');
%     set(gcf, 'color', 'white');
%     axis equal
%     axis off
    
    total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;
    K = sparse(total_unknown,total_unknown);
    FMech = zeros(total_unknown,1);
    
    % ***********************************
    %    Stiffness matrix computation
    % ***********************************
    
    disp([num2str(toc),'   DOMAIN ASSEMBLY'])
    
    pos = zeros(numnode,1);
    nsnode = 0 ;
    ntnode = 0 ;
    for i = 1 : numnode
        if (enrich_node(i) == 1)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            nsnode = nsnode + 1 ;
        elseif (enrich_node(i) == 2)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            ntnode = ntnode + 1 ;
        end
    end
    
    disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
    
    Stiffness_Matrix_1 %%--------STIFNESS MATRIX COMPUTATION---------%%
    
    % ************************
    %    NODAL FORCE VECTOR
    % ************************
    disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])
    
    % The top edge is applied a traction along Y direction
    [W,Q]=quadrature(1,'GAUSS',1);
    for e = 1:size(topEdge,1)
        sctr = topEdge(e,:);
        sctry = sctr.*2 ;
        for q=1:size(W,1)
            pt = Q(q,:);
            wt = W(q);
            N  = lagrange_basis('L2',pt);
            J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
            FMech(sctry)=FMech(sctry) + N*sigmato*det(J0)*wt;
        end   % of quadrature loop
    end       % of element loop
    
    f=FMech;
    
    % **********************************
    %    ESSENTIAL BOUNDARY CONDITION
    % **********************************
    disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])
    
    bcwt = mean(diag(K));
    
    vdofs = dispNodes.*2;
    udofs = 1;
    
    f(udofs) = 0 ;
    f(vdofs) = 0 ;
    K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
    K(vdofs,:) = 0;
    K(:,udofs) = 0;
    K(:,vdofs) = 0;
    K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
    K(vdofs,vdofs) = bcwt*speye(length(vdofs));
    
    % **********************************
    %          POST PROCESSING
    % **********************************
    disp([num2str(toc),'   POST PROCESSING'])
    
    % **********************************
    %       SOLUTION OF EQUATIONS
    % **********************************
    disp([num2str(toc),'   SOLUTION'])
    u   = K\f;
    u_x = u(1:2:2*numnode) ;
    u_y = u(2:2:2*numnode) ;
    
    disp([num2str(toc),'      Deformed configuration'])
    % --------------------------------------------------
    %     %Plot numerical deformed configuration
    %     figure
    %     hold on
    %     fac = 100;
    %     plot_mesh(node+fac*[u_x u_y],element,elemType,'g-');
    %     title(' Numerical deformed configuration ')
    %     set(gcf, 'color', 'white');
    %     axis off
    
    disp([num2str(toc),'      Stress computation'])
    
    Stress_Computation_1 %%---------STRESS COMPUTATION--------%%
    
    %     plotContour(stress);
    
    cL = a/4;
    cR = a/4;
    
    SIF_new_L_1 %%------STRESS INTENSITY FACTOR FOR LEFT CRACK-------%%
    
    alphaL = theta_CL+alphaL;
    anglereqL = alphaL*180/pi
    QTL = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];
    
    K1L_final = [K1L_final K1L];
    K2L_final = [K2L_final K2L];
    K1eqL_final = [K1eqL_final K1eqL];
    
    SIF_new_R_1 %%------STRESS INTENSITY FACTOR FOR RIGHT CRACK-------%%
    
    alphaR = theta_CR+alphaR;
    anglereqR = alphaR*180/pi
    QTR = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];
    
    K1R_final = [K1R_final K1R];
    K2R_final = [K2R_final K2R];
    K1eqR_final = [K1eqR_final K1eqR];
    
    % Compute the exact SIFs
    a = a+2*aImax;
    F = 1.0 + 0.128*(a/Lt) - 0.288*(a/Lt)^2 + 1.523*(a/Lt)^3 ;
    F1 = sqrt(1+0.50*(a/2/Lt)^2+20.46*(a/2/Lt)^4+81.72*(a/2/Lt)^6);
    
    KexactGdouts = F * sigmato*sqrt(pi*a/2)
    KexactParez = F1 * sigmato*sqrt(pi*a/2)
    aIL = aImax; aIR = aImax;
    
    if K1eqL >=K1eqR
        K1eq_MAX = K1eqL;
    else
        K1eq_MAX = K1eqR;
    end
    % K1eq_MAX is Used for crack propagation criterion
    ss = size(xCr,1);
    xCr = [[xTipL(jj,1)+aIL*cos(alphaL) xTipL(jj,2)+aIL*sin(alphaL)];xCr];% New right crack segment
    
    xCr(ss+2,:) = [xTipR(jj,1)+aIR*cos(alphaR) xTipR(jj,2)+aIR*sin(alphaR)]; % New left  crack segment
    
    xTipR(jj+1,:) = xCr(ss+2,:); % new right crack tip
    xTipL(jj+1,:) = xCr(1,:);    % new left crack tip
    
    jj = jj+1;
    clen(ni)=a;
    sif(ni)= K1eq_MAX;
    KGdouts(ni)= KexactGdouts;
    KParez(ni)= KexactParez;
end
% CLENGTH=clen';
SIF=sif';
% KEXACTGDOUTS= KGdouts';
% KPAREZ= KParez';
% T = table(SIF,KEXACTGDOUTS,KPAREZ);
T = table(SIF);
disp(T(1:ni,:));
filename = 'E:\Thesis\01. Code\XFEM Code\3centreswcnt.xlsx';
writetable(T,filename,'Sheet',1,'Range','A1');
