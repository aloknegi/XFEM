
% Stiffness Matrix

q = [];
disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
% -----------------
% Loop on elements
% -----------------
for iel = 1 : numelem
    sctr = element(iel,:); % element connectivity
    nn   = length(sctr);   % number of nodes per element
   
    % -----------------------------------------------
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))     % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
        
    elseif (ismember(iel,tip_elem))   % tip element
        order = 7;
        phi   = ls(sctr,1);
        nodes = node(sctr,:);

        % need to put logic for using correct tip

        x0=sum(nodes(:,1))/4;
        y0=sum(nodes(:,2))/4;
        x1=xTipR(:,1);
        y1=xTipR(:,2);

        x2=xTipL(:,1);
        y2=xTipL(:,2);
        dist1=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));
        dist2=sqrt((x2-x0)*(x2-x0)+(y2-y0)*(y2-y0));

        if (dist1<dist2)
            xTip2=xTipR;
        else
            xTip2=xTipL;
        end

        [W,Q] = disTipQ4quad(order,phi,nodes,xTip2);

    elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    end

    qq = [];
    for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:); % global GP
        q  = [q;Gpnt];
        qq = [qq;Gpnt];   
    end

    sctrB = assembly(iel,enrich_node,pos);

    % ---------------------
    % Loop on Gauss points
    % ---------------------
    for kk = 1 : size(W,1)
        pt = Q(kk,:) ;                            % quadrature point
        pt1 = qq(kk,:);
        x0=pt1(:,1);
        y0=pt1(:,2);
        x1=xTipR(:,1);
        y1=xTipR(:,2);

        x2=xTipL(:,1);
        y2=xTipL(:,2);
        dist1=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));
        dist2=sqrt((x2-x0)*(x2-x0)+(y2-y0)*(y2-y0));

        if (dist1<dist2)
            xTip2=xTipR;
            alpha2=alphaR;
            xCr2=xCr;
        else
            xTip2=xTipL;
            alpha2=alphaL;
            xCr2=xCr;
        end

        [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr2,xTip2,alpha2);

        K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);

    end                  % end of looping on GPs
end                      % end of looping on elements