% For initial crack of 30mm and 60MPa applied load

cr_length = [30 34 38 42 46 50 54 58];
K1 = [923.9153 1090.9 1341.7 1451.1 1709.9 2154.7 2330.3 2787.9];
K2 = [8.9530 -14.0387 -2.4405 22.1621 -22.3744 -0.2919 0.1458 5.3727];
figure
hold on
plot(cr_length,K1,'bo-','LineWidth',2.5,'MarkerEdgeColor','k','MarkerFaceColor','c','MarkerSize',5);
plot(cr_length,K2,'mo-','LineWidth',2.5,'MarkerEdgeColor','k','MarkerFaceColor','c','MarkerSize',5);
xlabel('Crack Length in mm');
ylabel('Stress Intensity Factor in MPa(mm)^.5');
legend('K1','K2','location','NorthWest')
set(gcf, 'color', 'white');
grid on
axis on