clear sctr
clear iel
count1 = 0;
count2 = 0;
for iel = 1 : numelem
    sctr = element(iel,:); % element connectivity
  if (ismember(sctr,split_elem)) 
      count1 = count1 + 1 ; % ah, one split element
      split_elem(count1) = iel;
  elseif (ismember(sctr,tip_elem))   % tip element
       count2 = count2 + 1 ; % ah, one tip element
       tip_elem(count2) = iel;
  end
end
clear sctr
clear iel
count1 = 0;
count2 = 0;
for iel = 1 : numelem
    sctr = element(iel,:); % element connectivity
  if (ismember(sctr,split_nodes(1,:))) 
      count1 = count1 + 1 ; % ah, one split element
      split_elem(count1) = iel;
  elseif (ismember(sctr,tip_nodes(1,:)))   % tip element
       count2 = count2 + 1 ; % ah, one tip element
       tip_elem(count2) = iel;
  end
end