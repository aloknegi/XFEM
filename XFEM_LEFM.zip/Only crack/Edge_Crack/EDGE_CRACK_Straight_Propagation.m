% STRAIGHT CRACK PROPAGATION WITH LEFM
clear all; state = 0; tic; close all; clc;
global nnx nny node element PLOT L
L = 100;
D = 200;
stressState='PLANE_STRESS';
PLOT = 1 ; 
a = 40;             % Left Crack length 
angle = 0;          % Inclination angle in degree for left crack
alpha = pi*angle/180; xedge = 0; yedge = D/2;
xCr   = [xedge yedge ; xedge+a*cos(alpha) yedge+a*sin(alpha)]; % crack coordinates 
% xCr   = [xedge yedge; 15 10 ; xedge+a*cos(alpha) yedge+a*sin(alpha)]; % crack coordinates 
xTip  = [xedge+a*cos(alpha) yedge+a*sin(alpha)];               % crack tip coordinates
seg   = xCr(2,:) - xCr(1,:);                                   % tip segment
QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)]; ni=1;

%%%%% Material Parameters %%%%%%%%%%
nu = 0.35;
sigmato = 2.5;  % applied load in MPa
KIC = 50;    % critical stress intensity factor
E  = 2.9e3;
aImax = 2;     % maximum size of crack increment

disp([num2str(toc),'   MESH GENERATION'])

nnx = 40;
nny = 80;

% Four corner points
pt1 = [0 0] ;
pt2 = [L 0] ;
pt3 = [L D] ;
pt4 = [0 D] ;

elemType = 'Q4' ;
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);
numnode = size(node,1);
numelem = size(element,1);

uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1   ;  % node number at (0,0)

topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';

botNodes   = unique(botEdge);
topNodes   = unique(topEdge);

dispNodes = botNodes;
tracNodes = topNodes;

% +++++++++++++++++++++++++++++++++++++
%        LEVEL SET INITIALIZATION
%      SELECTION OF ENRICHED NODES
% +++++++++++++++++++++++++++++++++++++

disp([num2str(toc),'   LEVEL SET INITIALIZATION'])

x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
ls=zeros(numnode,2);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;            % normal LS
    ls(i,2) = ([x y]-xTip)*t';  % tangent LS
end
split_elem=[];
enrich_node = zeros(numnode,1);
count1 = 0;
count2 = 0;
tip_elem = [];
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    if (max(phi)*min(phi) < 0)
        if max(psi) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elem(count2) = iel;
            enrich_node(sctr)   = 2;
        end
    end
end

split_nodes = find(enrich_node == 1);
tip_nodes   = find(enrich_node == 2);
Felement = union(split_elem,tip_elem);

% Plot mesh and enriched nodes to check
figure
hold on
cntr = plot([0,L,L,0,0],[0,0,D,D,0],'k-');
set(cntr,'LineWidth',2);
plot_mesh(node,element,elemType,'k-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',2);
% n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
% n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rh');
% set(n1,'MarkerSize',10);
% set(n2,'MarkerSize',10);
set(gcf, 'color', 'white');
% plot(node(dispNodes,1),node(dispNodes,2),'ks');
axis equal
axis off

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;

K = zeros(total_unknown,total_unknown);
f = zeros(total_unknown,1);

% ***********************************
%    Stiffness matrix computation
% ***********************************

% Compliance matrix C
if ( strcmp(stressState,'PLANE_STRESS') )
    C = E/(1-nu^2)*[ 1   nu 0;
        nu  1  0 ;
        0   0  0.5*(1-nu) ];
else
    C = E/(1+nu)/(1-2*nu)*[ 1-nu  nu  0;
        nu    1-nu 0;
        0     0  0.5-nu ];
end

pos = zeros(numnode,1);
nsnode = 0 ;
ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end

q = [];
disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
% -----------------
% Loop on elements
% -----------------
for iel = 1:numelem
    sctr = element(iel,:); % element connectivity
    nn   = length(sctr);   % number of nodes per element
    ke   = 0 ;             % elementary stiffness matrix
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))     % split element
        order = 2;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
    elseif (ismember(iel,tip_elem))   % tip element
        order = 7;
        phi   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phi,nodes,xTip);
    elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 4;
        [W,Q] = quadrature(order,'GAUSS',2);
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end

    % Transform these Gauss points to global coords
    % for plotting only
    for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:); % global GP
        q = [q;Gpnt];
    end
    
    sctrB = assembly(iel,enrich_node,pos);
        
    for kk = 1 : size(W,1)
        pt = Q(kk,:);   % quadrature point
        [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha); % B matrix                
        K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0); % Stiffness matrix       
    end                  % end of looping on GPs    
end                      % end of looping on elements

disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;
    for ij=1:size(W,1)
        pt = Q(ij,:);
        wt = W(ij);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        f(sctry)=f(sctry)+N*sigmato*det(J0)*wt;
    end   % of quadrature loop   
end       % of element loop

disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K)); % a measure of the average size of an element in K
% used to keep the conditioning of the K matrix

vdofs = dispNodes.*2;
udofs = 1; % for lower left corner node

f(udofs) = 0 ;
f(vdofs) = 0 ;

K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

disp([num2str(toc),'   SOLUTION'])
u  = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'   POST PROCESSING'])

disp([num2str(toc),'      Deformed configuration'])

% Plot numerical deformed configuration
figure
hold on
fac = 50;
plot_mesh(node+fac*[u_x u_y],element,elemType,'r-');
title(' Numerical deformed configuration ')
set(gcf, 'color', 'white');
axis off

% Compute stress at nodes and plot
disp([num2str(toc),'      Stress computation'])

stressPoints =[-1 -1;1 -1;1 1;-1 1];
stress = zeros(numelem, 4, 3);
         
for e = 1 : numelem
    sctr = element(e,:);
    nn   = length(sctr);
    U     = element_disp(e,pos,enrich_node,u);
    for ij=1:nn
        pt = stressPoints(ij,:);   
        [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip,alpha);
        strain = B*U;
        stress(e,ij,:) = C*strain;
    end
end

 plotContour(stress);

% ----------------------------------------------------
%  Stress 55intensity factor computation For LEFT crack
% -----------------------------------------------------
    
disp([num2str(toc),'      Stress intensity factors computation'])

Stress_Int_Factor_1 %%--------STRESS INTENSITY FACTOR--------%%
% Compute the exact SIFs

F = 1.12 - 0.23*(a/L) + 10.55*(a/L)^2 - 21.72*(a/L)^3 + 30.39*(a/L)^4;
Kexact = F * sigmato*sqrt(pi*a)
acg=a;

alpha = theta_C+alpha;
anglereq = alpha*180/pi;
QT = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
pat = [];
pat = [pat; a K1 K2 K1eq];
aa = a;
aI = aImax;

% =========================================================================
%                   CARCK PROPAGATION COMPUTATION
% =========================================================================

xCr(3,:)  = [xTip(1,1)+aI*cos(alpha) xTip(1,2)+aI*sin(alpha)]; % New left  crack segment

xTip(2,:) = [xTip(1,1)+aI*cos(alpha) xTip(1,2)+aI*sin(alpha)]; % new left crack tip

jj=2;
clear K
clear enrich_node
clear pos
disp(K1eq);
% ====================================================================== %
%               While loop for Fatigue crack propagation
% ====================================================================== %
kext(ni)= Kexact;
sif(ni)=K1eq;
K1_final = [];
K2_final = [];
while K1eq < KIC % check whether SIF is still less than fracture toughness
    ni=ni+1;
    xTip(jj-1,1)= xCr(jj,1);
    xTip(jj-1,2)= xCr(jj,2);
    
    xTip(jj,1)= xCr(jj+1,1);  % New crack tip
    xTip(jj,2)= xCr(jj+1,2);
    
    xTip(jj,:)= [xCr(jj+1,1) xCr(jj+1,2)];
    
    xa  = xTip(jj-1,1); ya = xTip(jj-1,2);
    xb  = xTip(jj,1);   yb = xTip(jj,2);
    
    seg2   = xCr(jj+1,:) - xCr(jj,:);
    seg22  = xCr(jj,:) - xCr(jj+1,:);  %  New segment
    t2  = 1/norm(seg2)*seg2;
    t22 = 1/norm(seg22)*seg22;
    lsL=zeros(numnode,3);
    
    for i = 1 : numnode
        x = node(i,1);
        y = node(i,2);
        l = sqrt((xb-xa)*(xb-xa)+(yb-ya)*(yb-ya)) ;     % crack length
        phi = (ya-yb)*x + (xb-xa)*y + (xa*yb-xb*ya);    % area
        lsL(i,1) = phi/l;                               % normal LS                    % y-distance from node to crack line
        lsL(i,2) = ([x y]-xTip(jj,:))*t2';
        lsL(i,3)=([x y]-xTip(jj-1,:))*t22';
    end
    
    split_elem = [];
    enrich_node = zeros(numnode,1);
    count1 = 0;
    count2 = 0;
    tip_elem = [];
    for iel = 1 : numelem
        sctr = element(iel,:);
        phi  = lsL(sctr,1);
        psi  = lsL(sctr,2);
        psi2  = lsL(sctr,3);
        if ( max(phi)*min(phi) < 0 )
            if max(psi) < 0 && max(psi2) < 0
                count1 = count1 + 1 ; % ah, one split element
                split_elem(count1) = iel;
            elseif max(psi)*min(psi) < 0
                count2 = count2 + 1 ; % ah, one tip element
                tip_elem(count2) = iel;
            end
        end
    end
    
    Fa = union(split_elem,tip_elem);
    ls(unique(element(Fa,:)),1) = lsL(unique(element(Fa,:)),1);
    split_elem  = union(Felement, split_elem);
    split_nodes = unique(element(split_elem,:));
    trr = element(tip_elem,:);
    tip_nodes   =  unique(trr');
    split_nodes = setdiff(split_nodes,tip_nodes);
    Felement    = union(split_elem,tip_elem);
    enrich_node(split_nodes(:,1)) = 1;
    enrich_node(tip_nodes(:,1))   = 2;
    
%     Plot mesh and enriched nodes to check
%     figure
%     hold on
%     cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
%     set(cntr,'LineWidth',3);
%     plot_mesh(node,element,elemType,'b-');
%     cr = plot(xCr(:,1),xCr(:,2),'r-');
%     set(cr,'LineWidth',3);
%     n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
%     n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rh');
%     set(n1,'MarkerSize',10);
%     set(n2,'MarkerSize',10);
%     set(gcf, 'color', 'white');
%     plot(node(dispNodes,1),node(dispNodes,2),'ks');
%     axis equal
%     axis off
    
    total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;
    
    K = zeros(total_unknown,total_unknown);
    f = zeros(total_unknown,1);
    
    % ***********************************
    %    Stiffness matrix computation
    % ***********************************
    
    pos = zeros(numnode,1);
    nsnode = 0 ;
    ntnode = 0 ;
    for i = 1 : numnode
        if (enrich_node(i) == 1)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            nsnode = nsnode + 1 ;
        elseif (enrich_node(i) == 2)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            ntnode = ntnode + 1 ;
        end
    end
    
    q = [];
    disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
    % -----------------
    % Loop on elements
    % -----------------
    for iel =1: numelem
        sctr = element(iel,:); % element connectivity
        nn   = length(sctr);   % number of nodes per element

        % Choose Gauss quadrature rules for elements
        if (ismember(iel,split_elem))     % split element
            order = 2;
            phi   = ls(sctr,1);
            [W,Q] = discontQ4quad(order,phi);
        elseif (ismember(iel,tip_elem))   % tip element
            order = 7;
            phi   = ls(sctr,1);
            nodes = node(sctr,:);
            [W,Q] = disTipQ4quad(order,phi,nodes,xTip(jj,:));
        elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
            order = 4;
            [W,Q] = quadrature(order,'GAUSS',2);
        else
            order = 2;
            [W,Q] = quadrature(order,'GAUSS',2);
        end
        % Transform these Gauss points to global coords
        % for plotting only
        for igp =1 : size(W,1)
            gpnt = Q(igp,:);
            [N,dNdxi]=lagrange_basis('Q4',gpnt);
            Gpnt = N' * node(sctr,:); % global GP
            q = [q;Gpnt];
        end
        
        sctrB = assembly(iel,enrich_node,pos);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);  % quadrature point            
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip(jj,:),alpha); % B matrix            
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0); % Stiffness matrix
        end                  % end of looping on GPs
    end                      % end of looping on elements
    
    disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])
    
    % The top edge is applied a traction along Y direction
    [W,Q]=quadrature(1,'GAUSS',1);
    for e = 1:size(topEdge,1)
        sctr = topEdge(e,:);
        sctry = sctr.*2 ;
        
        for ij=1:size(W,1)
            pt = Q(ij,:);
            wt = W(ij);
            N  = lagrange_basis('L2',pt);
            J0 = abs(node(sctr(2)) - node(sctr(1)) )/2;
            f(sctry) = f(sctry) + N*sigmato*det(J0)*wt;
        end   % of quadrature loop
    end       % of element loop
    
    disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])
    
    bcwt = mean(diag(K)); % a measure of the average size of an element in K
    % used to keep the conditioning of the K matrix
    
    vdofs = dispNodes.*2;
    udofs = 1; % for lower left corner node
    
    f(udofs) = 0 ;
    f(vdofs) = 0 ;
    
    K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
    K(vdofs,:) = 0;
    K(:,udofs) = 0;
    K(:,vdofs) = 0;
    K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
    K(vdofs,vdofs) = bcwt*speye(length(vdofs));
    
    
    disp([num2str(toc),'   SOLUTION'])
    u   = K\f;
    u_x = u(1:2:2*numnode) ;
    u_y = u(2:2:2*numnode) ;
    
    
%     disp([num2str(toc),'   POST PROCESSING'])
%     
%     disp([num2str(toc),'      Deformed configuration'])
% 
%     % Plot numerical deformed configuration
%     figure
%     hold on
%     fac = 1;
%     plot_mesh(node+fac*[u_x u_y],element,elemType,'r-');
%     title(' Numerical deformed configuration ')
%     set(gcf, 'color', 'white');
%     axis off
% 
    % Compute stress at nodes and plot
%     disp([num2str(toc),'      Stress computation'])
%     
%     stressPoints=[-1 -1;1 -1;1 1;-1 1];
%     stress = zeros(numelem, 4, 3);
%     
%     for e = 1 : numelem
%         sctr = element(e,:);
%         nn   = length(sctr);
%         U     = element_disp(e,pos,enrich_node,u);
%         for ij=1:nn
%             pt = stressPoints(ij,:);
%             [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip(jj,:),alpha);
%             strain = B*U;
%             stress(e,ij,:) = C*strain;
%         end
%     end
%     
%     plotContour(stress);
    
    clear Jdomain
    
    disp([num2str(toc),'      Stress intensity factors computation'])  
    
    Stress_Int_Factor_2 %%--------STRESS INTENSITY FACTOR--------%%
    K1_final = [K1_final K1];
    K2_final = [K2_final K2];
    
    acg=acg+aImax
    F = 1.12 - 0.23*(acg/L) + 10.55*(acg/L)^2 - 21.72*(acg/L)^3 + 30.39*(acg/L)^4;
    Kexact = F * sigmato*sqrt(pi*acg)
    

    alpha = theta_C+alpha;
    anglereq = alpha*180/pi
    QT = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];   
    aI = aImax;
       
    % =========================================================================
    %                         FOR LEFT EDGE CARCK
    % =========================================================================
    
    xCr(jj+2,:) = [xTip(jj,1)+aI*cos(alpha) xTip(jj,2)+aI*sin(alpha)]; % New left  crack segment
    
    xTip(jj+1,:) = [xTip(jj,1)+aI*cos(alpha) xTip(jj,2)+aI*sin(alpha)]; % new left crack tip
    
    jj=jj+1;
    kext(ni)= Kexact;
    sif(ni)=K1eq;
end
% SIF=sif';
% T = table(SIF);
% disp(T(1:ni,:));
% filename = 'E:\XFEM\Only crack\comparison.xlsx';
% writetable(T,filename,'Sheet',1,'Range','A1');
% 
% KEXACT=kext';
% P = table(KEXACT);
% disp(P(1:ni,:));
% filename = 'E:\XFEM\Only crack\comparison.xlsx';
% writetable(P,filename,'Sheet',1,'Range','B1');


           