function [xh,yh,rh,numh] = Data_inc(numincls)

nnx = 8;
nny = 10;

xhh = randi([1 nnx*nny],numincls,1);

pt11 = 1000*[0.01 0.01] ;
pt21 = 1000*[0.09 0.01] ;
pt31 = 1000*[0.09 0.19] ;
pt41 = 1000*[0.01 0.19] ;
elemType = 'Q4' ;

[node1,element1] = meshRectangularRegion(pt11, pt21, pt31, pt41, nnx,nny,elemType);
nn1 = unique(xhh);
numh = size(nn1,1);
xh = node1(nn1,1);
yh = node1(nn1,2);
rh = randi([350 400],numincls,1)/100;

nn11 =[];
while numh<numincls
    xhh = randi([1 nnx*nny],(numincls),1);
    nn9 = setdiff(xhh,nn1);
    nn10 = numincls-numh;
    nn11 =[];
    if size(nn9,1)> nn10    
       nn11 = [nn11; nn9(1:nn10)];
       xh = [xh; node1(nn9(1:nn10), 1)];
       yh = [yh; node1(nn9(1:nn10), 2)];
       numh = size(xh,1);
    else
       nn11 = [nn11; nn9(1,:)];
       xh = [xh; node1( nn9(1,:), 1)];
       yh = [yh; node1( nn9(1,:), 2)]; 
       numh = size(xh,1);
    end
end

end
