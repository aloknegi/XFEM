clear all;
close all;
clc;
tic;

global nnx nny node element PLOT  L D VOID elemType Em num Cm Ci Ei nui
% Dimension of the domain
% (it is simply a rectangular region D x L)
L = 100 ;
D = 200 ;

% Loading
sigmato = 2.5;
KIC = 56.08879178;
M = 3.21;
aImax = 2; % maximum size of crack increment
ni=1;

PLOT(5,2) = 1;
VOID = [];

% DATA INPUT
% numincls = 30;
% [ xh, yh, rh, numincls  ] = Data_inc( numincls );

numincls = 4;
[xh,yh,rh]=DATA_INCLNS(numincls);
hole = [xh' yh' rh'];

% Material properties
Em  = 8.858398707e3;
num = 0.344864865;
Ei  = 2e3*ones(1,numincls);
nui = 0.3*ones(1,numincls);
INC = [xh' yh' rh'];

Ar =0;
for i=1:numincls
    Ar = Ar+(3.14*(rh(i))^2);
end
perchange = Ar*100/(L*D)

stressState='PLANE_STRESS';

% Compliance matrix C
Cm = Em/(1-num^2)*[ 1  num  0;
    num   1   0 ;
    0   0    0.5*(1-num) ];
for j=1:numincls
    Ci(:,:,j) = Ei(j)/(1-nui(j)^2)*[ 1   nui(j)   0;
        nui(j)    1    0 ;
        0     0     0.5*(1-nui(j))];
end

% Main Crack Data
cc = [L/2 D/2]    ;                  % crack center coordinates
a = 20;                              % crack length
ang = 0;   %%% Crack Angle WRT Horizontal axis
an = pi/180*ang;
xCr   = [cc(1,1)-a/2*cos(an)    cc(1,2)-a/2*sin(an);    cc(1,1)+a/2*cos(an)    cc(1,2)+a/2*sin(an)];
xTipR  = [xCr(2,1)  xCr(2,2)];
xTipL = [xCr(1,1)  xCr(1,2)];

seg    = xCr(2,:) - xCr(1,:);        % Tip Segment
seg1   = xCr(1,:) - xCr(2,:);       % SEcond Function for left tip
alphaR = atan2(seg(2),seg(1));       % Inclination Angle
alphaL = atan2(seg1(2),seg1(1));
QTR    = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];
QTL    = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

% +++++++++++++++++++++++++++++
%            MESHING
% +++++++++++++++++++++++++++++

disp([num2str(toc),'   MESH GENERATION'])
% Number of nodes along two directions
nnx = 40;
nny = 80;

% Four corner points
pt1 = [0 0] ;
pt2 = [L 0] ;
pt3 = [L D] ;
pt4 = [0 D] ;

elemType = 'Q4' ;
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);

numnode = size(node,1);
numelem = size(element,1);

uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)
topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';
% GET NODES ON DIRICHLET BOUNDARY AND ESSENTIAL BOUNDARY
dispNodes  = unique(botEdge);
tracNodes  = unique(topEdge);          % returns the same values as in topedge but with no repetitions

disp([num2str(toc),'LEVEL SET INITIALIZATION'])

LevelSet_Crack

enrich_node = zeros(numnode,1);
split_elem  = setdiff(split_elem,tip_elem);
Felement    = union(split_elem,tip_elem);
split_nodes = unique(element(split_elem,:));
trr         = element(tip_elem,:);
tip_nodes   =  unique(trr');
split_nodes =  setdiff(split_nodes,tip_nodes);

% LEVEL SET FOR INCLUSIONS

LevelSet_Inclns

enrich_node(split_nodes(:,1))    = 1;
enrich_node(tip_nodes(:,1))      = 2;

figure
hold on
cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
set(cntr,'LineWidth',3);
plot_mesh(node,element,elemType,'b-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
% n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
% n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
% set(n1,'MarkerSize',5);
% set(n2,'MarkerSize',5);
theta = -pi:0.1:pi;
np=size(theta,2);
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
% plot(node(dispNodes,1),node(dispNodes,2),'ks');
set(gcf, 'color', 'white');
axis equal
axis off

for j=1:numincls
    ns=size(find(split_nodes_h (:,j)),1);
    split_nodes=union(split_nodes,split_nodes_h(1:ns,j));
end

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;

K = sparse(total_unknown,total_unknown);

FMech = zeros(total_unknown,1);                       % f-matrix

pos = zeros(numnode,1);
nsnode = 0 ; ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1 || enrich_node(i) == 3)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end

T_split_nodes=[];
T_split_elem_h=[];
for j=1:numincls
    ns = size(find(split_nodes_h(:,j)),1);
    T_split_nodes  = [T_split_nodes; split_nodes_h(1:ns,j)];
    T_split_elem_h = [T_split_elem_h; Tot_split_elem_h(j,:)'];
end


disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
Stiffness_Matrix

% ************************
%    NODAL FORCE VECTOR
% ************************
disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;
    
    for q=1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        FMech(sctry)=FMech(sctry) + N*sigmato*det(J0)*wt;
        
    end   % of quadrature loop
end       % of element loop
% -------------------------------------

f=FMech;

% **********************************
%    ESSENTIAL BOUNDARY CONDITION
% **********************************
disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K));

vdofs = dispNodes.*2;
udofs = 1; % for lower left corner node

f(udofs) = 0 ;
f(vdofs) = 0 ;
K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

% **********************************
%          POST PROCESSING
% **********************************
disp([num2str(toc),'   POST PROCESSING'])

% **********************************
%       SOLUTION OF EQUATIONS
% **********************************
disp([num2str(toc),'   SOLUTION'])
u   = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'      Deformed configuration'])
% --------------------------------------------------
%Plot numerical deformed configuration
figure
hold on
fac = 100;
plot_mesh(node+fac*[u_x u_y],element,elemType,'b-');
title(' Numerical deformed configuration ')
set(gcf, 'color', 'white');
axis equal
axis on

% --------------------------------------------------
% break
% ---------------------------------------------
% Compute stress at nodes and plot
disp([num2str(toc),'      Stress computation'])

Stress_Computation

plotContour(stress);

% -------------------------------------------------------------------------
disp([num2str(toc),'      Stress intensity factors computation'])
% -------------------------------------------------------------------------
cL = a/8;
cR = a/8;

SIF_Left

alphaL = theta_CL+alphaL;
anglereqL = alphaL*180/pi ;
QTL = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

SIF_Right

alphaR = theta_CR+alphaR;
anglereqR = alphaR*180/pi;
QTR = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];

% plot
figure
hold on
% plot the circle
theta = -pi:0.1:pi;
xoL = xTipL(1,1) + radiusL*cos(theta) ;
yoL = xTipL(1,2) + radiusL*sin(theta) ;
plot(xoL,yoL,'k-');
plot_mesh(node,element,'Q4','b-')
plot_mesh(node,element(JdomainL,:),'Q4','r-')
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(cr,'LineWidth',2);
xoR = xTipR(1,1) + radiusR*cos(theta) ;
yoR = xTipR(1,2) + radiusR*sin(theta) ;
plot(xoR,yoR,'k-');
plot_mesh(node,element(JdomainR,:),'Q4','r-')
theta = 0:0.5:360;
np=size(theta,2);
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(cr,'LineWidth',3);
set(gcf, 'color', 'white');

pat = [];
pat = [pat; 0 0 K1L K2L K1R K2R K1eqL K1eqR ];
aaL = 0;
aaR = 0;

% Compute the exact SIFs

F = 1.0 + 0.128*(a/L) - 0.288*(a/L)^2 + 1.523*(a/L)^3 ;
F1 = sqrt(1+0.50*(a/2/L)^2+20.46*(a/2/L)^4+81.72*(a/2/L)^6);

KexactGdouts = F * sigmato*sqrt(pi*a/2);

KexactParez = F1 * sigmato*sqrt(pi*a/2);

% aIL = aImax; aIR = aImax;

if K1eqL >= K1eqR % comparision to find out the dominant crack tip
    
    aIL = aImax;
    
    aIR = aImax*((K1eqR/K1eqL)^M);
else
    
    aIR = aImax;
    
    aIL = aImax*((K1eqL/K1eqR)^M);
end

if K1eqL >=K1eqR
    K1eq_MAX = K1eqL;
else
    K1eq_MAX = K1eqR;
end
sif1(ni)= K1eqL;
sif2(ni)= K1eqR;

% K1eq_MAX is Used for crack propagation criterion

xCr(3,:) = [xTipR(1,1)+aIR*cos(alphaR) xTipR(1,2)+aIR*sin(alphaR)];

xCr = [[xTipL(1,1)+aIL*cos(alphaL) xTipL(1,2)+aIL*sin(alphaL)];xCr];

xTipR(2,:) = xCr(4,:); % new right crack tip
xTipL(2,:) = xCr(1,:); % new left crack tip
jj = 2;

% ====================================================================== %
%               While loop for Fatigue crack propagation
% ====================================================================== %

while K1eq_MAX < KIC % check whether SIF is still less than fracture toughness
    ni=ni+1;
    
    clear K JdomainR JdomainL pos enrich_node
    
    Left_Right_Crack
    
    FaL = union(split_elemL,tip_elemL);
    ls(unique(element(FaL,:)),1) = lsLL(unique(element(FaL,:)),1);
    
    FaR = union(split_elemR,tip_elemR);
    ls(unique(element(FaR,:)),1) = lsRR(unique(element(FaR,:)),1);
    
    split_elem  = union(Felement, split_elemL);
    split_elem  = union(split_elem, split_elemR);
    split_nodes = unique(element(split_elem,:));
    trrL        = element(tip_elemL,:);
    tip_nodesL  =  unique(trrL');
    trrR        = element(tip_elemR,:);
    tip_nodesR  =  unique(trrR');
    tip_nodes   =  union(tip_nodesL, tip_nodesR);
    split_nodes =  setdiff(split_nodes,tip_nodes);
    tip_elem    =  union(tip_elemL,tip_elemR);
    Felement    =  union(split_elem,tip_elem);
    enrich_node = zeros(numnode,1);
    
    for j=1:numincls
        xx=find(split_nodes(:,1));
        n9=size(xx,1);
        yy=setdiff(split_nodes_h(1:n8,j),split_nodes(1:n9,1));
        n10=size(yy,1);
        split_nodes_h(1:n10,j) = setdiff(split_nodes_h(1:n8,j),split_nodes(1:n9,1));
        zz=setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
        n11=size(zz,1);
        split_nodes_h(1:n11,j) = setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
        T_split_nodes = setdiff(T_split_nodes,split_nodes);
        T_split_nodes = setdiff(T_split_nodes,tip_nodes);
        
        ns=size(find(split_nodes_h (:,j)),1);
        enrich_node(nonzeros(split_nodes_h (1:ns,j))) = 3;
    end
    
    enrich_node(nonzeros(split_nodes(:,1))) = 1;
    enrich_node(tip_nodes(:,1)) = 2;
    
    disp([num2str(toc),'   PLOT NODES AND GAUSS POINTS'])
    
    % % ++++++++++++++++++++++++++++++++++++ % %
    % PLOT NODES, BACKGROUND MESH, GPOINTS %
    % % ++++++++++++++++++++++++++++++++++++ % %
    
    figure
    hold on
    cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
    set(cntr,'LineWidth',3);
    plot_mesh(node,element,elemType,'b-');
    cr = plot(xCr(:,1),xCr(:,2),'r-');
    set(cr,'LineWidth',3);
    n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
    n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
    set(n1,'MarkerSize',5);
    set(n2,'MarkerSize',5);
    theta = -pi:0.1:pi;
    np=size(theta,2);
    for j=1:numincls
        xx(j,1:np)=xh(j)+rh(j)*cos(theta);
        yy(j,1:np)=yh(j)+rh(j)*sin(theta);
        plot(xx(j,1:np),yy(j,1:np),'k-')
    end
    plot(node(dispNodes,1),node(dispNodes,2),'ks');
    set(gcf, 'color', 'white');
    axis off
    axis equal
    
    for j=1:numincls
        ns=size(find(split_nodes_h (:,j)),1);
        split_nodes=union(split_nodes,split_nodes_h(1:ns,j));
    end
    
    total_unknown = numnode*2 + size(nonzeros(split_nodes),1)*1*2 + size(tip_nodes,1)*4*2;
    K = sparse(total_unknown,total_unknown);
    FMech = zeros(total_unknown,1);
    
    % ***********************************
    %    Stiffness matrix computation
    % ***********************************
    
    disp([num2str(toc),'   DOMAIN ASSEMBLY'])
    
    pos = zeros(numnode,1);
    nsnode = 0 ; ntnode = 0 ;
    for i = 1 : numnode
        if (enrich_node(i) == 1 || enrich_node(i) == 3)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            nsnode = nsnode + 1 ;
        elseif (enrich_node(i) == 2)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            ntnode = ntnode + 1 ;
        end
    end
    
    T_split_nodes=[];
    T_split_elem_h=[];
    for j=1:numincls
        ns=size(find(split_nodes_h(:,j)),1);
        T_split_nodes=[T_split_nodes; split_nodes_h(1:ns,j)];
        T_split_elem_h=[T_split_elem_h;Tot_split_elem_h(j,:)'];
    end
    
    disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
    
    Stiffness_Matrix1
    
    clear qq
    
    % ************************
    %    NODAL FORCE VECTOR
    % ************************
    disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])
    
    % The top edge is applied a traction along Y direction
    [W,Q]=quadrature(1,'GAUSS',1);
    for e = 1:size(topEdge,1)
        sctr = topEdge(e,:);
        sctry = sctr.*2 ;
        for q=1:size(W,1)
            pt = Q(q,:);
            wt = W(q);
            N  = lagrange_basis('L2',pt);
            J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
            FMech(sctry)=FMech(sctry) + N*sigmato*det(J0)*wt;
        end   % of quadrature loop
    end       % of element loop
    % -------------------------------------
    
    f=FMech;
    
    % **********************************
    %    ESSENTIAL BOUNDARY CONDITION
    % **********************************
    disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])
    
    bcwt = mean(diag(K));
    
    vdofs = dispNodes.*2;
    udofs = 1; % for lower left corner node
    
    f(udofs) = 0;
    f(vdofs) = 0;
    K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
    K(vdofs,:) = 0;
    K(:,udofs) = 0;
    K(:,vdofs) = 0;
    K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
    K(vdofs,vdofs) = bcwt*speye(length(vdofs));
    
    % **********************************
    %          POST PROCESSING
    % **********************************
    disp([num2str(toc),'   POST PROCESSING'])
    
    % **********************************
    %       SOLUTION OF EQUATIONS
    % **********************************
    disp([num2str(toc),'   SOLUTION'])
    u   = K\f;
    u_x = u(1:2:2*numnode) ;
    u_y = u(2:2:2*numnode) ;
    
    disp([num2str(toc),'      Deformed configuration'])
    % --------------------------------------------------
    %Plot numerical deformed configuration
    % figure
    % hold on
    % fac = 100;
    % plot_mesh(node+fac*[u_x u_y],element,elemType,'g-');
    % title(' Numerical deformed configuration ')
    % set(gcf, 'color', 'white');
    % axis off
    % --------------------------------------------------
    % break
    % --------------------------------------------------
    
    disp([num2str(toc),'      Stress computation'])
    
    Stress_Computation1
    
    %  plotContour(stress);
    
    disp([num2str(toc),'      Stress intensity factors computation'])
    
    SIF_Left1
    
    alphaL = theta_CL+alphaL;
    anglereqL = alphaL*180/pi
    QTL = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];
    
    SIF_Right1
    
    alphaR = theta_CR+alphaR;
    anglereqR = alphaR*180/pi
    QTR = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];
    
    % plot
    figure
    hold on
    % plot the circle
    theta = -pi:0.1:pi;
    xoL = xTipL(jj,1) + radiusL*cos(theta) ;
    yoL = xTipL(jj,2) + radiusL*sin(theta) ;
    plot(xoL,yoL,'k-');
    plot_mesh(node,element,'Q4','b-')
    plot_mesh(node,element(JdomainL,:),'Q4','r-')
    cr = plot(xCr(:,1),xCr(:,2),'k-');
    set(cr,'LineWidth',2);
    xoR = xTipR(jj,1) + radiusR*cos(theta) ;
    yoR = xTipR(jj,2) + radiusR*sin(theta) ;
    plot(xoR,yoR,'k-');
    plot_mesh(node,element(JdomainR,:),'Q4','r-')
    theta = 0:0.5:360;
    np=size(theta,2);
    np=size(theta,2);
    for j=1:numincls
        xx(j,1:np)=xh(j)+rh(j)*cos(theta);
        yy(j,1:np)=yh(j)+rh(j)*sin(theta);
        plot(xx(j,1:np),yy(j,1:np),'k-')
    end
    cr = plot(xCr(:,1),xCr(:,2),'k-');
    set(cr,'LineWidth',3);
    set(gcf, 'color', 'white');
    
    aaL = aaL + aIL;
    aaR = aaR + aIR;
    pat = [pat; aaL aaR K1L K2L K1R K2R K1eqL K1eqR];
    
    % Compute the exact SIFs
    a = a+2*aImax;
    F = 1.0 + 0.128*(a/L) - 0.288*(a/L)^2 + 1.523*(a/L)^3 ;
    F1 = sqrt(1+0.50*(a/2/L)^2+20.46*(a/2/L)^4+81.72*(a/2/L)^6);
    
    KexactGdouts = F * sigmato*sqrt(pi*a/2);
    
    KexactParez = F1 * sigmato*sqrt(pi*a/2);
    
    %     aIL = aImax; aIR = aImax;
    
    if K1eqL >= K1eqR % comparision to find out the dominant crack tip
        
        aIL = aImax;
        
        aIR = aImax*((K1eqR/K1eqL)^M);
    else
        
        aIR = aImax;
        
        aIL = aImax*((K1eqL/K1eqR)^M);
    end
    
    if K1eqL >=K1eqR
        K1eq_MAX = K1eqL;
    else
        K1eq_MAX = K1eqR;
    end
    
    % K1eq_MAX is Used for crack propagation criterion
    ss = size(xCr,1);
    xCr = [[xTipL(jj,1)+aIL*cos(alphaL) xTipL(jj,2)+aIL*sin(alphaL)];xCr];% New right crack segment
    
    xCr(ss+2,:) = [xTipR(jj,1)+aIR*cos(alphaR) xTipR(jj,2)+aIR*sin(alphaR)]; % New left  crack segment
    
    xTipR(jj+1,:) = xCr(ss+2,:); % new right crack tip
    xTipL(jj+1,:) = xCr(1,:);    % new left crack tip
    
    jj = jj+1;
        jj = jj+1;
    sif1(ni)=K1eqL;
    sif2(ni)=K1eqR;
end

SIFL=sif1';
SIFR=sif2';
T = table(SIFL,SIFR);
disp(T(1:ni,:));
filename = 'E:\Thesis\01. Code\Hole and Inclusions\centre crack\3centreswcnt_hole_inclusion.xlsx';
writetable(T,filename,'Sheet',1,'Range','A1');
