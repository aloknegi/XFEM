q = [];
stress = zeros(numelem,4,3);
for iel = 1:numelem
    sctr = element(iel,:); % element connectivity
    Q = [1 1; 1 -1; -1 1; -1 -1]; % four stress points to calculate stress
    W = [1;1;1;1];
    GZgp=zeros(4,9);
    
    for i = 1 : size(W,1)
        gpnt = Q(i,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:);    % global GP
        q = [q;Gpnt];
        
        for j=1:numincls
            Zgp= N' * ls_h(sctr,j);
            GZgp(i,j) = Zgp;
        end
        
    end
    
    U = element_disp(iel,pos,enrich_node,u);
    
    for kk = 1 : size(W,1)
        pt = Q(kk,:);                             % quadrature point
        if ismember(iel,split_elem)
            if GZgp(kk,1) > 0
                C = Cm;E=Em; nu=num;
            else
                C = Ci(:,:,1);E=Ei; nu=nui;
            end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
        elseif (ismember(iel,T_split_elem_h) || any(intersect(T_split_nodes,sctr)) ~= 0)
            for j=1:numincls
                ns=size(find(split_nodes_h(:,j)),1);
                if (ismember(iel,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
                    if GZgp(kk,j) > 0
                        C = Cm;E=Em; nu=num;
                    else
                        C = Ci(:,:,j);E=Ei; nu=nui;
                    end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha,ls_h(:,j));
                end
            end
        else
            C = Cm;E=Em; nu=num;
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
        end
        
        strain = B*U;
        stress(iel,kk,:) = C*strain;
        
    end                  % end of looping on GPs
end                      % end of looping on elements

