DD = 6.85e-8;
M = 3.21;
NN = 0;
NC = [];

KIC = 29;
ss = size(pat(:,1));
K1eq = pat(:,4)./sqrt(1000);

for i=1:ss
    NN = NN + aImax/(DD*K1eq(i)^M); %%%%%%  Life calculation
    NC = [NC; NN];
end

crack_length = [20 24 28 32 36 40 44 48];

figure
hold on
plot(pat(:,1),K1eq,'-bo','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
% plot(crack_length,K1eq,'-bs','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
xlabel('Crack Length (mm)')
ylabel('Stress Intensity Factors (N/mm^{3/2})')
% title('Variation of SIFs with Crack Length')
% axis ([15 50 10 35])
set(gcf,'color','white');
legend('K_I',2)
grid on

ss1 = size(NC,1);
da = ((KIC-K1eq(ss1-1))*aImax)/(K1eq(ss1)-K1eq(ss1-1));
Li = da/(DD*KIC^M);
Life = NC(ss1-1)+ Li
Cracklength = pat(ss1-1,1)+da
% Cracklength = crack_length(ss1-1)+da
CrackExtension = pat(1:ss1,1);

figure
hold on
plot(NC,pat(1:size(NC,1),1),'-bs','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
% plot(NC,crack_length,'-bs','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
plot(Life,Cracklength,'g*')
ylabel('Crack Extension (mm)')
xlabel(' No. of cycles')
set(gcf,'color','white');
% axis ([15000 5e4 15 50])
grid on

