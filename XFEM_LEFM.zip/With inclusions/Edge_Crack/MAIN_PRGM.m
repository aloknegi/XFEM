clear all
state = 0;
tic;
close all;
clc
global nnx nny node element PLOT VOID L D INC

L = 100;
D = 200;

nnx = 40;
nny = 80;

PLOT(5,2) = 1;
VOID = [];

% Loading
sigmato = 2.5;
KIC = 19.63924642;
aImax = 2;
ni=1;

numincls = 4;
[xh,yh,rh]=DATA_INCLS(numincls);
Em  = 2.9e3;
num = 0.35;
Ei=2.5e3*ones(1,numincls);
nui=0.3*ones(1,numincls);
INC = [xh' yh' rh'];

stressState='PLANE_STRESS';

% Compliance matrix C
Cm = (Em/(1-num^2))*[ 1     num   0;
                      num   1     0;
                      0     0     0.5*(1-num)];
% Cm = Em/(1+num)/(1-2*num)*[ 1-num  num  0;
%     num    1-num 0;
%     0     0  0.5-num ];

for j=1:numincls
    Ci(:,:,j) = (Ei(j)/(1-nui(j)^2))*[ 1         nui(j)   0;
                                     nui(j)    1        0;
                                     0         0        0.5*(1-nui(j))];
end
% Main Crack Data
a = 8;         % Left Crack length
angle = 0;      % Inclination angle in degree for left crack
alpha = pi*angle/180;
xedge = 0;
yedge = 100;
xCr   = [ xedge yedge; xedge+a*cos(alpha) yedge+a*sin(alpha)];      % crack coordinates
xTip  = [xedge+a*cos(alpha) yedge+a*sin(alpha)];                    % crack tip coordinates
seg   = xCr(2,:) - xCr(1,:);   % tip segment
QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];

disp([num2str(toc),'   MESH GENERATION'])

% Four corner points
pt1 = [0 0] ;
pt2 = [L 0] ;
pt3 = [L D] ;
pt4 = [0 D] ;

elemType = 'Q4' ;
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);

numnode = size(node,1);
numelem = size(element,1);

uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)

topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';

dispNodes  = unique(botEdge);
tracNodes  = unique(topEdge);

% +++++++++++++++++++++++++++++++++++++
%  LEVEL SET INITIALIZATION SELECTION OF ENRICHED NODES
% +++++++++++++++++++++++++++++++++++++

% FOR LEFT EDGE CRACK

disp([num2str(toc),'   LEVEL SET INITIALIZATION'])

x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
ls  = zeros(numnode,2);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;                                               % Normal LS
    ls(i,2) = ([x y]-xTip)*t';                                     % Tangent LS
end

enrich_node = zeros(numnode,1);
count1 = 0;
count2 = 0;
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elem(count2) = iel;
            enrich_node(sctr)   = 2;
        end
    end
end

split_nodes = find(enrich_node == 1);
split_nodes1 = split_nodes;
tip_nodes   = find(enrich_node == 2);
Felement = union(split_elem,tip_elem);

% +++++++++++++++++++++++++++++++++++++
%        LEVEL SET INITIALIZATION
%      SELECTION OF ENRICHED NODES
% +++++++++++++++++++++++++++++++++++++

% LEVEL SET FOR INCLUSIONS

ls_h = zeros(numnode,numincls);
rr   = zeros(numnode,numincls);
for i=1:numnode
    xi=node(i,1);
    yi=node(i,2);
    for j=1:numincls
        aa = sqrt((xi-xh(j))^2+(yi-yh(j))^2)-rh(j);
        ls_h(i,j) = aa;
        d=sqrt((xi-xh(j))^2+(yi-yh(j))^2);
        rr(i,j)= d;
    end
end

for j=1:numincls
    tst1=[];tst2=[];tst=[];
    tst1=rr(:,j)-rh(j);
    tst2=tst1(element)';
    n1=size(find(min(tst2<=0)),2);
    hole_elem(j,1:n1) = find(min(tst2<=0));
    tst = max(tst2).*min(tst2);
    n2=size(find(tst<=0),2);
    tt=find(tst<=0);
    split_elem_h(j,1:n2) = tt(1:n2);
    pp=find(hole_elem(j,:));
    n3=size(pp,2);
    n4=size(unique(element(hole_elem(j,1:n3),:)),1);
    hole_nodes_s(1:n4,j) = unique(element(hole_elem(j,1:n3),:));
    ss=union(split_elem_h(j,:),hole_elem(j,:));
    n5=size(union(split_elem_h(j,:),hole_elem(j,:)),2);
    Tot_split_elem_h(j,1:n5) = ss(1:n5);
    n6=size(find(split_elem_h(j,:)),2);
    n7=size(unique(element(split_elem_h(j,1:n6),:)),1);
    split_nodes_h(1:n7,j) = unique(element(split_elem_h(j,1:n6),:));
    qq=find(split_nodes_h(:,j));
    n8=size(qq,1);
    xx=find(split_nodes(:,1));
    n9=size(xx,1);
    yy=setdiff(split_nodes_h(1:n8,j),split_nodes(1:n9,1));
    n10=size(yy,1);
    split_nodes_h(1:n10,j) = setdiff(split_nodes_h(1:n8,j),split_nodes(1:n9,1));
    zz=setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
    n11=size(zz,1);
    split_nodes_h(1:n11,j) = setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
    
    ns=size(find(split_nodes_h (:,j)),1);
    enrich_node(split_nodes_h (1:ns,j)) = 3;
end

enrich_node(split_nodes(:,1))    = 1;
enrich_node(tip_nodes(:,1))      = 2;

figure
hold on
cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
plot_mesh(node,element,elemType,'b-');
set(cntr,'LineWidth',3);
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
% n1 = plot(node(split_nodes1,1),node(split_nodes1,2),'r*');
% n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
% set(n1,'MarkerSize',8);
% set(n2,'MarkerSize',8);
theta = -pi:0.1:pi+0.1;
np=size(theta,2);
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
% plot(node(dispNodes,1),node(dispNodes,2),'ks');
set(gcf, 'color', 'white');
axis off

for j=1:numincls
    ns=size(find(split_nodes_h (:,j)),1);
    split_nodes=union(split_nodes,split_nodes_h(1:ns,j));
end

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;

K = sparse(total_unknown,total_unknown);
f = zeros(total_unknown,1);

% ***********************************
%    Stiffness matrix computation
% ***********************************
pos = zeros(numnode,1);
nsnode = 0 ; ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1 || enrich_node(i) == 3)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end

T_split_nodes=[];
T_split_elem_h=[];
for j=1:numincls
    ns=size(find(split_nodes_h(:,j)),1);
    T_split_nodes=[T_split_nodes; split_nodes_h(1:ns,j)];
    T_split_elem_h=[T_split_elem_h;Tot_split_elem_h(j,:)'];
end

disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])

Stiffness_Matrix

clear q

disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;
    for q=1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        f(sctry)=f(sctry)+N*sigmato*det(J0)*wt;
    end   % of quadrature loop
end       % of element loop

disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K)); % a measure of the average size of an element in K
% used to keep the conditioning of the K matrix

vdofs = dispNodes.*2;
udofs = 1; % for lower left corner node

f(udofs) = 0 ;
f(vdofs) = 0 ;

K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

disp([num2str(toc),'   SOLUTION'])

u   = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'   POST PROCESSING'])

disp([num2str(toc),'      Deformed configuration'])
% Plot numerical deformed configuration
figure
hold on
fac = 50;
plot_mesh(node+fac*[u_x u_y],element,elemType,'b*');
title(' Numerical deformed configuration ')

% Compute stress at nodes and plot
disp([num2str(toc),'      Stress computation'])
Stress_Computation

plotContour(stress);

disp([num2str(toc),'      Stress intensity factors computation'])

% c = a/5;
SIF_Computation
% a=5;
alpha = theta_C+alpha;
anglereq = alpha*180/pi
QT = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];

pat =[];
pat = [pat; a K1 K2 K1eq];
aa = a;
aI = aImax;
sif(ni)=K1eq;

xCr(3,:)  = [xTip(1,1)+aI*cos(alpha) xTip(1,2)+aI*sin(alpha)]; % New left  crack segment

xTip(2,:) = [xTip(1,1)+aI*cos(alpha) xTip(1,2)+aI*sin(alpha)]; % new left crack tip

jj=2;
clear K enrich_node split_nodes pos split_elem tip_elem Jdomain

while K1eq < KIC % check whether SIF is still less than fracture toughness
    ni=ni+1;
    % ====================================================================== %
    %                          FOR LEFT EDGE CRACK
    % ====================================================================== %
    
    xTip(jj-1,:)= xCr(jj,:);
    xTip(jj,:)= xCr(jj+1,:);                    % New crack tip
    
    xa  = xTip(jj-1,1); ya = xTip(jj-1,2);
    xb  = xTip(jj,1);   yb = xTip(jj,2);
    
    seg2   = xCr(jj+1,:) - xCr(jj,:);
    t2  = 1/norm(seg2)*seg2;
    lsL=zeros(numnode,3);
    for i = 1 : numnode
        x = node(i,1);
        y = node(i,2);
        l = sqrt((xb-xa)*(xb-xa)+(yb-ya)*(yb-ya)) ;     % crack length
        phi = (ya-yb)*x + (xb-xa)*y + (xa*yb-xb*ya);    % area
        lsL(i,1) = phi/l;                               % normal LS                    % y-distance from node to crack line
        lsL(i,2) = ([x y]-xTip(jj,:))*t2';
        lsL(i,3)=([x y]-xTip(jj-1,:))*-t2';
    end
    
    split_elem =[];
    count1 = 0;
    count2 = 0;
    tip_elem = [];
    for iel = 1 : numelem
        sctr = element(iel,:);
        phi  = lsL(sctr,1);
        psi  = lsL(sctr,2);
        psi2  = lsL(sctr,3);
        if ( max(phi)*min(phi) < 0 )
            if max(psi) < 0&&max(psi2) < 0
                count1 = count1 + 1 ; % ah, one split element
                split_elem(count1) = iel;
            elseif max(psi)*min(psi) < 0
                count2 = count2 + 1 ; % ah, one tip element
                tip_elem(count2) = iel;
            end
        end
    end
    Fa = union(split_elem,tip_elem);
    ls(unique(element(Fa,:)),1) = lsL(unique(element(Fa,:)),1);
    split_elem  = union(Felement, split_elem);
    split_nodes = unique(element(split_elem,:));
    trr = element(tip_elem,:);
    tip_nodes   =  unique(trr');
    split_nodes = setdiff(split_nodes,tip_nodes);
    split_nodes1 = split_nodes;
    Felement = union(split_elem,tip_elem);
    enrich_node = zeros(numnode,1);
    
    for j=1:numincls
        xx=find(split_nodes(:,1));
        n9=size(xx,1);
        yy=setdiff(split_nodes_h(1:n8,j),split_nodes(1:n9,1));
        n10=size(yy,1);
        split_nodes_h(1:n10,j) = setdiff(split_nodes_h(1:n8,j),split_nodes(1:n9,1));
        zz=setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
        n11=size(zz,1);
        split_nodes_h(1:n11,j) = setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
        T_split_nodes = setdiff(T_split_nodes,split_nodes);
        T_split_nodes = setdiff(T_split_nodes,tip_nodes);
        
        ns=size(find(split_nodes_h (:,j)),1);
        enrich_node(nonzeros(split_nodes_h (1:ns,j))) = 3;
    end
    
    enrich_node(nonzeros(split_nodes(:,1))) = 1;
    enrich_node(tip_nodes(:,1))             = 2;
    
%     figure
%     hold on
%     plot_mesh(node,element,elemType,'b-');
%     cr = plot(xCr(:,1),xCr(:,2),'r-');
%     set(cr,'LineWidth',3);
%     n1 = plot(node(split_nodes1,1),node(split_nodes1,2),'r*');
%     n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
%     set(n1,'MarkerSize',8);
%     set(n2,'MarkerSize',8);
%     theta = -pi:0.1:pi;
%     np=size(theta,2);
%     for j=1:numincls
%         xx(j,1:np)=xh(j)+rh(j)*cos(theta);
%         yy(j,1:np)=yh(j)+rh(j)*sin(theta);
%         plot(xx(j,1:np),yy(j,1:np),'k-')
%     end
%     plot(node(dispNodes,1),node(dispNodes,2),'ks');
%     set(gcf, 'color', 'white');
%     axis off
    
    for j=1:numincls
        ns=size(find(split_nodes_h (:,j)),1);
        split_nodes=union(split_nodes,split_nodes_h(1:ns,j));
    end
    
    total_unknown = numnode*2 + size(nonzeros(split_nodes),1)*1*2 + size(tip_nodes,1)*4*2;
    
    K = sparse(total_unknown,total_unknown);
    f = zeros(total_unknown,1);
    
    % ***********************************
    %    Stiffness matrix computation
    % ***********************************
    pos = zeros(numnode,1);
    nsnode = 0 ; ntnode = 0 ;
    for i = 1 : numnode
        if (enrich_node(i) == 1 || enrich_node(i) == 3)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            nsnode = nsnode + 1 ;
        elseif (enrich_node(i) == 2)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            ntnode = ntnode + 1 ;
        end
    end
    
    T_split_nodes=[];
    T_split_elem_h=[];
    for j=1:numincls
        ns=size(find(split_nodes_h(:,j)),1);
        T_split_nodes=[T_split_nodes; split_nodes_h(1:ns,j)];
        T_split_elem_h=[T_split_elem_h;Tot_split_elem_h(j,:)'];
    end
    
    disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
    Stiffness_Matrix1
    
    disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])
    
    % The top edge is applied a traction along Y direction
    [W,Q]=quadrature(1,'GAUSS',1);
    for e = 1:size(topEdge,1)
        sctr = topEdge(e,:);
        sctry = sctr.*2 ;
        for q=1:size(W,1)
            pt = Q(q,:);
            wt = W(q);
            N  = lagrange_basis('L2',pt);
            J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
            f(sctry)=f(sctry)+N*sigmato*det(J0)*wt;
        end   % of quadrature loop
    end       % of element loop
    
    disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])
    
    bcwt = mean(diag(K)); % a measure of the average size of an element in K
    % used to keep the conditioning of the K matrix
    
    vdofs = dispNodes.*2;
    udofs = 1; % for lower left corner node
    
    f(udofs) = 0 ;
    f(vdofs) = 0 ;
    
    K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
    K(vdofs,:) = 0;
    K(:,udofs) = 0;
    K(:,vdofs) = 0;
    K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
    K(vdofs,vdofs) = bcwt*speye(length(vdofs));
    
    disp([num2str(toc),'   SOLUTION'])
    
    u   = K\f;
    u_x = u(1:2:2*numnode) ;
    u_y = u(2:2:2*numnode) ;
    
    disp([num2str(toc),'   POST PROCESSING'])
    
    % disp([num2str(toc),'      Deformed configuration'])
    % % Plot numerical deformed configuration
    % figure
    % hold on
    % fac = 50;
    % plot_mesh(node+fac*[u_x u_y],element,elemType,'b*');
    % title(' Numerical deformed configuration ')
    
    % Compute stress at nodes and plot
    disp([num2str(toc),'      Stress computation'])
    Stress_Computation1
    
    %     plotContour(stress);
    
    disp([num2str(toc),'      Stress intensity factors computation'])
    a = a + aI;
    SIF_Computation1
    
    alpha = theta_C+alpha;
    anglereq = alpha*180/pi
    QT = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
    
    aa = aa + aImax;
    aI = aImax;
    pat = [pat; a K1 K2 K1eq];
    
    sif(ni)=K1eq;
    
    % =========================================================================
    %                         FOR LEFT EDGE CARCK
    % =========================================================================
    
    xCr(jj+2,:) = [xTip(jj,1)+aI*cos(alpha) xTip(jj,2)+aI*sin(alpha)]; % New left  crack segment
    
    xTip(jj+1,:) = [xTip(jj,1)+aI*cos(alpha) xTip(jj,2)+aI*sin(alpha)]; % new left crack tip
    
    jj=jj+1;
    clear Jdomain
end

SIF=sif';
T = table(SIF);
disp(T(1:ni,:));
filename = 'E:\XFEM\With inclusions\2edgemwcnt_inclusions.xlsx';
writetable(T,filename,'Sheet',1,'Range','E1');
