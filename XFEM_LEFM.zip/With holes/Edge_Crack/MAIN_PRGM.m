% LEFT EDGE CRACK WITH HOLES
clear all
state = 0;
tic;
close all;
clc
global nnx nny node element PLOT VOID L D INC elemType E nu C
L = 100;
D = 200;
E  = 2.9e3;
nu = 0.35;
ni=1;

% Loading
sigmato = 2.5;
KIC = 19.63924642;
aImax = 2;

nnx = 40;
nny = 80;

INC = [];
PLOT(5,2) = 1;

stressState='PLANE_STRESS';

% Compliance matrix C
if ( strcmp(stressState,'PLANE_STRESS') )
    C = E/(1-nu^2)*[ 1   nu 0;
        nu  1  0 ;
        0   0  0.5*(1-nu) ];
else
    C = E/(1+nu)/(1-2*nu)*[ 1-nu  nu  0;
        nu    1-nu 0;
        0     0  0.5-nu ];
end

% DATA INPUT
numholes = 4;
[xh,yh,rh]=DATA_HOLES(numholes);
hole = [xh' yh' rh'];
VOID=hole;

% Main Crack Data
a = 8;         % Left Crack length
angle = 0;      % Inclination angle in degree for left crack
alpha=pi*angle/180;
xedge=0;
yedge=100;
xCr   = [ xedge yedge; xedge+a*cos(alpha) yedge+a*sin(alpha)];      % crack coordinates
xTip  = [xedge+a*cos(alpha) yedge+a*sin(alpha)];                    % crack tip coordinates
seg  = xCr(2,:) - xCr(1,:);   % tip segment
QT    =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];

disp([num2str(toc),'   MESH GENERATION'])

% Four corner points
pt1 = [0 0] ;
pt2 = [L 0] ;
pt3 = [L D] ;
pt4 = [0 D] ;

elemType = 'Q4' ;
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);

numnode = size(node,1);
numelem = size(element,1);

uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)

topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';

dispNodes  = unique(botEdge);
tracNodes  = unique(topEdge);

% +++++++++++++++++++++++++++++++++++++
%        LEVEL SET INITIALIZATION
%      SELECTION OF ENRICHED NODES
% +++++++++++++++++++++++++++++++++++++

disp([num2str(toc),'   LEVEL SET INITIALIZATION'])

x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
ls=zeros(numnode,2);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;                                               % normal LS
    ls(i,2) = ([x y]-xTip)*t';                                     % tangent LS
end

enrich_node = zeros(numnode,1);
count1 = 0; count2 = 0;
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elem(count2) = iel;
            enrich_node(sctr)   = 2;
        end
    end
end

split_nodes = find(enrich_node == 1);
tip_nodes   = find(enrich_node == 2);
Felement = union(split_elem,tip_elem);

% +++++++++++++++++++++++++++++++++++++
%        LEVEL SET INITIALIZATION
%      SELECTION OF ENRICHED NODES
% +++++++++++++++++++++++++++++++++++++

% FOR HOLES

node1=node;
ls_h = zeros(numnode,numholes);
r_h = zeros(numnode,numholes);

for i=1:numnode
    xi=node(i,1);
    yi=node(i,2);
    for j=1:numholes
        d1 = sqrt((xi-xh(j))^2+(yi-yh(j))^2)-rh(j);
        if d1 < 0
            ls_h(i,j) = d1;
            node1(i,:)=0;
        else
            ls_h(i,j) = d1;
        end
        d2=sqrt((xi-xh(j))^2+(yi-yh(j))^2);
        rr(i,j)=d2;
    end
end

for j=1:numholes
    tst1 = []; tst2 = []; tst = [];
    tst1 = rr(:,j) - rh(j);
    tst2 = tst1(element)';
    n1 = size(find(min(tst2<=0)),2);
    hole_elem(j,1:n1) = find(min(tst2<=0));
    tst = max(tst2).*min(tst2);
    n2 = size(find(tst<=0),2);
    tt = find(tst<=0);
    split_elem_h(j,1:n2) = tt(1:n2);
    pp1 = find(hole_elem(j,:));
    n3 = size(pp1,2);
    n4 = size(unique(element(hole_elem(j,1:n3),:)),1);
    hole_nodes_s(1:n4,j) = unique(element(hole_elem(j,1:n3),:));
    pp2 = union(split_elem_h(j,:),hole_elem(j,:));
    n5 = size(union(split_elem_h(j,:),hole_elem(j,:)),2);
    Tot_split_elem_h(j,1:n5) = pp2(1:n5);
    n6 = size(find(split_elem_h(j,:)),2);
    n7 = size(unique(element(split_elem_h(j,1:n6),:)),1);
    split_nodes_h(1:n7,j) = unique(element(split_elem_h(j,1:n6),:));
    pp3 = find(split_nodes_h(:,j));
    n8 = size(pp3,1);
    pp4 = find(hole_nodes_s(:,j));
    n9 = size(pp4,1);
%         pp5 = setdiff(hole_nodes_s(1:n9,j),split_nodes_h(1:n8,j));
%         n10 = size(pp5,1);
%         hole_nodes(1:n10,j) = setdiff(hole_nodes_s(1:n9,j),split_nodes_h(1:n8,j));
    pp5 = hole_nodes_s(1:n9,j);
    n10 = size(pp5,1);
    hole_nodes(1:n10,j) = hole_nodes_s(1:n9,j);
end

% figure
% hold on
% cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
% set(cntr,'LineWidth',3);
% plot_mesh(node,element,elemType,'b-');
% cr = plot(xCr(:,1),xCr(:,2),'r-');
% set(cr,'LineWidth',3);
% % n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
% % n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
% % set(n1,'MarkerSize',8);
% % set(n2,'MarkerSize',8);
% theta = -pi:0.1:pi;
% np=size(theta,2);
% for j=1:numholes
%     xx(j,1:np)=xh(j)+rh(j)*cos(theta);
%     yy(j,1:np)=yh(j)+rh(j)*sin(theta);
%     fill(xx(j,1:np),yy(j,1:np),'w','LineStyle','none')
% end
% % plot(node(dispNodes,1),node(dispNodes,2),'ks');
% set(gcf, 'color', 'white');
% axis off

for j=1:numholes
    nf=size(find(split_nodes_h(:,j)),1);
    nf1=size(split_nodes,1);
    nf2=size(union(split_nodes(1:nf1,1),split_nodes_h(1:nf,j)),1);
    split_nodes(1:nf2,1)= union(split_nodes(1:nf1,1),split_nodes_h(1:nf,j));
end

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;

K = sparse(total_unknown,total_unknown);
f = zeros(total_unknown,1);

% ***********************************
%    Stiffness matrix computation
% ***********************************

pos = zeros(numnode,1);
enrich_node(split_nodes (:,1)) = 1;
nsnode = 0 ;
ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end


disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
Stiffness_Matrix

disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;
    for ii=1:size(W,1)
        pt = Q(ii,:);
        wt = W(ii);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        f(sctry)=f(sctry)+N*sigmato*det(J0)*wt;
    end   % of quadrature loop
end       % of element loop

disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K)); % a measure of the average size of an element in K
% used to keep the conditioning of the K matrix

vdofs = dispNodes.*2;
udofs = 1; % for lower left corner node
for j=1:numholes
    n1=size(find(hole_nodes(:,j)),1);
    vdofs1 = hole_nodes(1:n1,j)*2;
    udofs1 = hole_nodes(1:n1,j)*2-1;
    udofs=[udofs; udofs1];
    vdofs=[vdofs; vdofs1];
end

f(udofs) = 0 ;
f(vdofs) = 0 ;

K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

disp([num2str(toc),'   SOLUTION'])
u   = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'   POST PROCESSING'])

disp([num2str(toc),'      Deformed configuration'])
% --------------------------------------------------
% Plot numerical deformed configuration
figure
hold on
factr = 10;
plot_mesh(node1 + factr*[u_x u_y],element,elemType,'b*');
title(' Numerical deformed configuration ')
% --------------------------------------------------

% ---------------------------------------------
% Compute stress at nodes and plot
disp([num2str(toc),'      Stress computation'])

stressPoints=[-1 -1;1 -1;1 1;-1 1];
stress = zeros(numelem,4,3);
for e = 1 : numelem
    sctr = element(e,:);
    nn   = length(sctr);
    U     = element_disp(e,pos,enrich_node,u);
    for i=1:nn
        pt = stressPoints(i,:);
        if (ismember(e,split_elem))
            [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip,alpha);
        elseif (ismember(e,Tot_split_elem_h(1:numholes,:)))
            for j=1:numholes
                if (ismember(e,Tot_split_elem_h(j,:)))
                    [B,J0] = xfemBmatrixh(pt,elemType,e,enrich_node,hole(j,:));
                end
            end
        else
            [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip,alpha);
        end
        strain = B*U;
        stress(e,i,:) = C*strain;
    end
end

% plotContour(stress);

% disp([num2str(toc),'      Stress intensity factors computation'])
% c=5.5136;
SIF_Computation

alpha = theta_C+alpha;
anglereq = alpha*180/pi ;
QT = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
% Compute the exact SIFs
F = 1.12 - 0.23*(a/L) + 10.55*(a/L)^2 - 21.72*(a/L)^3 + 30.39*(a/L)^4;
Kexact = F * sigmato*sqrt(pi*a)

pat =[];
pat = [pat; a K1 K2 K1eq];
aa = a;
aI = aImax;
sif(ni)=K1eq;

xCr(3,:)  = [xTip(1,1)+aI*cos(alpha) xTip(1,2)+aI*sin(alpha)]; % New left  crack segment
xTip(2,:) = [xTip(1,1)+aI*cos(alpha) xTip(1,2)+aI*sin(alpha)]; % new left crack tip
jj=2;

clear K enrich_node split_nodes pos split_elem tip_elem Jdomain

while K1eq < KIC % check whether SIF is still less than fracture toughness
%     
%     % ====================================================================== %
%     %                          FOR LEFT EDGE CRACK
%     % ====================================================================== %
    ni=ni+1;
    xTip(jj-1,:)= xCr(jj,:);
    xTip(jj,:)= xCr(jj+1,:);                    % New crack tip
    
    xa  = xTip(jj-1,1); ya = xTip(jj-1,2);
    xb  = xTip(jj,1);   yb = xTip(jj,2);
    
    seg2   = xCr(jj+1,:) - xCr(jj,:);
    t2  = 1/norm(seg2)*seg2;
    lsL=zeros(numnode,3);
    for i = 1 : numnode
        x = node(i,1);
        y = node(i,2);
        l = sqrt((xb-xa)*(xb-xa)+(yb-ya)*(yb-ya)) ;     % crack length
        phi = (ya-yb)*x + (xb-xa)*y + (xa*yb-xb*ya);    % area
        lsL(i,1) = phi/l;                               % normal LS    % y-distance from node to crack line
        lsL(i,2) = ([x y]-xTip(jj,:))*t2';
        lsL(i,3)=([x y]-xTip(jj-1,:))*-t2';
    end
    
    count1 = 0;
    split_elem = [];
    tip_elem = [];
    count2 = 0;
    for iel = 1 : numelem
        sctr = element(iel,:);
        phi  = lsL(sctr,1);
        psi  = lsL(sctr,2);
        psi2  = lsL(sctr,3);
        if ( max(phi)*min(phi) < 0 )
            if max(psi) < 0&&max(psi2) < 0
                count1 = count1 + 1 ; % ah, one split element
                split_elem(count1) = iel;
            elseif max(psi)*min(psi) < 0
                count2 = count2 + 1 ; % ah, one tip element
                tip_elem(count2) = iel;
            end
        end
    end
    Fa = union(split_elem,tip_elem);
    ls(unique(element(Fa,:)),1) = lsL(unique(element(Fa,:)),1);
    split_elem  = union(Felement, split_elem);
    split_nodes = unique(element(split_elem,:));
    trr = element(tip_elem,:);
    tip_nodes   =  unique(trr');
    split_nodes = setdiff(split_nodes,tip_nodes);
    split_nodes1 = split_nodes;
    Felement = union(split_elem,tip_elem);
    
    figure
    hold on
    plot_mesh(node1,element,elemType,'b*');
    cr = plot(xCr(:,1),xCr(:,2),'r-');
    set(cr,'LineWidth',3);
    n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
    n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
    set(n1,'MarkerSize',8);
    set(n2,'MarkerSize',8);
    theta = -pi:0.1:pi;
    np=size(theta,2);
    for j=1:numholes
        xx(j,1:np)=xh(j)+rh(j)*cos(theta);
        yy(j,1:np)=yh(j)+rh(j)*sin(theta);
        plot(xx(j,1:np),yy(j,1:np),'k-')
    end
    plot(node(dispNodes,1),node(dispNodes,2),'ks');
    set(gcf, 'color', 'white');
    axis off
    
    for j=1:numholes
        nf=size(find(split_nodes_h(:,j)),1);
        nf1=size(split_nodes,1);
        nf2=size(union(split_nodes(1:nf1,1),split_nodes_h(1:nf,j)),1);
        split_nodes(1:nf2,1)= union(split_nodes(1:nf1,1),split_nodes_h(1:nf,j));
    end
    
    total_unknown = numnode*2 + size(nonzeros(split_nodes),1)*1*2 + size(tip_nodes,1)*4*2;
    
    K = sparse(total_unknown,total_unknown);
    f = zeros(total_unknown,1);
    
    % ***********************************
    %    Stiffness matrix computation
    % ***********************************
    
    enrich_node = zeros(numnode,1);
    pos = zeros(numnode,1);
    enrich_node(split_nodes (:,1)) = 1;
    enrich_node(tip_nodes(:,1))    = 2;
    nsnode = 0 ;
    ntnode = 0 ;
    for i = 1 : numnode
        if (enrich_node(i) == 1)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            nsnode = nsnode + 1 ;
        elseif (enrich_node(i) == 2)
            pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
            ntnode = ntnode + 1 ;
        end
    end
    
    
    disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
    Stiffness_Matrix1
    
    disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])
    
    % The top edge is applied a traction along Y direction
    [W,Q]=quadrature(1,'GAUSS',1);
    for e = 1:size(topEdge,1)
        sctr = topEdge(e,:);
        sctry = sctr.*2 ;
        for i=1:size(W,1)
            pt = Q(i,:);
            wt = W(i);
            N  = lagrange_basis('L2',pt);
            J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
            f(sctry)=f(sctry)+N*sigmato*det(J0)*wt;
        end   % of quadrature loop
    end       % of element loop
    
    disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])
    
    bcwt = mean(diag(K)); % a measure of the average size of an element in K
    % used to keep the conditioning of the K matrix
    
    vdofs = dispNodes.*2;
    udofs = 1; % for lower left corner node
    for j=1:numholes
        n1=size(find(hole_nodes(:,j)),1);
        vdofs1 = hole_nodes(1:n1,j)*2;
        udofs1 = hole_nodes(1:n1,j)*2-1;
        udofs=[udofs; udofs1];
        vdofs=[vdofs; vdofs1];
    end
    
    f(udofs) = 0 ;
    f(vdofs) = 0 ;
    
    K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
    K(vdofs,:) = 0;
    K(:,udofs) = 0;
    K(:,vdofs) = 0;
    K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
    K(vdofs,vdofs) = bcwt*speye(length(vdofs));
    
    disp([num2str(toc),'   SOLUTION'])
    u   = K\f;
    u_x = u(1:2:2*numnode) ;
    u_y = u(2:2:2*numnode) ;
    
    disp([num2str(toc),'   POST PROCESSING'])
    
    disp([num2str(toc),'      Deformed configuration'])
    % % --------------------------------------------------
    % % Plot numerical deformed configuration
    % figure
    % hold on
    % factr = 10;
    % plot_mesh(node1 + factr*[u_x u_y],element,elemType,'b*');
    % title(' Numerical deformed configuration ')
    % % --------------------------------------------------
    
    disp([num2str(toc),'      Stress computation'])
    
    stressPoints=[-1 -1;1 -1;1 1;-1 1];
    stress = zeros(numelem,4,3);
    for e = 1 : numelem
        sctr = element(e,:);
        nn   = length(sctr);
        U     = element_disp(e,pos,enrich_node,u);
        for i=1:nn
            pt = stressPoints(i,:);
            if (ismember(e,split_elem))
                [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip(jj,:),alpha);
            elseif (ismember(e,Tot_split_elem_h(1:numholes,:)))
                for j=1:numholes
                    if (ismember(e,Tot_split_elem_h(j,:)))
                        [B,J0] = xfemBmatrixh(pt,elemType,e,enrich_node,hole(j,:));
                    end
                end
            else
                [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTip(jj,:),alpha);
            end
            strain = B*U;
            stress(e,i,:) = C*strain;
        end
    end
    
%     plotContour(stress);
    
    disp([num2str(toc),'      Stress intensity factors computation'])
    a = a + aI;
    SIF_Computation1
    
    alpha = theta_C+alpha;
    anglereq = alpha*180/pi ;
    QT = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
    
    aa = aa + aImax;
    aI = aImax;
    pat = [pat; a K1 K2 K1eq];

    sif(ni)=K1eq;
    
    xCr(jj+2,:) = [xTip(jj,1)+aI*cos(alpha) xTip(jj,2)+aI*sin(alpha)]; % New left  crack segment
    
    xTip(jj+1,:) = [xTip(jj,1)+aI*cos(alpha) xTip(jj,2)+aI*sin(alpha)]; % new left crack tip
    
    jj=jj+1;
    clear Jdomain
end
pp=1;

SIF=sif';
T = table(SIF);
disp(T(1:ni,:));
filename = 'E:\XFEM\With holes\2edgemwcnt_hole.xlsx';
writetable(T,filename,'Sheet',1,'Range','E1');
