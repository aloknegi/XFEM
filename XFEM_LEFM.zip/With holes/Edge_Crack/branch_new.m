function [f,dfdX,dfdY] = branch_new(r,theta,alpha)
% FINAL MODIFIED ON 16/09/2012
%  (r,theta) : polar coordinates of points where the branch
%              functions are to be evaluated
%   alpha    : inclination of the crack tip segment w.r.t x axis

if( r ~=0 )
    r2 = sqrt(r);
else
    r2    = 0.1d-4;
    theta = 0.0d0 ;
end
fac  = 0.5/r2 ;
st2  = sin(theta/2.);
ct2  = cos(theta/2.);
st   = sin(theta);
ct   = cos(theta);

drdx = cos(theta);
drdy = sin(theta);
dtdx = -sin(theta)/r;
dtdy = cos(theta)/r;

dxdX = cos(alpha);
dxdY = sin(alpha);
dydX = -sin(alpha);
dydY = cos(alpha);

drdX = drdx*dxdX + drdy*dydX;
drdY = drdx*dxdY + drdy*dydY;
dtdX = dtdx*dxdX + dtdy*dydX;
dtdY = dtdx*dxdY + dtdy*dydY;

% Functions 
f(1) = r2 * st2 ;
f(2) = r2 * ct2;
f(3) = r2 * st2 * ct;
f(4) = r2 * ct2 * ct;

% Derivatives

% first function
dPhidr = fac * st2;
dPhidt = r2/2 * ct2;
dfdX(1) = dPhidr * drdX + dPhidt * dtdX  ;
dfdY(1) = dPhidr * drdY + dPhidt * dtdY  ;

% second function
dPhidr = fac * ct2;
dPhidt = -r2/2 * st2; 
dfdX(2) = dPhidr * drdX + dPhidt * dtdX  ;
dfdY(2) = dPhidr * drdY + dPhidt * dtdY  ;

% third function
dPhidr = fac * st2 * ct;
dPhidt = r2 * (1/2*ct2*ct-st2*st);
dfdX(3) = dPhidr * drdX + dPhidt * dtdX  ;
dfdY(3) = dPhidr * drdY + dPhidt * dtdY  ;

% fourth function
dPhidr = fac * ct2 *ct;
dPhidt = r2 * (-1/2*st2*ct-ct2*st);
dfdX(4) = dPhidr * drdX + dPhidt * dtdX  ;
dfdY(4) = dPhidr * drdY + dPhidt * dtdY  ;
        
