ggp = [];
for iel = 1:numelem
    sctr = element(iel,:); % element connectivity
    nn   = length(sctr);   % number of nodes per element
    
    sctrB = assembly(iel,enrich_node,pos);
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))     % split element
        order = 7 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
    elseif (ismember(iel,tip_elem))   % tip element
        order = 7;
        phi   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phi,nodes,xTip);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
    elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 6 ;
        [W,Q] = quadrature(order,'GAUSS',2);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
        
    elseif (ismember(iel,Tot_split_elem_h(1:numholes,:)))     % hole element
        
        for j=1:numholes
            if (ismember(iel,Tot_split_elem_h(j,:)))
                order = 7 ;
                phi   = ls_h(sctr,j);
                [W,Q] = discontQ4quad(order,phi);
                for kk = 1 : size(W,1)
                    pt = Q(kk,:);                             % quadrature point
                    [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));
                    K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
                end
            end
        end
    else
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip,alpha);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
    end
    
    % Transform these Gauss points to global coords for plotting only
    for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:); % global GP
        ggp = [ggp;Gpnt];
    end
end                      % end of looping on elements
