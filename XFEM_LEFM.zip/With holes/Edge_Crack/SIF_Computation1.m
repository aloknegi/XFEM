[Jdomain,qnode,radius] = Jdomain1(max(tip_elem),xTip(jj,:));

% plot
figure
hold on
theta = -pi:0.1:pi;
xo = xTip(jj,1) + radius*cos(theta) ;
yo = xTip(jj,2) + radius*sin(theta) ;
plot(xo,yo,'k-');
plot_mesh(node1,element,'Q4','b*')
plot_mesh(node,element(Jdomain,:),'Q4','r-')
np=size(theta,2);
for j=1:numholes
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(gcf, 'color', 'white');
set(cr,'LineWidth',2);
axis off

I  = zeros(2,1);

ind=0;ind1=0;
for iel = 1 : numelem
    sctr = element(iel,:);
    % Choose Gauss quadrature rule
    if (ismember(iel,split_elem))     % Main Crack split elements
        order = 2;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
        
    elseif (ismember(iel,tip_elem))   % Main Crack tip elements
        order = 7;
        phi   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phi,nodes,xTip(jj,:));
        
    elseif (any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 4;
        [W,Q] = quadrature(order,'GAUSS',2);
        
    elseif (ismember(iel,Tot_split_elem_h(1:numholes,:)))     % hole element
        
        for j=1:numholes
            if (ismember(iel,Tot_split_elem_h(j,:)))
                order = 2 ;
                phi   = ls_h(sctr,j);
                [W,Q] = discontQ4quad(order,phi);
            end
        end
        
    else
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
    if (ismember(iel,Jdomain))
        ind1=ind1+1;
    end
    
    for ij = 1:size(W,1)
        ind=ind+1;
        
        if (ismember(iel,Jdomain))
            pt = Q(ij,:);
            wt = W(ij);
            [N,dNdxi] = lagrange_basis(elemType,pt);
            J0 = node(sctr,:)'*dNdxi;
            invJ0 = inv(J0);
            dNdx  = dNdxi*invJ0;
            Gpt = N' * node(sctr,:);     % GP in global coord
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTip(jj,:),alpha);
            leB = size(B,2);
            U = element_disp(iel,pos,enrich_node,u);
            % compute derivatives of u w.r.t xy
            HH(1,1) = B(1,1:2:leB)*U(1:2:leB);    % u,x
            HH(1,2) = B(2,2:2:leB)*U(1:2:leB);    % u,y
            HH(2,1) = B(1,1:2:leB)*U(2:2:leB);    % v,x
            HH(2,2) = B(2,2:2:leB)*U(2:2:leB);    % v,y
            
            % ++++++++++++++
            % Gradient of q
            % ++++++++++++++
            q     = qnode(ind1,:);
            gradq = q*dNdx;
            
            % ++++++++++++++
            % Stress at GPs
            % ++++++++++++++
            
            epsilon = B*U;
            sigma   = C*epsilon;
            
            % +++++++++++++++++++++++++++++++++++
            % Transformation to local coordinate
            % +++++++++++++++++++++++++++++++++++
            
            voit2ind    = [1 3;3 2];
            gradqloc    = QT*gradq';
            graddisploc = QT*HH*QT';
            stressloc   = QT*sigma(voit2ind)*QT';
            
            % ++++++++++++++++++
            %  Auxiliary fields
            % ++++++++++++++++++
            
            xp    = QT*(Gpt-xTip(jj,:))';           % local coordinates
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));
            theta = atan2(xp(2),xp(1));
            
            K1 = 1.0 ;
            K2 = K1  ;
            
            mu = E/(2.+ nu + nu);
            %             kappa = 3-4*nu;    %Kolosov coeff, Plane strain
            kappa = (3-nu)/(1+nu);    %Kolosov coeff, Plane stress
            
            SQR  = sqrt(r);
            CT   = cos(theta);
            ST   = sin(theta);
            CT2  = cos(theta/2);
            ST2  = sin(theta/2);
            C3T2 = cos(3*theta/2);
            S3T2 = sin(3*theta/2);
            
            drdx = CT;
            drdy = ST;
            dtdx = -ST/r;
            dtdy = CT/r;
            
            FACStress1 = sqrt(1/(2*pi));
            FACStress2 = FACStress1;
            
            FACDisp1 = sqrt(1/(2*pi))/(2*mu);
            FACDisp2 = FACDisp1;
            
            AuxStress   = zeros(2,2);
            AuxGradDisp = zeros(2,2);
            AuxEps      = zeros(2,2);
            
            
            for mode = 1:2
                if (mode == 1)
                    
                    AuxStress(1,1) = K1*FACStress1/SQR*CT2*(1-ST2*S3T2);
                    AuxStress(2,2) = K1*FACStress1/SQR*CT2*(1+ST2*S3T2);
                    AuxStress(1,2) = K1*FACStress1/SQR*ST2*CT2*C3T2;
                    AuxStress(2,1) = AuxStress(1,2);
                    
                    %                 u1    = K1*FACDisp1*SQR*CT2*(kappa - CT);
                    du1dr = K1*FACDisp1*0.5/SQR*CT2*(kappa - CT);
                    du1dt = K1*FACDisp1*SQR*(-0.5*ST2*(kappa - CT) + CT2*ST);
                    
                    %                 u2    = K1*FACDisp1*SQR*ST2*(kappa - CT);
                    du2dr = K1*FACDisp1*0.5/SQR*ST2*(kappa - CT);
                    du2dt = K1*FACDisp1*SQR*(0.5*CT2*(kappa - CT) + ST2*ST);
                    
                    AuxGradDisp(1,1) = du1dr*drdx + du1dt*dtdx;
                    AuxGradDisp(1,2) = du1dr*drdy + du1dt*dtdy;
                    AuxGradDisp(2,1) = du2dr*drdx + du2dt*dtdx;
                    AuxGradDisp(2,2) = du2dr*drdy + du2dt*dtdy;
                    
                    AuxEps(1,1) = AuxGradDisp(1,1);
                    AuxEps(2,1) = 0.5*(AuxGradDisp(2,1) + AuxGradDisp(1,2));
                    AuxEps(1,2) = AuxEps(2,1);
                    AuxEps(2,2) = AuxGradDisp(2,2);
                elseif (mode == 2)
                    AuxStress(1,1) = -K2*FACStress2/SQR*ST2*(2+CT2*C3T2);
                    AuxStress(2,2) = K2*FACStress2/SQR*ST2*CT2*C3T2;
                    AuxStress(1,2) = K2*FACStress2/SQR*CT2*(1-ST2*S3T2);
                    AuxStress(2,1) = AuxStress(1,2);
                    
                    %                 u1    = K2*FACDisp2*SQR*ST2*(kappa + 2 + CT);
                    du1dr = K2*FACDisp2*0.5/SQR*ST2*(kappa + 2 + CT);
                    du1dt = K2*FACDisp2*SQR*(0.5*CT2*(kappa + 2 + CT) - ST2*ST);
                    
                    %                 u2    = -K2*FACDisp2*SQR*CT2*(kappa - 2 + CT);
                    du2dr = -K2*FACDisp2*0.5*(1/SQR)*CT2*(kappa - 2 + CT);
                    du2dt = -K2*FACDisp2*SQR*(-0.5*ST2*(kappa - 2 + CT) - CT2*ST);
                    
                    AuxGradDisp(1,1) = du1dr*drdx + du1dt*dtdx;
                    AuxGradDisp(1,2) = du1dr*drdy + du1dt*dtdy;
                    AuxGradDisp(2,1) = du2dr*drdx + du2dt*dtdx;
                    AuxGradDisp(2,2) = du2dr*drdy + du2dt*dtdy;
                    
                    AuxEps(1,1) = AuxGradDisp(1,1);
                    AuxEps(2,1) = 0.5*(AuxGradDisp(2,1) + AuxGradDisp(1,2));
                    AuxEps(1,2) = AuxEps(2,1);
                    AuxEps(2,2) = AuxGradDisp(2,2);
                end
                
                % +++++++++++++++
                %   J integral
                % +++++++++++++++
                I1= (stressloc(1,1) * AuxGradDisp(1,1) + stressloc(2,1) * AuxGradDisp(2,1) ) * gradqloc(1) + ...
                    (stressloc(1,2) * AuxGradDisp(1,1) + stressloc(2,2) * AuxGradDisp(2,1) ) * gradqloc(2);
                
                I2= (AuxStress(1,1) * graddisploc(1,1) + AuxStress(2,1) * graddisploc(2,1) ) * gradqloc(1) + ...
                    (AuxStress(2,1) * graddisploc(1,1) + AuxStress(2,2) * graddisploc(2,1) ) * gradqloc(2);
                
                StrainEnergy = 0;
                for i=1:2 %size(AuxEpsm1,1)
                    for j=1:2  %size(AuxEpsm1,2)
                        StrainEnergy= StrainEnergy+  stressloc(i,j)*AuxEps(i,j);
                    end
                end
                
                % Interaction integral I
                I(mode,1) = I(mode,1) + (I1 + I2 - StrainEnergy*gradqloc(1))*det(J0)*wt;
            end   %loop on mode
        end
    end       % of quadrature loop
end           % end of element loop

%disp([num2str(toc), 'Plane Stress'])

% Knum = I.*E/(2*(1-nu^2));     % plane strain
Knum = I.*E/2                  % plane stress
K1 = Knum(1,:);
K2 = Knum(2,:);
theta_C = 2*atan((K1-(sqrt(K1*K1+8*K2*K2)))/(4*K2));                                        % Theta obtained from max. normal stress theory
K1eq = (K1*(cos(0.5*theta_C))^3)-(3*K2*cos(0.5*theta_C)*cos(0.5*theta_C)*sin(0.5*theta_C)) % to be compared with K1eqRight

