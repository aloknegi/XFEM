function [ xh, yh, rh,xhhh, yhhh, rhhh,am,anglem,xedgem,yedgem,alpham,numi,numc,numh ] = Data_inc( numincls,numcracks,numholes)

nnx = 8;
nny = 12;

tot = nnx*nny;
totd = numincls+numcracks+numholes;
if tot<totd
    disp ('invalid data')
else
xhh = randi([1 nnx*nny],(totd),1);

pt11 = 1000*[0.01 0.01] ;
pt21 = 1000*[0.09 0.01] ;
pt31 = 1000*[0.09 0.19] ;
pt41 = 1000*[0.01 0.19] ;
elemType = 'Q4' ;

[node1,element1] = meshRectangularRegion(pt11, pt21, pt31, pt41, nnx,nny,elemType);

nn1 = xhh(1:numincls,1);
nn2 = unique(nn1);
numi = size(nn2,1);
xh = node1(nn2, 1);
yh = node1(nn2, 2);
rh = randi([300 400],numincls,1)/100;

nn3 = xhh(numincls+1:numincls+numcracks,1);
nn4 = setdiff(nn3,nn2);
nn5 = unique(nn4);
numc = size(nn5,1);
am = [randi([400 550],numcracks,1)/100]';
anglem = [randi([0 10],numcracks,1)]';
xedgem = [node1(nn5, 1)]';
yedgem = [node1(nn5, 2)]';
alpham =(pi/180)*anglem;

nn6 = xhh(numincls+numcracks+1:totd,1);
nn7 = setdiff(nn6,nn2);
nn7 = setdiff(nn7,nn3);
nn8 = unique(nn7);
numh = size(nn8,1);
xhhh = node1(nn8, 1);
yhhh = node1(nn8, 2);
rhhh = randi([300 400],numholes,1)/100;

nn11 =[];
while numi<numincls
    xhh = randi([1 nnx*nny],(totd),1);
    nn9 = setdiff(xhh,nn2);
    nn9 = setdiff(nn9,nn5);
    nn9 = setdiff(nn9,nn8);
    nn10 = numincls-numi;
    nn11 =[];
    if size(nn9,1)> nn10    
       nn11 = [nn11; nn9(1:nn10)];
       xh = [xh; node1(nn9(1:nn10), 1)];
       yh = [yh; node1(nn9(1:nn10), 2)];
       numi = size(xh,1);
    else
       nn11 = [nn11; nn9(1,:)];
       xh = [xh; node1( nn9(1,:), 1)];
       yh = [yh; node1( nn9(1,:), 2)]; 
       numi = size(xh,1);
    end
end

while numc<numcracks
    xhh = randi([1 nnx*nny],(totd),1);
    nn9 = setdiff(xhh,nn2);
    nn9 = setdiff(nn9,nn5);
    nn9 = setdiff(nn9,nn8);
    nn9 = setdiff(nn9,nn11);
    nn10 = numcracks-numc;
    nn12 =[];
    if size(nn9,1)> nn10    
       nn12 = [nn12; nn9(1:nn10)];
       xedgem = [xedgem'; node1(nn9(1:nn10), 1)]';
       yedgem = [yedgem'; node1(nn9(1:nn10), 2)]';
       numc = size(xedgem,2);
    else
       nn12 = [nn12; nn9(1,:)];
       xedgem = [xedgem'; node1( nn9(1,:), 1)]';
       yedgem = [yedgem'; node1( nn9(1,:), 2)]'; 
       numc = size(xedgem,2);
    end
end

while numh<numholes
    xhh = randi([1 nnx*nny],(totd),1);
    nn9 = setdiff(xhh,nn2);
    nn9 = setdiff(nn9,nn5);
    nn9 = setdiff(nn9,nn8);
    nn9 = setdiff(nn9,nn11);
    nn9 = setdiff(nn9,nn12);
    nn10 = numholes-numh;
    nn13 =[];
    if size(nn9,1)> nn10    
       nn13 = [nn13; nn9(1:nn10)];
       xhhh = [xhhh; node1(nn9(1:nn10), 1)];
       yhhh = [yhhh; node1(nn9(1:nn10), 2)];
       numh = size(xhhh,1);
    else
       nn13 = [nn13; nn9(1,:)];
       xhhh = [xhhh; node1( nn9(1,:), 1)];
       yhhh = [yhhh; node1( nn9(1,:), 2)]; 
       numh = size(xhhh,1);
    end
end
end

