DD = 6.85e-8;
M = 3.21;
NNL = 0;
NCL = [];
NNR = 0;
NCR = [];

KIC = 29;
ss1 = size(pat,1);
KeqL = pat(1:(ss1-1),7)./sqrt(1000);
KeqR = pat(1:(ss1-1),8)./sqrt(1000);
K1eqL = pat(1:(ss1),7)./sqrt(1000);
K1eqR = pat(1:(ss1),8)./sqrt(1000);
aIL = pat(1:(ss1),1);
aIR = pat(1:(ss1),2);

for i=1:ss1
    
    NNL = NNL + aIL(i)/(DD*K1eqL(i)^M); %%%%%%  Life calculation
    NCL = [NCL; NNL];
    
    NNR = NNR + aIR(i)/(DD*K1eqR(i)^M); %%%%%%  Life calculation
    NCR = [NCR; NNR];
    
end
% for i=1:(ss1)
    if (K1eqR(ss1)<K1eqL(ss1))
        daL = ((KIC-K1eqL(ss1-1))*aImax)/(K1eqL(ss1)-K1eqL(ss1-1));
        Li = daL/(DD*KIC^M);
        Life = NCL(ss1-1)+ Li
        CracklengthL = (pat(ss1-1,1)+daL);
        daR = daL*((K1eqR(ss1-1)/K1eqL(ss1-1))^M);
        CracklengthR = (pat(ss1-1,2)+daR);
    else
        daR = ((KIC-K1eqR(ss1-1))*aImax)/(K1eqR(ss1)-K1eqR(ss1-1));
        Li = daR/(DD*KIC^M);
        Life = NCR(ss1-1)+ Li
        CracklengthR = (pat(ss1-1,2)+daR);
        daL = daR*((K1eqL(ss1-1)/K1eqR(ss1-1))^M);
        CracklengthL = (pat(ss1-1,1)+daL);
    end
% end

% if LifeL<LifeR
%     Life = LifeL;
% else
%     Life = LifeR;
% end

Cracklength = CracklengthL + CracklengthR + 20

CrackExtension = 20 + pat(1:size(NCL,1),1)+ pat(1:size(NCR,1),2);

figure
hold on
plot(pat(:,1),pat(:,3),'-bs','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',10)
plot(pat(:,1),pat(:,4),'-rs','LineWidth',2,'MarkerEdgeColor','g','MarkerFaceColor','r','MarkerSize',10)
plot(pat(:,2),pat(:,5),'-bs','LineWidth',2,'MarkerEdgeColor','m','MarkerFaceColor','r','MarkerSize',10)
plot(pat(:,2),pat(:,6),'-rs','LineWidth',2,'MarkerEdgeColor','y','MarkerFaceColor','r','MarkerSize',10)
xlabel('Crack Extension (mm)')
ylabel('Stress Intensity Factors (N/mm^{3/2})')
% plot(CracklengthL,KIC,'g*')
% plot(CracklengthR,KIC,'g*')
% axis ([-1 20 -500 2500])
set(gcf,'color','white');
legend('K_I','K_{II}',2)
grid on

figure
hold on
plot(NCL,CrackExtension,'-bo','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
plot(NCR,CrackExtension,'-bo','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
plot(NCL,pat(1:size(NCL,1),1),'-ks','LineWidth',2,'MarkerEdgeColor','g','MarkerFaceColor','r','MarkerSize',7)
plot(NCR,pat(1:size(NCR,1),2),'-kd','LineWidth',2,'MarkerEdgeColor','g','MarkerFaceColor','r','MarkerSize',8)
plot(Life,CracklengthL,'m*')
plot(Life,CracklengthR,'m*')
plot(Life,Cracklength,'g*')
ylabel('Crack Extension (mm)')
xlabel(' No. of cycles')
set(gcf,'color','white');
% axis ([-200 6e3 -2 40])
grid on
