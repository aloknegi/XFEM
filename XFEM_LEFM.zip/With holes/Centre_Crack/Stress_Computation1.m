stressPoints=[-1 -1;1 -1;1 1;-1 1];
stress = zeros(numelem,4,3);
for e = 1 : numelem
    sctr = element(e,:);
    nn   = length(sctr);
    U     = element_disp(e,pos,enrich_node,u);
    for i=1:nn
        pt = stressPoints(i,:);
        %         if (ismember(e,Tot_split_elem_h(1:numholes,:)))     % hole element
        %             for j=1:numholes
        %                 if (ismember(e,Tot_split_elem_h(j,:)))
        %                     order = 2;
        %                 end
        %             end
        
        if (ismember(e,Tot_split_elem_h) || any(intersect(split_nodes,sctr)) ~= 0)
            for j=1:numholes
                ns=size(find(split_nodes_h(:,j)),1);
                
                if (ismember(e,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
                    [B,J0] = xfemBmatrixh(pt,elemType,e,enrich_node,hole(j,:));
                end
            end
        else
            [B,J0] = xfemBmatrix(pt,elemType,e,enrich_node,xCr,xTipL(jj,:),alphaL,xTipR(jj,:),alphaR);
        end
        strain = B*U;
        stress(e,i,:) = C*strain;
    end
end

% stressPoints=[-1 -1;1 -1;1 1;-1 1];
% stress = zeros(numelem,4,3);
% for e = 1 : numelem
%     sctr = element(e,:);
%     nn   = length(sctr);
%     U     = element_disp(e,pos,enrich_node,u);
%     for i=1:nn
%         pt = stressPoints(i,:);
% %         if (ismember(e,Tot_split_elem_h))
% %             [B,J0] = xfemBmatrixh(pt,elemType,e,enrich_node,hole);
%         if (ismember(e,Tot_split_elem_h(1:numholes,:)))
%             for j=1:numholes
%                 if (ismember(e,Tot_split_elem_h(j,:)))
%                     [B,J0] = xfemBmatrixh(pt,elemType,e,enrich_node,hole(j,:));
%                 end
%             end
%         else
%             [B,J0] = xfemBmatrixh(pt,elemType,e,enrich_node,hole);
%         end
%         strain = B*U;
%         stress(e,i,:) = C*strain;
%     end
% end


