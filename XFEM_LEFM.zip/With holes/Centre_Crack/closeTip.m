function [ dist ] = closeTip( nodes,xTip )

        a  = size(nodes,1);
        x0 = sum(nodes(:,1))/a;
        y0 = sum(nodes(:,2))/a;
        
        x1 = xTip(:,1);
        y1 = xTip(:,2);
        
        dist = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0));

end

