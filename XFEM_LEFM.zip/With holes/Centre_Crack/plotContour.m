function plotContour(stress)
global nnx nny node element PLOT L D INC VOID

numnode = size(node,1);
numelem = size(element,1);

X = zeros(nnx,nny); Y = X; Z = X;

% Average nodal values if not already done

    stressXX = stress(:,:,1); stressXY = stress(:,:,3); stressYY = stress(:,:,2);
    Sxx = zeros(numnode,2); Sxy = Sxx; Syy = Sxx;

    % Construct stress vectors
    for iE = 1:(numelem)
        for iN = 1:4
            sctr = element(iE,:);
            nNode = sctr(iN);
            Sxx(nNode,:) = Sxx(nNode,:) + [stressXX(iE,iN) 1];
            Sxy(nNode,:) = Sxy(nNode,:) + [stressXY(iE,iN) 1];
            Syy(nNode,:) = Syy(nNode,:) + [stressYY(iE,iN) 1];
        end
    end

    % Average nodal stress values
    Sxx(:,1) = Sxx(:,1)./Sxx(:,2); Sxx(:,2) = [];
    Sxy(:,1) = Sxy(:,1)./Sxy(:,2); Sxy(:,2) = [];
    Syy(:,1) = Syy(:,1)./Syy(:,2); Syy(:,2) = [];


% Plot the contours
for i = 1:3
    figure; hold on;
    if i == 1
        z = Sxx;
        title('\sigma_x_x')
    elseif i == 2
        z = Sxy;
        title('\sigma_x_y')
    elseif i == 3
        z = Syy;
        title('\sigma_y_y')
    end

    iNode = 1;
    for yE = 1:(nny)
        for xE = 1:(nnx)
            X(xE,yE) = node(iNode,1);
            Y(xE,yE) = node(iNode,2);
            Z(xE,yE) = z(iNode);
            iNode = iNode+1;
        end
    end

    if PLOT(5,2) == 1                                                           % Filled contour
        contourf(X,Y,Z,40,'LineStyle','none');
    else
       contour(X,Y,Z);                                                     % Contour lines
    end
    colorbar; xlabel('X'); ylabel('Y');

%     % Plot the inclusions
%     if isempty(INC) == 0
%         nINC = size(INC,1);
%         for iI = 1:nINC
%             xc = INC(iI,1); yc = INC(iI,2); rc = INC(iI,3);
%             theta = (0:256)*pi*2/256;
%             xp = rc*cos(theta)+xc;
%             yp = rc*sin(theta)+yc;
%             for j = 1:length(xp)
%                 if (xp(j) > L) || (xp(j) < 0)
%                     xp(j) = NaN; yp(j) = NaN;
%                 elseif (yp(j) > D) || (yp(j) < 0)
%                     xp(j) = NaN; yp(j) = NaN;
%                 end
%             end
% 
%             plot(xp,yp,'w','LineWidth',2)
%         end
%     end

    % Plot the voids
    if isempty(VOID) == 0
        nVOID = size(VOID,1);
        for iI = 1:nVOID
            xc = VOID(iI,1); yc = VOID(iI,2); rc = VOID(iI,3);
            theta = 0:0.5:360;
            xp = rc*cosd(theta)+xc;
            yp = rc*sind(theta)+yc;
            for j = 1:length(xp)
                if (xp(j) > L) || (xp(j) < 0)
                    xp(j) = 0; yp(j) = 0;
                elseif (yp(j) > D) || (yp(j) < 0)
                    xp(j) = 0; yp(j) = 0;
                end
            end
            fill(xp,yp,'w','LineStyle','none')
        end
    end
    set(gcf, 'color', 'white');
    axis equal; axis off; hold off;    
end

end