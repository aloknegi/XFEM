qq =[];

for iel = 1 : numelem
    sctr = element(iel,:); % element connectivity
    
    sctrB = assembly(iel,enrich_node,pos);
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))     % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,xTipR(jj,:),alphaR);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
        
    elseif (ismember(iel,tip_elemL))   % tip element
        order = 7;
        phiL   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phiL,nodes,xTipL(jj,:));
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
        
    elseif (ismember(iel,tip_elemR))   % tip element
        order = 7;
        phiR   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phiR,nodes,xTipR(jj,:));
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipR(jj,:),alphaR);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
        
    elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,xTipR(jj,:),alphaR);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
        
    elseif (ismember(iel,Tot_split_elem_h(1:numholes,:)))     % hole element
        
        for j=1:numholes
            if (ismember(iel,Tot_split_elem_h(j,:)))
                order = 2 ;
                phi   = ls_h(sctr,j);
                [W,Q] = discontQ4quad(order,phi);
                for kk = 1 : size(W,1)
                    pt = Q(kk,:);                             % quadrature point
                    [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));
                    K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
                end
            end
        end
        
        %     elseif (ismember(iel,Tot_split_elem_h) || any(intersect(split_nodes,sctr)) ~= 0)
        %         for j=1:numholes
        %             ns=size(find(split_nodes_h(:,j)),1);
        %
        %             if (ismember(iel,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
        %                 order = 2 ;
        %                 phi   = ls_h(sctr,j);
        %                 [W,Q] = discontQ4quad(order,phi);
        %                 for kk = 1 : size(W,1)
        %                     pt = Q(kk,:);                             % quadrature point
        %                     [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));
        %                     K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        %                 end
        %             end
        %         end
        
    else
        order = 2 ;
        [W,Q] = quadrature(order,'GAUSS',2);
        for kk = 1 : size(W,1)
            pt = Q(kk,:);                             % quadrature point
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,xTipR(jj,:),alphaR);
            K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        end
    end
end                      % end of looping on elements
