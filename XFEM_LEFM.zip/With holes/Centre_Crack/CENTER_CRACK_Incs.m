
clear all

for ijk=1:1
    
    clearvars -except T_pat T_NCL T_NCR T_Life T_Cracklength ijk T_CracklengthL T_CracklengthR
close all
clc;
tic;

global nnx nny node element PLOT  L D VOID elemType Em num Cm Ci Ei nui
% Dimension of the domain
% (it is simply a rectangular region D x L)
L = 100 ;
D = 200 ;

% Number of nodes along two directions
nnx = 40 ;
nny = 80;

% Loading
sigmato = 2.5;
KIC = 20;
DD = 2.087136e-13;
M = 3.32;
NNL = 0;
NCL = [0];
NNR = 0;
NCR = [0];
aImax = 5; % maximum size of crack increment

% Material properties
PLOT(5,2) = 1;

% DATA INPUT
numincls = 4;
numholes = 0;
% [xh,yh,rh] = DATA_INCLS(numincls);
% [xhh,yhh,rhh] = DATA_HOLES(numholes);
% [ xh, yh, rh, numincls  ] = Data_inc( numincls );

numcracks = 0;         %  no. of cracks
[ xh, yh, rh, xhh, yhh, rhh,am,anglem,xedgem,yedgem,alpham,numincls,numcracks,numholes ] = Data_inc( numincls,numcracks,numholes);

Em  = 74e3 ;
num = 0.3 ;
Ei  = 10e3*ones(1,numincls);
nui = 0.3*ones(1,numincls);
INC = [xh yh rh];
hole = [xhh yhh rhh];     
VOID = hole;

stressState='PLANE_STRESS';

% Compliance matrix C
Cm = Em/(1+num)/(1-2*num)*[ 1- num     num   0;
    num    1- num    0 ;
    0      0    0.5-num ];
for j=1:numincls
    Ci(:,:,j) = Ei(j)/(1+nui(j))/(1-2*nui(j))*[ 1-nui(j)         nui(j)   0;
        nui(j)    1-nui(j)        0 ;
        0         0         0.5-nui(j)];
end

% Main Crack Data
cc = [L/2 D/2]    ;                  % crack center coordinates
a = 20;                              % crack length
ang = 0;   %%% Crack Angle WRT Horizontal axis
an = pi/180*ang;
xCr   = [cc(1,1)-a/2*cos(an)    cc(1,2)-a/2*sin(an);    cc(1,1)+a/2*cos(an)    cc(1,2)+a/2*sin(an)];
xTipR  = [xCr(2,1)  xCr(2,2)];
xTipL = [xCr(1,1)  xCr(1,2)];

seg    = xCr(2,:) - xCr(1,:);        % Tip Segment
seg1   = xCr(1,:) - xCr(2,:);       % SEcond Function for left tip
alphaR = atan2(seg(2),seg(1));       % Inclination Angle
alphaL = atan2(seg1(2),seg1(1));
QTR    = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];
QTL    = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

% ---------------------------------------
% +++++++++++++++++++++++++++++
%            MESHING
% +++++++++++++++++++++++++++++
% ---------------------------------------

disp([num2str(toc),'   MESH GENERATION'])

% Four corner points
pt1 = [0 0] ;
pt2 = [L 0] ;
pt3 = [L D] ;
pt4 = [0 D] ;

elemType = 'Q4' ;
[node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);

numnode = size(node,1);
numelem = size(element,1);

uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)
topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';
% GET NODES ON DIRICHLET BOUNDARY AND ESSENTIAL BOUNDARY
dispNodes  = unique(botEdge);
tracNodes  = unique(topEdge);          % returns the same values as in topedge but with no repetitions

disp([num2str(toc),'LEVEL SET INITIALIZATION'])
x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
t1   = 1/norm(seg1)*seg1;
ls=zeros(numnode,3);

for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;               % normal LS
    ls(i,2) = ([x y]-xTipR)*t';     % tangent LS
    ls(i,3) = ([x y]-xTipL)*t1';   % tangent LS Second tip LeftTip
end

enrich_node = zeros(numnode,1);
count1 = 0;
count2 = 0;

for iel = 1: numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    psi1 = ls(sctr,3);
    
    if ( max(phi)*min(phi) < 0 )% && max(psi1)*min(psi1) > 0)
        if (max(psi) < 0 ) && (max(psi1) < 0) %
            count1 = count1 + 1 ;
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        end
    end
end

for iel = 1: numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    psi1 = ls(sctr,3);
    xdiff=xTipR(1)-node(sctr,1);
    ydiff=xTipR(2)-node(sctr,2);

    xdiff1=xTipL(1)-node(sctr,1);
    ydiff1=xTipL(2)-node(sctr,2);

    if ( max(phi)*min(phi) < 0 )

        if  (max(psi)*min(psi) < 0 )%&& (max(xdiff)*min(xdiff)<0 && max(ydiff)*min(ydiff)<0) )
            if (max(xdiff)*min(xdiff)<0 && max(ydiff)*min(ydiff)<0)
                count2 = count2 + 1 ; % one tip element
                tip_elem(count2) = iel;
                enrich_node(sctr)   = 2;
            end
            if (enrich_node(sctr)   == 0|enrich_node(sctr)   == 1)
                count1 = count1 + 1 ;
                split_elem(count1) = iel;
                enrich_node(sctr)   = 1;
            end
        end
        if  (max(psi1)*min(psi1) < 0 )%&& (max(xdiff1)*min(xdiff1)<0 && max(ydiff1)*min(ydiff1)<0) )
            if (max(xdiff1)*min(xdiff1)<0 && max(ydiff1)*min(ydiff1)<0)
                count2 = count2 + 1 ; % one tip element
                tip_elem(count2) = iel;
                enrich_node(sctr)   = 2;
                if (enrich_node(sctr)   == 0|enrich_node(sctr)   == 1)
                    count1 = count1 + 1 ;
                    split_elem(count1) = iel;
                    enrich_node(sctr)   = 1;
                end
            end
        end

    end
end
enrich_node = zeros(numnode,1);
split_elem  = setdiff(split_elem,tip_elem);
Felement    = union(split_elem,tip_elem);
split_nodes = unique(element(split_elem,:));
trr         = element(tip_elem,:);
tip_nodes   =  unique(trr');
split_nodes =  setdiff(split_nodes,tip_nodes);

% LEVEL SET INITIALIZATION FOR INCLUSIONS
%===========================================================

[ ls_h,enrich_node,split_nodes_h,Tot_split_elem_h,split_elem_h ] = LS_Inc( xh,yh,rh,split_nodes,tip_nodes,numincls);

%    LEVEL SET INITIALIZATION FOR MICRO CRACK
%===========================================================

[ xCr_m, xTip_m,seg_m,QT_m,ls_m,split_elem_m ] = LS_Mics( numcracks, xedgem, yedgem,alpham,am);

%    LEVEL SET INITIALIZATION FOR HOLES
%===========================================================

[ ls_hh,hole_nodes,split_nodes_hh,Tot_split_elem_hh,split_elem_hh ] = LS_Hols( numholes,xhh,yhh,rhh);

figure
hold on
cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
set(cntr,'LineWidth',3);
plot_mesh(node,element,elemType,'b-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
n1 = plot(node(split_nodes,1),node(split_nodes,2),'r*');
n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
set(n1,'MarkerSize',5);
set(n2,'MarkerSize',5);
theta = 0:0.5:360;
np=size(theta,2);
for j=1:numholes
    xp(j,1:np) = rhh(j)*cosd(theta)+xhh(j);
    yp(j,1:np) = rhh(j)*sind(theta)+yhh(j);
    fill(xp(j,1:np),yp(j,1:np),'w','LineStyle','none')
end
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-');
end
for j=1:numcracks
    cr1 = plot(xCr_m(:,1,j),xCr_m(:,2,j),'r-');
    set(cr1,'LineWidth',2);
end
set(gcf, 'color', 'white');
axis equal
axis off

for j=1:numholes
    nf=size(find(split_nodes_hh(:,j)),1);
    nf1=size(split_nodes,1);
    nf2=size(union(split_nodes(1:nf1,1),split_nodes_hh(1:nf,j)),1);
    split_nodes(1:nf2,1)= union(split_nodes(1:nf1,1),split_nodes_hh(1:nf,j));
end

enrich_node(split_nodes(:,1))    = 1;
enrich_node(tip_nodes(:,1))      = 2;

for j=1:numincls
    ns=size(find(split_nodes_h (:,j)),1);
    split_nodes=union(split_nodes,split_nodes_h(1:ns,j));
end

total_unknown = numnode*2 + size(split_nodes,1)*1*2 + size(tip_nodes,1)*4*2;

for j=1:numcracks
    ns=size((split_elem_m(j,:)),2);
    ind=0;
    for jj=1:ns
        if split_elem_m(j,jj)>0
            ind=ind+1;
            ttt(j,1:4,ind) = element(split_elem_m(j,jj),:);
        end
    end
    split_nodes_m=unique(ttt(j,:,1:ind))';
    total_unknown = total_unknown + size(split_nodes_m,1)*1*2;
    enrich_node(split_nodes_m(:,1)) = 1;
end

for j=1:numcracks
    n6=size(split_elem_m(j,:),2);
    n7=size(unique(element(nonzeros(split_elem_m(j,1:n6)),:)),1);
    if n7==1
       n7=size(unique(element(nonzeros(split_elem_m(j,1:n6)),:)),2); 
    end
    split_nodes_mm(1:n7,j) = unique(element(nonzeros(split_elem_m(j,1:n6)),:));
end

split_nodes_Tot = nonzeros(unique(ttt));

K = sparse(total_unknown,total_unknown);
FMech = zeros(total_unknown,1);                       % f-matrix

pos = zeros(numnode,1);
nsnode = 0 ; ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1 || enrich_node(i) == 3)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end

T_split_nodes=[];
T_split_elem_h=[];
for j=1:numincls
    ns = size(find(split_nodes_h(:,j)),1);
    T_split_nodes  = [T_split_nodes; split_nodes_h(1:ns,j)];
    T_split_elem_h = [T_split_elem_h; Tot_split_elem_h(j,:)'];
end

q = [];
disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
% -----------------
% Loop on elements
% -----------------
for iel = 1 : numelem
    sctr = element(iel,:); % element connectivity
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))     % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
       
    elseif (ismember(iel,tip_elem))   % tip element
        order = 7;
        phi   = ls(sctr,1);
        nodes = node(sctr,:);
        [ dist1 ] = closeTip( nodes,xTipL );
        [ dist2 ] = closeTip( nodes,xTipR );       
        if (dist1<dist2)
            xTip2 =xTipL;
            alpha2=alphaL;
        else
            xTip2 =xTipR;
            alpha2=alphaR;
        end
        [W,Q] = disTipQ4quad(order,phi,nodes,xTip2);

    elseif (ismember(iel,split_elem_h(1:numincls,:)))
      for i=1:numincls
          if (ismember(iel,split_elem_h(i,:)))
              order = 4 ;
              phi   = ls_h(sctr,i);
              [W,Q] = discontQ4quad(order,phi);
          end
      end 
      
    elseif (ismember(iel,split_elem_m(1:numcracks,:)))
        for j=1:numcracks
            if (ismember(iel,split_elem_m(j,:)))
                order = 2 ;
                phi   = ls_m(sctr,3*(j-1)+1);
                [W,Q] = discontQ4quad(order,phi);
            end
        end 
      
    elseif (ismember(iel,Tot_split_elem_hh(1:numholes,:)))     % hole element       
        for j=1:numholes
            if (ismember(iel,Tot_split_elem_hh(j,:)))
                order = 2 ;
                phi   = ls_hh(sctr,j);
                [W,Q] = discontQ4quad(order,phi);
            end
        end  
          
    elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    
    else
        order = 2 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    end
    
     GZgp = zeros(size(W,1),numincls);
    
    for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        for j=1:numincls
            Zgp= N' * ls_h(sctr,j);
            GZgp(igp,j) = Zgp;
        end 
        Gpnt = N' * node(sctr,:); % global GP
        q  = [q;Gpnt];
    end
    
    sctrB = assembly(iel,enrich_node,pos);
    
    for kk = 1 : size(W,1)
        pt = Q(kk,:);                             % quadrature point
        
        if ismember(iel,split_elem)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);
        
        elseif ismember(iel,tip_elem)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);    
            
        elseif (ismember(iel,T_split_elem_h) || any(intersect(T_split_nodes,sctr)) ~= 0)
            for j=1:numincls
                ns=size(find(split_nodes_h(:,j)),1);
                if (ismember(iel,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
                    if GZgp(kk,j) > 0, C = Cm; else C = Ci(:,:,j); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);
                end
            end
            
        elseif (ismember(iel,Tot_split_elem_hh(1:numholes,:)))     % hole element        
           for j=1:numholes
               if (ismember(iel,Tot_split_elem_hh(j,:)))
                   C = Cm; 
                   [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));                  
               end
           end 
           
        elseif (ismember(iel,split_elem_m(1:numcracks,:)) || any(intersect(split_nodes_Tot,sctr)))
            for j=1:numcracks
                ns=size(find(split_nodes_mm(:,j)),1);
                if (ismember(iel,split_elem_m(j,:)) || any(intersect(split_nodes_mm(1:ns,j),sctr)))
                    if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr_m(:,:,j),xTip_m(:,:,j),alpham(j));
                end
            end
            
        else
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);
        end
        
        K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        
    end                  % end of looping on GPs 
end                      % end of looping on elements

% -------------------------------------
% % Plot GPs for checking
% figure
% hold on
% plot_mesh(node,element,elemType,'b-');
% plot(q(:,1),q(:,2),'r*');
% cr = plot(xCr(:,1),xCr(:,2),'r-');
% set(cr,'LineWidth',3);
% axis off
% clear q
% % -------------------------------------

% ************************
%    NODAL FORCE VECTOR
% ************************
disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;

    for q=1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        FMech(sctry)=FMech(sctry) + N*sigmato*det(J0)*wt;
        
    end   % of quadrature loop
end       % of element loop
% -------------------------------------

f=FMech;

% **********************************
%    ESSENTIAL BOUNDARY CONDITION
% **********************************
disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K));

vdofs = dispNodes.*2;
udofs = 1; % for lower left corner node

for j=1:numholes
    n1=size(find(hole_nodes(:,j)),1);
    vdofs1 = hole_nodes(1:n1,j)*2;
    udofs1 = hole_nodes(1:n1,j)*2-1;
    udofs=[udofs; udofs1];
    vdofs=[vdofs; vdofs1];
end

f(udofs) = 0 ;
f(vdofs) = 0 ;
K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

% **********************************
%          POST PROCESSING
% **********************************
disp([num2str(toc),'   POST PROCESSING'])

% **********************************
%       SOLUTION OF EQUATIONS
% **********************************
disp([num2str(toc),'   SOLUTION'])
u   = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'      Deformed configuration'])
% --------------------------------------------------
% %Plot numerical deformed configuration
figure
hold on
fac = 100;
plot_mesh(node+fac*[u_x u_y],element,elemType,'g-');
title(' Numerical deformed configuration ')
set(gcf, 'color', 'white');
axis equal
axis on

% --------------------------------------------------
% break
% ---------------------------------------------
% Compute stress at nodes and plot
disp([num2str(toc),'      Stress computation'])

stress = zeros(numelem,4,3);
for iel = 1:numelem
    sctr = element(iel,:); % element connectivity
    Q = [1 1; 1 -1; -1 1; -1 -1]; % four stress points to calculate stress
    W = [1;1;1;1];
    GZgp=zeros(4,numincls);
    
    for i = 1 : size(W,1)
        gpnt = Q(i,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:);    % global GP
        
        for j=1:numincls
            Zgp= N' * ls_h(sctr,j);
            GZgp(i,j) = Zgp;
        end        
    end
    
    U = element_disp(iel,pos,enrich_node,u);
    
    for kk = 1 : size(W,1)
        pt = Q(kk,:);                             % quadrature point
        if ismember(iel,split_elem)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);
            
        elseif ismember(iel,tip_elem)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);    
            
        elseif (ismember(iel,T_split_elem_h) || any(intersect(T_split_nodes,sctr)) ~= 0)
            for j=1:numincls
                ns=size(find(split_nodes_h(:,j)),1);
                if (ismember(iel,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
                    if GZgp(kk,j) > 0, C = Cm; else C = Ci(:,:,j); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);
                end
            end
            
        elseif (ismember(iel,Tot_split_elem_hh(1:numholes,:)))     % hole element        
           for j=1:numholes
               if (ismember(iel,Tot_split_elem_hh(j,:)))
                   C = Cm; 
                   [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));                  
               end
           end     
        
        elseif (ismember(iel,split_elem_m(1:numcracks,:)) || any(intersect(split_nodes_Tot,sctr)))
            for j=1:numcracks
                ns=size(find(split_nodes_mm(:,j)),1);
                if (ismember(iel,split_elem_m(j,:)) || any(intersect(split_nodes_mm(1:ns,j),sctr)))
                    if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr_m(:,:,j),xTip_m(:,:,j),alpham(j));
                end
            end
            
        else
            if GZgp(kk,j) > 0, C = Cm; else C = Ci(:,:,j); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,ls_h(:,j),xTipR,alphaR);
        end
        
        strain = B*U;
        stress(iel,kk,:) = C*strain;
        
    end                  % end of looping on GPs
end                      % end of looping on elements

plotContour(stress);

% -------------------------------------------------------------------------
disp([num2str(toc),'      Stress intensity factors computation'])
% -------------------------------------------------------------------------

[JdomainR,qnodeR,radiusR] = Jdomain(tip_elem(2),xTipR);
[JdomainL,qnodeL,radiusL] = Jdomain(tip_elem(1),xTipL);

% plot
figure
hold on
% plot the circle
theta = -pi:0.1:pi;
xoL = xTipL(1,1) + radiusL*cos(theta) ;
yoL = xTipL(1,2) + radiusL*sin(theta) ;
plot(xoL,yoL,'k-');
plot_mesh(node,element,'Q4','b-')
plot_mesh(node,element(JdomainL,:),'Q4','r-')
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(cr,'LineWidth',2);
xoR = xTipR(1,1) + radiusR*cos(theta) ;
yoR = xTipR(1,2) + radiusR*sin(theta) ;
plot(xoR,yoR,'k-');
plot_mesh(node,element(JdomainR,:),'Q4','r-')
theta = 0:0.5:360;
np=size(theta,2);
for j=1:numholes
    xp(j,1:np) = rhh(j)*cosd(theta)+xhh(j);
    yp(j,1:np) = rhh(j)*sind(theta)+yhh(j);
    fill(xp(j,1:np),yp(j,1:np),'w','LineStyle','none')
end
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
for j=1:numcracks
    cr1 = plot(xCr_m(:,1,j),xCr_m(:,2,j),'r-');
    set(cr1,'LineWidth',2);
end
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(cr,'LineWidth',3);
set(gcf, 'color', 'white');

% --------------------------------------------
%break
%---------------------------------------------
% Compute interaction integral

% [ K1L, K2L, K1eqL, theta_CL ] = sif( JdomainL, ls, split_elem, qnodeL, xCr, xTipL, alphaL, pos, enrich_node, u, QTL)
[ K1L, K2L, K1eqL, theta_CL ] = sif( JdomainL, ls, split_elem, qnodeL, xCr, xTipL, alphaL, pos, enrich_node, u, QTL,split_elem_h,ls_h,T_split_elem_h,T_split_nodes,split_nodes_h,Tot_split_elem_h,numincls)

alphaL = theta_CL+alphaL;
anglereqL = alphaL*180/pi ;                           
QTL = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

% [ K1R, K2R, K1eqR, theta_CR ] = sif( JdomainR, ls, split_elem, qnodeR, xCr, xTipR, alphaR, pos, enrich_node, u, QTR)
[ K1R, K2R, K1eqR, theta_CR ] = sif( JdomainR, ls, split_elem, qnodeR, xCr, xTipR, alphaR, pos, enrich_node, u, QTR,split_elem_h,ls_h,T_split_elem_h,T_split_nodes,split_nodes_h,Tot_split_elem_h,numincls)

alphaR = theta_CR+alphaR;
anglereqR = alphaR*180/pi;
QTR = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];

pat = [];
pat = [pat; 0 0 K1L K2L K1R K2R K1eqL K1eqR ];
aaL = 0;
aaR = 0;
                                
% disp([num2str(toc),'Plane Strain'])

% Compute the exact SIFs

F = 1.0 + 0.128*(a/L) - 0.288*(a/L)^2 + 1.523*(a/L)^3 ;
F1 = sqrt(1+0.50*(a/2/L)^2+20.46*(a/2/L)^4+81.72*(a/2/L)^6);

KexactGdouts = F * sigmato*sqrt(pi*a/2)

KexactParez = F1 * sigmato*sqrt(pi*a/2)

% aIL = aImax; aIR = aImax;
% 
% if K1eqL >=K1eqR
%     
%     K1eq_MAX = K1eqL;
% else
%     K1eq_MAX = K1eqR;
% end
if K1eqL >= K1eqR % comparision to find out the dominant crack tip

    aIL = aImax;

    aIR = aImax*((K1eqR/K1eqL)^M);
else

    aIR = aImax;

    aIL = aImax*((K1eqL/K1eqR)^M);
end

if K1eqL >=K1eqR
    K1eq_MAX = K1eqL;
else
    K1eq_MAX = K1eqR;
end
% K1eq_MAX is Used for crack propagation criterion

xCr(3,:) = [xTipR(1,1)+aIR*cos(alphaR) xTipR(1,2)+aIR*sin(alphaR)]; 

xCr = [[xTipL(1,1)+aIL*cos(alphaL) xTipL(1,2)+aIL*sin(alphaL)];xCr];

xTipR(2,:) = xCr(4,:); % new right crack tip
xTipL(2,:) = xCr(1,:); % new left crack tip
jj = 2;

% ====================================================================== %
%               While loop for Fatigue crack propagation
% ====================================================================== %

while K1eq_MAX < KIC % check whether SIF is still less than fracture toughness
    
    clear K JdomainR JdomainL pos enrich_node split_nodes pos split_elem tip_elem ttt
    
    NNL = NNL + aIL/(DD*K1eqL^M); %%%%%%  Life calculation
    NCL = [NCL; NNL];

    NNR = NNR + aIR/(DD*K1eqR^M); %%%%%%  Life calculation
    NCR = [NCR; NNR];

    % ====================================================================== %
    %                          FOR LEFT EDGE CRACK
    % ====================================================================== %
    
    xaL  = xTipL(jj-1,1); yaL = xTipL(jj-1,2);
    xbL  = xTipL(jj,1);   ybL = xTipL(jj,2);

    seg2L   = xCr(jj-1,:) - xCr(jj,:);         %  New segment
    seg22L  = xCr(jj,:) - xCr(jj-1,:);        %  New segment
    t2L   = 1/norm(seg2L)*seg2L;
    t22L  = 1/norm(seg22L)*seg22L;

    lsLL = zeros(numnode,3);
    for i = 1 : numnode
        x = node(i,1);
        y = node(i,2);
        lL   = sqrt((xbL-xaL)*(xbL-xaL)+(ybL-yaL)*(ybL-yaL)) ;  % crack length
        phiL = (yaL-ybL)*x + (xbL-xaL)*y + (xaL*ybL-xbL*yaL);   % area
        lsLL(i,1) = -phiL/lL;                                    % normal LS        % y-distance from node to crack line
        lsLL(i,2) = ([x y]-xTipL(jj,:))*t2L';
        lsLL(i,3) = ([x y]-xTipL(jj-1,:))*t22L';                                   % x-distance of node previous tip
    end
    
    split_elemL = [];
    count1 = 0;
    count2 = 0;
    tip_elemL = [];
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = lsLL(sctr,1);
    psi  = lsLL(sctr,2);
    psi2 = lsLL(sctr,3);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) < 0&& max(psi2) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elemL(count1) = iel;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elemL(count2) = iel;
        end
    end
end

    % ====================================================================== %
    %                          FOR RIGHT EDGE CRACK
    % ====================================================================== %

    xaR  = xTipR(jj-1,1); yaR = xTipR(jj-1,2);
    xbR  = xTipR(jj,1);   ybR = xTipR(jj,2);

    seg2R   = xCr(jj+2,:) - xCr(jj+1,:);  
    seg22R  = xCr(jj+1,:) - xCr(jj+2,:);           %  New segment
    t2R   = 1/norm(seg2R)*seg2R;
    t22R  = 1/norm(seg22R)*seg22R;

    lsRR = zeros(numnode,3);
    for i = 1 : numnode
        x = node(i,1);
        y = node(i,2);
        lR   = sqrt((xbR-xaR)*(xbR-xaR)+(ybR-yaR)*(ybR-yaR)) ;  % crack length
        phiR = (yaR-ybR)*x + (xbR-xaR)*y + (xaR*ybR-xbR*yaR);   % area
        lsRR(i,1) = phiR/lR;                                    % normal LS         % y-distance from node to crack line
        lsRR(i,2) = ([x y]-xTipR(jj,:))*t2R'; 
        lsRR(i,3) = ([x y]-xTipR(jj-1,:))*t22R';                                      % x-distance of node previous tip
    end

    split_elemR = [];
    count1 = 0;
    count2 = 0;
    tip_elemR = [];
for iel =  numelem:-1:1
    sctr = element(iel,:);
    phi  = lsRR(sctr,1);
    psi  = lsRR(sctr,2);
    psi2  = lsRR(sctr,3);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) <0 &&max(psi2) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elemR(count1) = iel;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elemR(count2) = iel;
        end
    end
end


FaL = union(split_elemL,tip_elemL);
ls(unique(element(FaL,:)),1) = lsLL(unique(element(FaL,:)),1);

FaR = union(split_elemR,tip_elemR);
ls(unique(element(FaR,:)),1) = lsRR(unique(element(FaR,:)),1);

split_elem  = union(Felement, split_elemL);
split_elem  = union(split_elem, split_elemR);
split_nodes = unique(element(split_elem,:));
trrL        = element(tip_elemL,:);
tip_nodesL  =  unique(trrL');
trrR        = element(tip_elemR,:);
tip_nodesR  =  unique(trrR');
tip_nodes   =  union(tip_nodesL, tip_nodesR);
split_nodes =  setdiff(split_nodes,tip_nodes);
tip_elem    =  union(tip_elemL,tip_elemR);  
Felement    =  union(split_elem,tip_elem);
split_nodes1 = split_nodes;
enrich_node = zeros(numnode,1);

for j=1:numincls
    xx=find(split_nodes(:,1));
    n9=size(xx,1);
    yy=setdiff(split_nodes_h(:,j),split_nodes(1:n9,1));
    n10=size(yy,1);
    split_nodes_h(1:n10,j) = setdiff(split_nodes_h(:,j),split_nodes(1:n9,1));
    zz=setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
    n11=size(zz,1);
    split_nodes_h(1:n11,j) = setdiff(split_nodes_h(1:n10,j),tip_nodes(:,1));
    T_split_nodes = setdiff(T_split_nodes,split_nodes);
    T_split_nodes = setdiff(T_split_nodes,tip_nodes);
    
    ns=size(find(split_nodes_h (:,j)),1);
    enrich_node(nonzeros(split_nodes_h (1:ns,j))) = 3;
end

for j=1:numholes
    nf=size(find(split_nodes_hh(:,j)),1);
    nf1=size(split_nodes,1);
    nf2=size(union(split_nodes(1:nf1,1),split_nodes_hh(1:nf,j)),1);
    split_nodes(1:nf2,1)= union(split_nodes(1:nf1,1),split_nodes_hh(1:nf,j));
end

enrich_node(nonzeros(split_nodes(:,1))) = 1;
enrich_node(tip_nodes(:,1)) = 2;

 disp([num2str(toc),'   PLOT NODES AND GAUSS POINTS'])
 
    % % ++++++++++++++++++++++++++++++++++++ % %
    % PLOT NODES, BACKGROUND MESH, GPOINTS %
    % % ++++++++++++++++++++++++++++++++++++ % %
    
figure
hold on
cntr = plot([0,L,L,0,0],[0,0,D,D,0]);
set(cntr,'LineWidth',3);
plot_mesh(node,element,elemType,'b-');
cr = plot(xCr(:,1),xCr(:,2),'r-');
set(cr,'LineWidth',3);
n1 = plot(node(split_nodes1,1),node(split_nodes1,2),'r*');
n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'rs');
set(n1,'MarkerSize',5);
set(n2,'MarkerSize',5);
theta = 0:0.5:360;
np=size(theta,2);
for j=1:numholes
    xp(j,1:np) = rhh(j)*cosd(theta)+xhh(j);
    yp(j,1:np) = rhh(j)*sind(theta)+yhh(j);
    fill(xp(j,1:np),yp(j,1:np),'w','LineStyle','none')
end
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
for j=1:numcracks
    cr1 = plot(xCr_m(:,1,j),xCr_m(:,2,j),'r-');
    set(cr1,'LineWidth',2);
end
set(gcf, 'color', 'white');
axis off
axis equal

for j=1:numincls
    ns=size(find(split_nodes_h (:,j)),1);
    split_nodes=union(split_nodes,split_nodes_h(1:ns,j));
end

total_unknown = numnode*2 + size(nonzeros(split_nodes),1)*1*2 + size(tip_nodes,1)*4*2;

for j=1:numcracks
    ns=size((split_elem_m(j,:)),2);
    ind=0;
    for jjj=1:ns
        if split_elem_m(j,jjj)>0
            ind=ind+1;
            ttt(j,1:4,ind) = element(split_elem_m(j,jjj),:);
        end
    end
    split_nodes_m=unique(ttt(j,:,1:ind))';
    total_unknown = total_unknown + size(split_nodes_m,1)*1*2;
    enrich_node(split_nodes_m(:,1)) = 1;
end

K = sparse(total_unknown,total_unknown);
FMech = zeros(total_unknown,1);

% ***********************************
%    Stiffness matrix computation
% ***********************************

disp([num2str(toc),'   DOMAIN ASSEMBLY'])

pos = zeros(numnode,1);
nsnode = 0 ; ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1 || enrich_node(i) == 3)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        ntnode = ntnode + 1 ;
    end
end

T_split_nodes=[];
T_split_elem_h=[];
for j=1:numincls
    ns=size(find(split_nodes_h(:,j)),1);
    T_split_nodes=[T_split_nodes; split_nodes_h(1:ns,j)];
    T_split_elem_h=[T_split_elem_h;Tot_split_elem_h(j,:)'];
end

disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])
qq =[];

for iel = 1 : numelem
    sctr = element(iel,:); % element connectivity
    
    % Choose Gauss quadrature rules for elements
    if (ismember(iel,split_elem))     % split element
        order = 2 ;
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);
        
    elseif (ismember(iel,tip_elemL))   % tip element
        order = 7;
        phiL   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phiL,nodes,xTipL(jj,:));
       
    elseif (ismember(iel,tip_elemR))   % tip element
        order = 7;
        phiR   = ls(sctr,1);
        nodes = node(sctr,:);
        [W,Q] = disTipQ4quad(order,phiR,nodes,xTipR(jj,:));
        
    elseif (ismember(iel,split_elem_h(1:numincls,:)))
      for i=1:numincls
          if (ismember(iel,split_elem_h(i,:)))
              order = 4 ;
              phi   = ls_h(sctr,i);
              [W,Q] = discontQ4quad(order,phi);
          end
      end  
      
    elseif (ismember(iel,split_elem_m(1:numcracks,:)))
        for j=1:numcracks
            if (ismember(iel,split_elem_m(j,:)))
                order = 2 ;
                phi   = ls_m(sctr,3*(j-1)+1);
                [W,Q] = discontQ4quad(order,phi);
            end
        end 
      
    elseif (ismember(iel,Tot_split_elem_hh(1:numholes,:)))     % hole element       
        for j=1:numholes
            if (ismember(iel,Tot_split_elem_hh(j,:)))
                order = 2 ;
                phi   = ls_hh(sctr,j);
                [W,Q] = discontQ4quad(order,phi);
            end
        end  
        
    elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
        order = 4 ;
        [W,Q] = quadrature(order,'GAUSS',2);
        
    else
        order = 2 ;
        [W,Q] = quadrature(order,'GAUSS',2);
    end   
   
     % Transform these Gauss points to global coords for plotting only   
    GZgp=zeros(size(W,1),numincls);
    
    for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        
        for j=1:numincls
            Zgp= N' * ls_h(sctr,j);
            GZgp(igp,j) = Zgp;
        end 
        Gpnt = N' * node(sctr,:); % global GP
        qq = [qq;Gpnt];
    end
    
    sctrB = assembly(iel,enrich_node,pos);
    
    for kk = 1 : size(W,1)
        pt = Q(kk,:);                             % quadrature point
        
        if ismember(iel,split_elem)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
            
        elseif ismember(iel,tip_elemL)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
            
        elseif ismember(iel,tip_elemR)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);    
            
        elseif (ismember(iel,T_split_elem_h) || any(intersect(T_split_nodes,sctr)) ~= 0)
            for j=1:numincls
                ns=size(find(split_nodes_h(:,j)),1);
                if (ismember(iel,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
                    if GZgp(kk,j) > 0, C = Cm; else C = Ci(:,:,j); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
                end
            end
            
        elseif (ismember(iel,Tot_split_elem_hh(1:numholes,:)))     % hole element        
           for j=1:numholes
               if (ismember(iel,Tot_split_elem_hh(j,:)))
                   C = Cm; 
                   [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));                  
               end
           end 
           
        elseif (ismember(iel,split_elem_m(1:numcracks,:)) || any(intersect(split_nodes_Tot,sctr)))
            for j=1:numcracks
                ns=size(find(split_nodes_mm(:,j)),1);
                if (ismember(iel,split_elem_m(j,:)) || any(intersect(split_nodes_mm(1:ns,j),sctr)))
                    if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr_m(:,:,j),xTip_m(:,:,j),alpham(j));
                end
            end
            
        else
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
        end
        
        K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
        
    end                  % end of looping on GPs       
end                      % end of looping on elements

% figure
% hold on
% plot_mesh(node,element,elemType,'b-');
% plot(qq(:,1),qq(:,2),'r*');
% crL = plot(xCrL(:,1),xCrL(:,2),'r-');
% crR = plot(xCrR(:,1),xCrR(:,2),'r-');
% set(crL,'LineWidth',3);
% set(crR,'LineWidth',3);
% axis off
clear qq

% ************************
%    NODAL FORCE VECTOR
% ************************
disp([num2str(toc),'   NODAL FORCE VECTOR COMPUTATION'])

% The top edge is applied a traction along Y direction
[W,Q]=quadrature(1,'GAUSS',1);
for e = 1:size(topEdge,1)
    sctr = topEdge(e,:);
    sctry = sctr.*2 ;

    for q=1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        N  = lagrange_basis('L2',pt);
        J0 = abs( node(sctr(2))-node(sctr(1)) )/2;
        FMech(sctry)=FMech(sctry) + N*sigmato*det(J0)*wt;
        
    end   % of quadrature loop

end       % of element loop
% -------------------------------------

f=FMech;

% **********************************
%    ESSENTIAL BOUNDARY CONDITION
% **********************************
disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K));

vdofs = dispNodes.*2;
udofs = 1; % for lower left corner node

for j=1:numholes
    n1=size(find(hole_nodes(:,j)),1);
    vdofs1 = hole_nodes(1:n1,j)*2;
    udofs1 = hole_nodes(1:n1,j)*2-1;
    udofs=[udofs; udofs1];
    vdofs=[vdofs; vdofs1];
end

f(udofs) = 0 ;
f(vdofs) = 0 ;
K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

% **********************************
%          POST PROCESSING
% **********************************
disp([num2str(toc),'   POST PROCESSING'])

% **********************************
%       SOLUTION OF EQUATIONS
% **********************************
disp([num2str(toc),'   SOLUTION'])
u   = K\f;
u_x = u(1:2:2*numnode) ;
u_y = u(2:2:2*numnode) ;

disp([num2str(toc),'      Deformed configuration'])
% --------------------------------------------------
%Plot numerical deformed configuration
% figure
% hold on
% fac = 100;
% plot_mesh(node+fac*[u_x u_y],element,elemType,'g-');
% title(' Numerical deformed configuration ')
% set(gcf, 'color', 'white');
% axis off
% --------------------------------------------------
% break
% --------------------------------------------------

disp([num2str(toc),'      Stress computation'])

stress = zeros(numelem,4,3);
for iel = 1:numelem
    sctr = element(iel,:); % element connectivity
    Q = [1 1; 1 -1; -1 1; -1 -1]; % four stress points to calculate stress
    W = [1;1;1;1];
    GZgp=zeros(4,numincls);
    
    for i = 1 : size(W,1)
        gpnt = Q(i,:);
        [N,dNdxi]=lagrange_basis('Q4',gpnt);
        Gpnt = N' * node(sctr,:);    % global GP      
        for j=1:numincls
            Zgp= N' * ls_h(sctr,j);
            GZgp(i,j) = Zgp;
        end        
    end
    
    U = element_disp(iel,pos,enrich_node,u);
    
    for kk = 1 : size(W,1)
        pt = Q(kk,:);                             % quadrature point
        if ismember(iel,split_elem)
            if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
            
        elseif (ismember(iel,T_split_elem_h) || any(intersect(T_split_nodes,sctr)) ~= 0)
            for j=1:numincls
                ns=size(find(split_nodes_h(:,j)),1);
                if (ismember(iel,Tot_split_elem_h(j,:)) || any(intersect(split_nodes_h(1:ns,j),sctr)) ~= 0)
                    if GZgp(kk,j) > 0, C = Cm; else C = Ci(:,:,j); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
                end
            end
            
        elseif (ismember(iel,Tot_split_elem_hh(1:numholes,:)))     % hole element        
           for j=1:numholes
               if (ismember(iel,Tot_split_elem_hh(j,:)))
                   C = Cm; 
                   [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));                  
               end
           end 
           
        elseif (ismember(iel,split_elem_m(1:numcracks,:)) || any(intersect(split_nodes_Tot,sctr)))
            for j=1:numcracks
                ns=size(find(split_nodes_mm(:,j)),1);
                if (ismember(iel,split_elem_m(j,:)) || any(intersect(split_nodes_mm(1:ns,j),sctr)))                   
                    if GZgp(kk,1) > 0, C = Cm; else C = Ci(:,:,1); end
                    [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr_m(:,:,j),xTip_m(:,:,j),alpham(j));
                    
                end
            end
            
        else
            if GZgp(kk,j) > 0, C = Cm; else C = Ci(:,:,j); end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL(jj,:),alphaL,ls_h(:,j),xTipR(jj,:),alphaR);
        end
        
        strain = B*U;
        stress(iel,kk,:) = C*strain;
        
    end                  % end of looping on GPs
end                      % end of looping on elements

 plotContour(stress);

    %-----------------------------------------------------
    %  Stress intensity factor computation For LEFT crack
    % -----------------------------------------------------
    
 disp([num2str(toc),'      Stress intensity factors computation'])
 
[JdomainL,qnodeL,radiusL] = Jdomain(max(tip_elemL),xTipL(jj,:));
[JdomainR,qnodeR,radiusR] = Jdomain(min(tip_elemR),xTipR(jj,:));

% % plot
figure
hold on
% plot the circle
theta = -pi:0.1:pi;
xoL = xTipL(jj,1) + radiusL*cos(theta) ;
yoL = xTipL(jj,2) + radiusL*sin(theta) ;
plot(xoL,yoL,'k-');
plot_mesh(node,element,'Q4','b-')
plot_mesh(node,element(JdomainL,:),'Q4','r-')
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(cr,'LineWidth',2);
xoR = xTipR(jj,1) + radiusR*cos(theta) ;
yoR = xTipR(jj,2) + radiusR*sin(theta) ;
plot(xoR,yoR,'k-');
plot_mesh(node,element(JdomainR,:),'Q4','r-')
theta = 0:0.5:360;
np=size(theta,2);
for j=1:numholes
    xp(j,1:np) = rhh(j)*cosd(theta)+xhh(j);
    yp(j,1:np) = rhh(j)*sind(theta)+yhh(j);
    fill(xp(j,1:np),yp(j,1:np),'w','LineStyle','none')
end
for j=1:numincls
    xx(j,1:np)=xh(j)+rh(j)*cos(theta);
    yy(j,1:np)=yh(j)+rh(j)*sin(theta);
    plot(xx(j,1:np),yy(j,1:np),'k-')
end
for j=1:numcracks
    cr1 = plot(xCr_m(:,1,j),xCr_m(:,2,j),'r-');
    set(cr1,'LineWidth',2);
end
cr = plot(xCr(:,1),xCr(:,2),'k-');
set(cr,'LineWidth',3);
set(gcf, 'color', 'white');

[ K1L, K2L, K1eqL, theta_CL ] = sif( JdomainL, ls, split_elem, qnodeL, xCr, xTipL(jj,:), alphaL, pos, enrich_node, u, QTL,split_elem_h,ls_h,T_split_elem_h,T_split_nodes,split_nodes_h,Tot_split_elem_h,numincls)

alphaL = theta_CL+alphaL;
anglereqL = alphaL*180/pi                           
QTL = [cos(alphaL) sin(alphaL); -sin(alphaL) cos(alphaL)];

[ K1R, K2R, K1eqR, theta_CR ] = sif( JdomainR, ls, split_elem, qnodeR, xCr, xTipR(jj,:), alphaR, pos, enrich_node, u, QTR,split_elem_h,ls_h,T_split_elem_h,T_split_nodes,split_nodes_h,Tot_split_elem_h,numincls)

alphaR = theta_CR+alphaR;
anglereqR = alphaR*180/pi
QTR = [cos(alphaR) sin(alphaR); -sin(alphaR) cos(alphaR)];

aaL = aaL + aIL;
aaR = aaR + aIR;
pat = [pat; aaL aaR K1L K2L K1R K2R K1eqL K1eqR];

% Compute the exact SIFs
a = a+2*aImax;
F = 1.0 + 0.128*(a/L) - 0.288*(a/L)^2 + 1.523*(a/L)^3 ;
F1 = sqrt(1+0.50*(a/2/L)^2+20.46*(a/2/L)^4+81.72*(a/2/L)^6);

KexactGdouts = F * sigmato*sqrt(pi*a/2)

KexactParez = F1 * sigmato*sqrt(pi*a/2)

% aIL = aImax; aIR = aImax;
% 
% if K1eqL >=K1eqR
%     
%     K1eq_MAX = K1eqL;
% else
%     K1eq_MAX = K1eqR;
% end

if K1eqL >= K1eqR % comparision to find out the dominant crack tip

    aIL = aImax;

    aIR = aImax*((K1eqR/K1eqL)^M);
else

    aIR = aImax;

    aIL = aImax*((K1eqL/K1eqR)^M);
end

if K1eqL >=K1eqR
    K1eq_MAX = K1eqL;
else
    K1eq_MAX = K1eqR;
end

% K1eq_MAX is Used for crack propagation criterion
ss = size(xCr,1);
xCr = [[xTipL(jj,1)+aIL*cos(alphaL) xTipL(jj,2)+aIL*sin(alphaL)];xCr];% New right crack segment

xCr(ss+2,:) = [xTipR(jj,1)+aIR*cos(alphaR) xTipR(jj,2)+aIR*sin(alphaR)]; % New left  crack segment

xTipR(jj+1,:) = xCr(ss+2,:); % new right crack tip
xTipL(jj+1,:) = xCr(1,:);    % new left crack tip

jj = jj+1;
end

ss1 = size(pat,1);
KeqL = pat(ss1-1,7);
KeqR = pat(ss1-1,8);

if (KeqR<KeqL)
    daL = ((KIC-KeqL)*aImax)/(pat(ss1,7)-KeqL);
    Li = daL/(DD*KIC^M);
    Life = NCL(ss1-1)+ Li
    CracklengthL = (pat(ss1-1,1)+daL);
    daR = daL*((K1eqR/K1eqL)^M);
    CracklengthR = (pat(ss1-1,2)+daR);
else
    daR = ((KIC-KeqR)*aImax)/(pat(ss1,8)-KeqR);
    Li = daR/(DD*KIC^M);
    Life = NCR(ss1-1)+ Li
    CracklengthR = (pat(ss1-1,2)+daR);
    daL = daR*((K1eqL/K1eqR)^M);
    CracklengthL = (pat(ss1-1,1)+daL);
end

Cracklength = CracklengthL+CracklengthR

figure
hold on
plot(pat(:,1),pat(:,3),'-bs','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',10)
plot(pat(:,1),pat(:,4),'-rs','LineWidth',2,'MarkerEdgeColor','g','MarkerFaceColor','r','MarkerSize',10)
plot(pat(:,2),pat(:,5),'-bs','LineWidth',2,'MarkerEdgeColor','m','MarkerFaceColor','r','MarkerSize',10)
plot(pat(:,2),pat(:,6),'-rs','LineWidth',2,'MarkerEdgeColor','y','MarkerFaceColor','r','MarkerSize',10)
xlabel('Crack Extension (mm)')
ylabel('Stress Intensity Factors (N/mm^{3/2})')
plot(CracklengthL,KIC,'g*')
plot(CracklengthR,KIC,'g*')
axis ([-1 20 -500 2500])
set(gcf,'color','white');
legend('K_I','K_{II}',2)
grid on

figure
hold on
plot(NCL,(pat(1:size(NCL,1),1)+ pat(1:size(NCR,1),2)),'-bo','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',8)
plot(NCL,pat(1:size(NCL,1),1),'-ks','LineWidth',2,'MarkerEdgeColor','g','MarkerFaceColor','r','MarkerSize',7)
plot(NCR,pat(1:size(NCR,1),2),'-kd','LineWidth',2,'MarkerEdgeColor','g','MarkerFaceColor','r','MarkerSize',8)
plot(Life,CracklengthL,'m*')
plot(Life,CracklengthR,'m*')
plot(Life,Cracklength,'m*')
ylabel('Crack Extension (mm)')
xlabel(' No. of cycles')
set(gcf,'color','white');
legend('Total Extension','Extension Left Edge','Extension Right Edge',2)
axis ([-200 6e3 -2 40])
grid on

    T_pat(:,:,ijk)=pat
    T_NCL(:,ijk)=NCL;
    T_NCR(:,ijk)=NCR;
    T_Life(ijk,1)=Life
    T_Cracklength(ijk,1)=Cracklength
    T_CracklengthL(ijk,1)=CracklengthL;
    T_CracklengthR(ijk,1)=CracklengthR;
end