function [ xCr_m, xTip_m,seg_m,QT_m,ls_m,split_elem_m ] = LS_Mics( numcracks, xedgem, yedgem,alpham,am)

%    LEVEL SET INITIALIZATION FOR MICRO CRACK
%===========================================================

global  node element
numnode = size(node,1);
numelem = size(element,1);

for i = 1:numcracks
    xCr_m(:,:,i)  = [xedgem(i) yedgem(i); xedgem(i)+am(i)*cos(alpham(i)) yedgem(i)+am(i)*sin(alpham(i))];      % crack coordinates
    xTip_m(:,:,i) = [xedgem(i)+am(i)*cos(alpham(i)) yedgem(i)+am(i)*sin(alpham(i))];                           % crack tip coordinates
    seg_m(:,:,i)  = xCr_m(2,:,i) - xCr_m(1,:,i);                                                               % tip segment
    QT_m(:,:,i)   = [cos(alpham(i)) sin(alpham(i)); -sin(alpham(i)) cos(alpham(i))];
end

for i = 1:numcracks
    x_0(i) = xCr_m(1,1,i);
    y_0(i) = xCr_m(1,2,i);
    x_1(i) = xCr_m(2,1,i);
    y_1(i) = xCr_m(2,2,i);
    t_m(:,:,i)  = 1/norm(seg_m(:,:,i))*seg_m(:,:,i);
end

ls_m  = zeros(numnode,3*numcracks);

for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    
    for j=1:numcracks
        lc(:,j)   = sqrt((x_1(j)-x_0(j))*(x_1(j)-x_0(j))+(y_1(j)-y_0(j))*(y_1(j)-y_0(j))) ;
        phic(:,j) = (y_0(j)-y_1(j))*x + (x_1(j)-x_0(j))*y + (x_0(j)*y_1(j)-x_1(j)*y_0(j));
        ls_m(i,3*(j-1)+1) = phic(:,j)/lc(:,j);
        ls_m(i,3*(j-1)+2) = ([x y]-xCr_m(1,:,j))*-t_m(:,:,j)';
        ls_m(i,3*(j-1)+3) = ([x y]-xCr_m(2,:,j))*t_m(:,:,j)';
    end
    
end

ind=0;
for iel = 1 : numelem
    sctr = element(iel,:);    
    for j=1:numcracks
        phi1  = ls_m(sctr,3*(j-1)+1);
        psi1  = ls_m(sctr,3*(j-1)+2);
        psi2  = ls_m(sctr,3*(j-1)+3);
        if ( max(phi1)*min(phi1) < 0 )
            if max(psi1) < 0 && max(psi2) < 0
                ind=ind+1;
                split_elem_m(j,ind) = iel;
            end
        end
    end    
end


end

