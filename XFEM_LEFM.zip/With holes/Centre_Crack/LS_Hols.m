function [ ls_h,hole_nodes,split_nodes_h,Tot_split_elem_h,split_elem_h ] = LS_Hols( numholes,xh,yh,rh )

%  LEVEL SET INITIALIZATION FOR HOLES
%===========================================================

global node element

numnode = size(node,1);
node1 = node;
ls_h  = zeros(numnode,numholes);

for i=1:numnode
    xi=node(i,1);
    yi=node(i,2);
    for j=1:numholes
        d1 = sqrt((xi-xh(j))^2+(yi-yh(j))^2)-rh(j);
        if d1 < 0
            ls_h(i,j) = d1;
            node1(i,:)=0;
        else
            ls_h(i,j) = d1;
        end
        d2=sqrt((xi-xh(j))^2+(yi-yh(j))^2);
        rr(i,j)=d2;
    end
end

for j=1:numholes
    tst1 = []; tst2 = []; tst = [];
    tst1 = rr(:,j) - rh(j);
    tst2 = tst1(element)';
    n1 = size(find(min(tst2<=0)),2);
    hole_elem(j,1:n1) = find(min(tst2<=0));
    tst = max(tst2).*min(tst2);
    n2 = size(find(tst<=0),2); 
    tt = find(tst<=0);
    split_elem_h(j,1:n2) = tt(1:n2);
    pp1 = find(hole_elem(j,:));
    n3 = size(pp1,2);
    n4 = size(unique(element(hole_elem(j,1:n3),:)),1);
    hole_nodes_s(1:n4,j) = unique(element(hole_elem(j,1:n3),:));
    pp2 = union(split_elem_h(j,:),hole_elem(j,:));
    n5 = size(union(split_elem_h(j,:),hole_elem(j,:)),2);
    Tot_split_elem_h(j,1:n5) = pp2(1:n5);
    n6 = size(find(split_elem_h(j,:)),2);
    n7 = size(unique(element(split_elem_h(j,1:n6),:)),1);
    split_nodes_h(1:n7,j) = unique(element(split_elem_h(j,1:n6),:));
    pp3 = find(split_nodes_h(:,j));
    n8  = size(pp3,1);
    pp4 = find(hole_nodes_s(:,j));
    n9  = size(pp4,1);
    pp5 = hole_nodes_s(1:n9,j);
    n10 = size(pp5,1);
    hole_nodes(1:n10,j) = hole_nodes_s(1:n9,j);
end

end

