
% ====================================================================== %
%                          FOR LEFT EDGE CRACK
% ====================================================================== %

xaL  = xTipL(jj-1,1); yaL = xTipL(jj-1,2);
xbL  = xTipL(jj,1);   ybL = xTipL(jj,2);

seg2L   = xCr(jj-1,:) - xCr(jj,:);         %  New segment
seg22L  = xCr(jj,:) - xCr(jj-1,:);        %  New segment
t2L   = 1/norm(seg2L)*seg2L;
t22L  = 1/norm(seg22L)*seg22L;

lsLL = zeros(numnode,3);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    lL   = sqrt((xbL-xaL)*(xbL-xaL)+(ybL-yaL)*(ybL-yaL)) ;  % crack length
    phiL = (yaL-ybL)*x + (xbL-xaL)*y + (xaL*ybL-xbL*yaL);   % area
    lsLL(i,1) = -phiL/lL;                                    % normal LS        % y-distance from node to crack line
    lsLL(i,2) = ([x y]-xTipL(jj,:))*t2L';
    lsLL(i,3) = ([x y]-xTipL(jj-1,:))*t22L';                                   % x-distance of node previous tip
end

split_elemL = [];
count1 = 0;
count2 = 0;
tip_elemL = [];
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = lsLL(sctr,1);
    psi  = lsLL(sctr,2);
    psi2 = lsLL(sctr,3);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) < 0&& max(psi2) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elemL(count1) = iel;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elemL(count2) = iel;
        end
    end
end

% ====================================================================== %
%                          FOR RIGHT EDGE CRACK
% ====================================================================== %

xaR  = xTipR(jj-1,1); yaR = xTipR(jj-1,2);
xbR  = xTipR(jj,1);   ybR = xTipR(jj,2);

seg2R   = xCr(jj+2,:) - xCr(jj+1,:);
seg22R  = xCr(jj+1,:) - xCr(jj+2,:);           %  New segment
t2R   = 1/norm(seg2R)*seg2R;
t22R  = 1/norm(seg22R)*seg22R;

lsRR = zeros(numnode,3);
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    lR   = sqrt((xbR-xaR)*(xbR-xaR)+(ybR-yaR)*(ybR-yaR)) ;  % crack length
    phiR = (yaR-ybR)*x + (xbR-xaR)*y + (xaR*ybR-xbR*yaR);   % area
    lsRR(i,1) = phiR/lR;                                    % normal LS         % y-distance from node to crack line
    lsRR(i,2) = ([x y]-xTipR(jj,:))*t2R';
    lsRR(i,3) = ([x y]-xTipR(jj-1,:))*t22R';                                      % x-distance of node previous tip
end

split_elemR = [];
count1 = 0;
count2 = 0;
tip_elemR = [];
for iel =  numelem:-1:1
    sctr = element(iel,:);
    phi  = lsRR(sctr,1);
    psi  = lsRR(sctr,2);
    psi2  = lsRR(sctr,3);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) <0 &&max(psi2) < 0
            count1 = count1 + 1 ; % ah, one split element
            split_elemR(count1) = iel;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1 ; % ah, one tip element
            tip_elemR(count2) = iel;
        end
    end
end
