x0  = xCr(1,1); y0 = xCr(1,2);
x1  = xCr(2,1); y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
t1   = 1/norm(seg1)*seg1;
ls=zeros(numnode,3);

for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;               % normal LS
    ls(i,2) = ([x y]-xTipR)*t';     % tangent LS
    ls(i,3) = ([x y]-xTipL)*t1';   % tangent LS Second tip LeftTip
end

enrich_node = zeros(numnode,1);
count1 = 0;
count2 = 0;

for iel = 1: numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    psi1 = ls(sctr,3);
    
    if ( max(phi)*min(phi) < 0 )% && max(psi1)*min(psi1) > 0)
        if (max(psi) < 0 ) && (max(psi1) < 0) %
            count1 = count1 + 1 ;
            split_elem(count1) = iel;
            enrich_node(sctr)   = 1;
        end
    end
end

for iel = 1: numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    psi1 = ls(sctr,3);
    xdiff=xTipR(1)-node(sctr,1);
    ydiff=xTipR(2)-node(sctr,2);
    
    xdiff1=xTipL(1)-node(sctr,1);
    ydiff1=xTipL(2)-node(sctr,2);
    
    if ( max(phi)*min(phi) < 0 )
        
        if  (max(psi)*min(psi) < 0 )%&& (max(xdiff)*min(xdiff)<0 && max(ydiff)*min(ydiff)<0) )
            if (max(xdiff)*min(xdiff)<0 && max(ydiff)*min(ydiff)<0)
                count2 = count2 + 1 ; % one tip element
                tip_elem(count2) = iel;
                enrich_node(sctr)   = 2;
            end
            if (enrich_node(sctr)   == 0|enrich_node(sctr)   == 1)
                count1 = count1 + 1 ;
                split_elem(count1) = iel;
                enrich_node(sctr)   = 1;
            end
        end
        if  (max(psi1)*min(psi1) < 0 )%&& (max(xdiff1)*min(xdiff1)<0 && max(ydiff1)*min(ydiff1)<0) )
            if (max(xdiff1)*min(xdiff1)<0 && max(ydiff1)*min(ydiff1)<0)
                count2 = count2 + 1 ; % one tip element
                tip_elem(count2) = iel;
                enrich_node(sctr)   = 2;
                if (enrich_node(sctr)   == 0|enrich_node(sctr)   == 1)
                    count1 = count1 + 1 ;
                    split_elem(count1) = iel;
                    enrich_node(sctr)   = 1;
                end
            end
        end
        
    end
end