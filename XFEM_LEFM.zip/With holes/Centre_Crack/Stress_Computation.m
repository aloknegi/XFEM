stressPoints=[-1 -1;1 -1;1 1;-1 1];
stress = zeros(numelem,4,3);
for iel = 1 : numelem
    sctr = element(iel,:);
    nn   = length(sctr);
    U    = element_disp(iel,pos,enrich_node,u);
%     sctrB = assembly(iel,enrich_node,pos);
    % Choose Gauss quadrature rules for elements
    
    for kk = 1 : nn
        pt = stressPoints(kk,:);
        
        if (ismember(iel,split_elem))     % split element
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,xTipR,alphaR);
            
        elseif (ismember(iel,tip_elem))   % tip element
            nodes = node(sctr,:);
            [ dist1 ] = closeTip( nodes,xTipL );
            [ dist2 ] = closeTip( nodes,xTipR );
            if (dist1<dist2)
                xTip2 =xTipL;
                alpha2=alphaL;
            else
                xTip2 =xTipR;
                alpha2=alphaR;
            end
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,xTipR,alphaR);
            
        elseif ( any(intersect(tip_nodes,sctr)) ~= 0)% having tip enriched nodes
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,xTipR,alphaR);
            
        elseif (ismember(iel,Tot_split_elem_h(1:numholes,:)))     % hole element
            
            for j=1:numholes
                if (ismember(iel,Tot_split_elem_h(j,:)))
                    [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));
                end
            end
            
        else
            [B,J0] = xfemBmatrix(pt,elemType,iel,enrich_node,xCr,xTipL,alphaL,xTipR,alphaR);
        end
        strain = B*U;
        stress(iel,kk,:) = C*strain;
    end
end

% stressPoints=[-1 -1;1 -1;1 1;-1 1];
% stress = zeros(numelem,4,3);
% for iel = 1 : numelem
%     sctr = element(iel,:);
%     nn   = length(sctr);
%     U     = element_disp(iel,pos,enrich_node,u);
%     for i=1:nn
%         pt = stressPoints(i,:);
% %         if (ismember(iel,Tot_split_elem_h))
% %             [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole);
%         if (ismember(iel,Tot_split_elem_h(1:numholes,:)))
%             for j=1:numholes
%                 if (ismember(iel,Tot_split_elem_h(j,:)))
%                     [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole(j,:));
%                 end
%             end
%         else
%             [B,J0] = xfemBmatrixh(pt,elemType,iel,enrich_node,hole);
%         end
%         strain = B*U;
%         stress(iel,i,:) = C*strain;
%     end
% end


